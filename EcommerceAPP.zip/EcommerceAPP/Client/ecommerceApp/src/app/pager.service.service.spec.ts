import { TestBed } from '@angular/core/testing';

import { Pager.ServiceService } from './pager.service.service';

describe('Pager.ServiceService', () => {
  let service: Pager.ServiceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(Pager.ServiceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
