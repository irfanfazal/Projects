import { Component, OnInit } from '@angular/core';
import { ProductService } from 'src/app/products/product.service';
import { Product_Category } from '../category';

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.css']
})
export class SidebarComponent implements OnInit {
 categoryList:Product_Category
  constructor(private productservice:ProductService) { }

  ngOnInit(): void {
    debugger;
    this.productservice.getCategory().subscribe(data=>{

      this.categoryList=data;
    })
  }

}
