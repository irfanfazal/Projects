export interface Product_Category {
    id:number;
    name:string;
    created_date:string

}
