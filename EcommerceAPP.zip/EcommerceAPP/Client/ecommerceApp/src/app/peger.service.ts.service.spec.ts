import { TestBed } from '@angular/core/testing';

import { Peger.Service.TsService } from './peger.service.ts.service';

describe('Peger.Service.TsService', () => {
  let service: Peger.Service.TsService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(Peger.Service.TsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
