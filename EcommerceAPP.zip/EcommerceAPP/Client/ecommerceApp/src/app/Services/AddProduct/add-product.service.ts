import {UtilityService} from '../Generices/utility.service'
import { Injectable } from '@angular/core';
import {Product} from '../../../app/products/product'

@Injectable({
  providedIn: 'root'
})
export class AddProductService {

constructor(private _servicecaller: UtilityService) {

 }
exportProductReport(p: string) {
  return this._servicecaller.GenericServiceCallMethod("post", "Categories/ExportProduct/", "",p);
}

}
