import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpResponse } from '@angular/common/http';
import { DatePipe } from '@angular/common';
import { Observable, throwError } from 'rxjs';
import { map, catchError } from 'rxjs/operators';
import * as bigInt from 'json-bigint';
import * as _ from "lodash";
import * as moment from 'moment';

declare var $: any;

@Injectable({
  providedIn: 'root'
})
export class UtilityService {
  private myDomain: string;
  // coolHttp: CoolHttp;
  headers: HttpHeaders;
  private myUrl: string;
  domainUtills = new DomainUtills();
  baseUrl = new BaseUrl();
constructor(public http: HttpClient) {
  this.myDomain = this.domainUtills.GetDomain();
  this.headers = this.getHeaders();
}
GenericServiceCallMethod(callType: string, controlerActionName: string, token: string, data: any): any
{
  let myUrl = "";
  let myCallType = "";
  if (callType != "" && controlerActionName != "") {
      // MAKING COMPLETE URL ,  SETTING CALL TYPE [POST / GET]  AND MAKING HEADERS
      $("#spinnerLoaderXhr").show();
      myUrl = this.myDomain + controlerActionName;
      myCallType = callType;
      this.headers = this.headers.set('Request-Date', new Date().toLocaleString());

      if (myCallType == "post") {
          if (data != null) {
              return this.http.post(myUrl, data, { responseType: 'text', headers: this.headers }).pipe(
                  map((res) => {
                      $("#spinnerLoaderXhr").hide();
                      return bigInt.parse(res);
                  }),
                  catchError(e => {
                      $("#spinnerLoaderXhr").hide();
                      if (e.status === 401) {
                          localStorage.clear();
                          window.location.href = window.location.origin + '/StagingAccount/SecureLogin';
                          return throwError(new Error('Unauthorized'));
                      }
                      else {
                          return throwError(e);
                      }
                  }));
          }
          else {
              return JSON.stringify("Please send data");
          }
      }
      else if (myCallType == "get") {
          return this.http.get(myUrl, { responseType: 'text', headers: this.headers }).pipe(
              map((res) => {
                  $("#spinnerLoaderXhr").hide();
                  return bigInt.parse(res);
              }),
              catchError(e => {
                  $("#spinnerLoaderXhr").hide();
                  if (e.status === 401) {
                      localStorage.clear();
                      window.location.href = window.location.origin + '/StagingAccount/SecureLogin';
                      return throwError(new Error('Unauthorized'));
                  }
                  else {
                      return throwError(e);
                  }
              }));
      }
      else {
          return JSON.stringify("Please enter a valid call type [post get]");
      }
  } else {
      return JSON.stringify("Controler/Action name or type [post get] required");
  }
}

showAlertMessage(message, type: number) {
  (document.getElementById("alertMessage") as HTMLDivElement).innerHTML = "";
  if (message != undefined && message != "" && type != null) {
      var div = $("#alertMessage");
      if (div == undefined || div == null) {
          return;
      }
      div.on("mouseenter", function () {
          clearTimeout(timeOutFunction);
      });
      div.on("mouseleave", function () {
          div.fadeOut(1000);
      });
      var innerhtml = "";
      if (type === 0) {
          innerhtml = "<div class='alert alert-danger alert-content' id='alert' ><p><span class='glyphicon glyphicon-exclamation-sign margin-r5'></span> " + message + "</p></div>";
          div.append(innerhtml);
          div.css("display", "block");
          var timeOutFunction = setTimeout(() => {
              div.find("[id$='alert']").fadeOut(1000);
              div.find("[id$='alert']").remove();
              div.css("display", "none");
          }, 3000);
      }
      else if (type === 1) {
          var innerhtml = "<div class='alert alert-success alert-content' id='alert' ><p><span class='glyphicon glyphicon-ok margin-r5'></span> " + message + "</p></div>";
          div.append(innerhtml);
          div.css("display", "block");
          var timeOutFunction = setTimeout(() => {
              //Changes By Billing
              //div.find("[id$='alert']").fadeOut(100);
              div.find("[id$='alert']").fadeOut(1000);
              div.find("[id$='alert']").remove();
              div.css("display", "none");
          }, 3000);
      }

      else if (type === 2) {
          innerhtml = "<div class='alert alert-warning alert-content' id='alert' ><p><span class='glyphicon glyphicon-exclamation-sign margin-r5'></span> " + message + "</p></div>";
          div.append(innerhtml);
          div.css("display", "block");
          var timeOutFunction = setTimeout(() => {
              div.find("[id$='alert']").fadeOut(1000);
              div.find("[id$='alert']").remove();
              div.css("display", "none");
          }, 4000);
      }
      else if (type === 3) {
          innerhtml = "<div class='alert alert-info alert-content' id='alert' ><p><span class='glyphicon glyphicon-exclamation-sign margin-r5'></span> " + message + "</p></div>";
          div.append(innerhtml);
          div.css("display", "block");
          var timeOutFunction = setTimeout(() => {
              div.find("[id$='alert']").fadeOut(1000);
              div.find("[id$='alert']").remove();
              div.css("display", "none");
          }, 4000);
      }
  }

  return;
}
private getHeaders() {
  let headers = new HttpHeaders();
  headers = headers.append('Access-Control-Allow-Origin', '*');
  headers = headers.append("Access-Control-Allow-Credentials", "true");
  headers = headers.append('Access-Control-Allow-Headers', '*');
  headers = headers.append('Token', localStorage.getItem("AuthToken"));
  headers = headers.append('serverID', localStorage.getItem("siteId"));
  headers = headers.append('Content-Type', 'application/json; charset=UTF-8');
  headers = headers.append('Accept', 'application/json');
  headers = headers.append('Request-Date', new Date().toLocaleString())
  return headers;
}

}
export class DomainUtills {
  baseUrl = new BaseUrl();
  GetDomain(): any {
      return this.baseUrl.ApiUrl + "api/";
  }
}
  export class BaseUrl {
    private applicationUrl: string;
    private apiUrl: string;
    constructor() {
        this.applicationUrl = window.location.origin + "/";
        this.apiUrl = this.getApiUrl();
    }
    get ApplicationUrl() {
        return this.applicationUrl;
    }
    get ApiUrl() {
        return this.apiUrl;
    }
    getApiUrl() {
        let originalPath = window.location.origin;
        let domain: string = "";
        if (originalPath.includes("localhost")) {
            domain = "https://localhost:44333/";
        }

        else if (originalPath.includes("10.20.25.33:8060")) {
            domain = "http://10.20.25.33:8061/";
        }
        else if (originalPath.includes("securesoft.mtbc.com")) {
            domain = "https://securesoftapi.mtbc.com/";
        }
        else if (originalPath.includes("10.20.25.33:6060")) {
            domain = "http://10.20.25.33:6061/";
        }
        else if (originalPath.includes("securesoft2.mtbc.com")) {
            domain = "https://securesoft2api.mtbc.com/";
        }
        else if (originalPath.includes("172.25.0.36:6060")) {
            domain = "http://172.25.0.36:6061/";
        }
        else if (originalPath.includes("securesoft3.mtbc.com")) {
            domain = "https://securesoft3api.mtbc.com/";
        }
        else if (originalPath.includes("10.20.25.34:7070")) {
            domain = "http://10.20.25.34:7069/";
        }
        else if (originalPath.includes("10.20.25.32:4440")) {
            domain = "http://10.20.25.32:4441/";
        }
        else if (originalPath.includes("stagingsoft.mtbc.com")) {
            domain = "https://stagingsoftapi.mtbc.com/";
        }
        else if (originalPath.includes("10.20.25.34:6060")) {
            domain = "http://10.20.25.34:6061/";
        }
        else if (originalPath.includes("testingsoft.mtbc.com")) {
            domain = "https://testingsoftapi.mtbc.com/";
        }
        else if (originalPath.includes("testingsoft2.mtbc.com")) {
            domain = "https://testingsoft2api.mtbc.com/";
        }
        else if (originalPath.includes("10.20.25.32:8060")) {
            domain = "http://10.20.25.32:8061/";
        }
        else if (originalPath.includes("172.16.0.27:9131")) {
            domain = "http://172.16.0.27:9132/";
        }
        else if (originalPath.includes("10.20.25.32:4406")) {
            domain = "http://10.20.25.32:4407/";
        }
        else if (originalPath.includes("10.20.25.32:3306")) {
            domain = "http://10.20.25.32:3307/";
        }
        else if (originalPath.includes("172.16.0.27:9995")) {
            domain = "http://172.16.0.27:9996/";
        }
        else if (originalPath.includes("172.16.0.27:2020")) {
            domain = "http://172.16.0.27:2021/";
        }
        else if (originalPath.includes("10.20.25.32:8097")) {
            domain = "http://10.20.25.32:8098/";
        }
        else if (originalPath.includes("10.20.35.70:8086")) {
            domain = "http://10.20.35.70:8087/";
        }
        else if (originalPath.includes("10.20.25.32:2255")) {
            domain = "http://10.20.25.32:2256/";
        }
        else if (originalPath.includes("10.20.25.32:1087")) {
            domain = "http://10.20.25.32:1088/";
        }
        else if (originalPath.includes("172.16.0.27:2222")) {
            domain = "http://172.16.0.27:2221/";
        }
        else if (originalPath.includes("172.16.0.27:1010")) {
            domain = "http://172.16.0.27:1011/";
        }
        else if (originalPath.includes("172.16.0.27:1596")) {
            domain = "http://172.16.0.27:1597/";
        }
        else if (originalPath.includes("10.20.25.32:8097")) {
            domain = "http://10.20.25.32:8098/";
        }
        else if (originalPath.includes("10.20.25.32:4475")) {
            domain = "http://10.20.25.32:4476/";
        }
        else if (originalPath.includes("172.16.0.27:1596")) {
            domain = "http://172.16.0.27:1597/";
        }
        else if (originalPath.includes("172.16.0.27:5542")) {
            domain = "http://172.16.0.27:5543/";
        }
        else if (originalPath.includes("10.20.25.32:2255")) {
            domain = "http://10.20.25.32:2256/";
        }
        else if (originalPath.includes("10.20.25.32:4408")) {
            domain = "http://10.20.25.32:4409/";
        }
        else if (originalPath.includes("10.20.25.32:1072")) {
            domain = "http://10.20.25.32:1073/";
        }
        else if (originalPath.includes("10.20.25.32:4447")) {
            domain = "http://10.20.25.32:4446/";
        }
        else if (originalPath.includes("172.16.0.27:9091")) {
            domain = "http://172.16.0.27:9092/";
        }
        else if (originalPath.includes("172.16.0.27:9091")) {
            domain = "http://172.16.0.27:9092/";
        }
        else if (originalPath.includes("172.16.0.27:9130")) {
            domain = "http://172.16.0.27:9129/";
        }
        return domain;
    }
}
export enum MessageType {
  error = 0,
  success = 1,
  warning = 2,
  info = 3

}
