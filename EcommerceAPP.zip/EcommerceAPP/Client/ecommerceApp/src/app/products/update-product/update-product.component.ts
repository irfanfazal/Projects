import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-update-product',
  templateUrl: './update-product.component.html',
  styleUrls: ['./update-product.component.css']
})
export class UpdateProductComponent implements OnInit {
  productid=0;
  constructor(private activedroute:ActivatedRoute) { }

  ngOnInit(): void {
    this.activedroute.params.subscribe(data=>{
      this.productid=data.id;
    })
  }


}
