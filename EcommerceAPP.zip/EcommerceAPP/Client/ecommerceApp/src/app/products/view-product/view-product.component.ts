import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-view-product',
  templateUrl: './view-product.component.html',
  styleUrls: ['./view-product.component.css']
})
export class ViewProductComponent implements OnInit {
  productid=0;
  constructor(private activedroute:ActivatedRoute) { }

  ngOnInit(): void {
    this.activedroute.params.subscribe(data=>{
      this.productid=data.id;
    })
  }

}
