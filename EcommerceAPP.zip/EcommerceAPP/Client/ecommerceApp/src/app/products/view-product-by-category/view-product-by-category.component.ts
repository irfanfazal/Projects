import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-product-by-category',
  templateUrl: './view-product-by-category.component.html',
  styleUrls: ['./view-product-by-category.component.css']
})
export class ViewProductByCategoryComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
