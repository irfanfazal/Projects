

export interface Product {
    productID:number;
    //categoryID:string;
    productName:string;
    description:string;
    //rating:string;
    //price:string;
    //created_date:string;
    //productImage:string;
    isAvaialable:boolean;
    //color:string;
    //review:number;
    mrp:number;
    dp:number;
}
