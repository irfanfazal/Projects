import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import {Product} from '../products/product';
import { Product_Category } from '../site-layout/category';
import {HttpHeaders,HttpParams } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ProductService {
  static filteredColumns: any[];
  baseUrl='https://localhost:44333/api/Categories/';
  constructor(private httpclient:HttpClient)
  { }
  createProducts(productBody):Observable<Product>
  {
    debugger;
   this.baseUrl='https://localhost:44333/api/Product/';
    return this.httpclient.post<Product>(this.baseUrl+'InsertProduct',productBody);

  }
  getCategory():Observable<Product_Category>
  {

    return this.httpclient.get<Product_Category>(this.baseUrl+'GetCategoriesList');
  }
  getProducts():Observable<Product>
  {
    this.baseUrl='https://localhost:44333/api/Product/';
    return this.httpclient.get<Product>(this.baseUrl+'GetProductList');
  }
  singleProduct(id):Observable<any>
  {
    debugger;
    const params = new HttpParams().append('id', id);
    this.baseUrl='https://localhost:44333/api/Product/';
    return this.httpclient.get(this.baseUrl+'GetProductById',{ params: params});
  }
  updateProduct(productdata:any)  {

    debugger;
    this.baseUrl='https://localhost:44333/api/Product/';
    return this.httpclient.post('https://localhost:44333/api/Product/UpdateProduct',productdata,{responseType: 'text'});
  }
  deleteProduct(id)  {

    debugger;
    const params = new HttpParams().append('id', id);
    this.baseUrl='https://localhost:44333/api/Product/';
    return this.httpclient.delete(this.baseUrl+'DeleteProductById',{ params: params});
  }
  static setFilterColumns(columns: any = [])
  {
   this.filteredColumns = [];
   if (columns != null && columns != undefined && columns.length > 0) {
       for (var i = 0; i < columns.length; i++)
       {
           this.filteredColumns.push(columns[i]);
       }
   }
}
}
