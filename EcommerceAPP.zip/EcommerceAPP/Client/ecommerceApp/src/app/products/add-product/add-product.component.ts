import { AddProductService } from './../../Services/AddProduct/add-product.service';
import { PagerService } from './../../pager.service';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { Product } from '../product';
import { ProductService } from '../product.service';
import { ToastrService } from 'ngx-toastr';
import {UtilityService,MessageType} from '../../Services/Generices/utility.service';
declare var jQuery: any;
@Component({
  selector: 'app-add-product',
  templateUrl: './add-product.component.html',
  styleUrls: ['./add-product.component.css'],
})
export class AddProductComponent implements OnInit {
  query = '';
  pager: any = {};
  pagesize: number = 5;
  page = 1;
  all_product_data;
  addEditProductForm: FormGroup;
  addEditProduct: boolean = false; //for form validation
  popup_header: string;
  add_product: boolean;
  edit_product: boolean;

  product_data;
  product_dto: Product;

  single_product_data: Product;
  edit_product_id;
  product_id;
  productreponse: Product[];

  constructor(
    private formBuilder: FormBuilder,
    private router: Router,
    private product_service: ProductService,
    private toastr: ToastrService,
    private pagerService: PagerService,
    private addProductservice:AddProductService,
    private utilityservice:UtilityService
  ) {}

  ngOnInit() {
    this.addEditProductForm = this.formBuilder.group({
      productName: ['', Validators.required],
      isAvaialable: ['', Validators.required],
      description: ['', Validators.required],
      mrp: ['', Validators.required],
      dp: ['', Validators.required],
    });
    this.getAllProduct();
  }

  get rf() {
    return this.addEditProductForm.controls;
  }

  resetdefaultform() {
    debugger;
    this.addEditProductForm.reset;
  }

  getAllProduct() {
    this.product_service.getProducts().subscribe(
      (data) => {
        this.all_product_data = JSON.parse(JSON.stringify(data));
        this.productreponse = JSON.parse(JSON.stringify(data));
        this.setPage(1, 5);
      },
      (error) => {
        console.log('My error', error);
      }
    );
  }
  addProductPopup() {
    this.add_product = true;
    this.edit_product = false;
    this.popup_header = 'Add New Product';
  }

  addNewProduct() {
    debugger;
    this.addEditProduct = true;
    if (this.addEditProductForm.invalid) {
      // alert('Error!! :-)\n\n' + JSON.stringify(this.addEditProductForm.value))
      return;
    }
    this.product_data = this.addEditProductForm.value;
    this.product_dto = {
      productID: 0,
      productName: this.product_data.productName,
      description: this.product_data.description,
      mrp: this.product_data.mrp,
      dp: this.product_data.dp,
      isAvaialable: this.product_data.isAvaialable,
    };
    this.product_service.createProducts(this.product_dto).subscribe(
      (data) => {
        // console.log(data);
        this.toastr.success('Product Created Successfully!', 'Success');
        this.addEditProductForm.reset();
        jQuery('#addEditProductModal').modal('toggle');
        this.getAllProduct();
      },
      (err) => {
        alert('Some Error Occured');
      }
    );
    this.addEditProductForm.reset();
    this.addEditProductForm.get('productName').clearValidators();
    this.addEditProductForm.get('isAvaialable').clearValidators();
    this.addEditProductForm.get('description').clearValidators();
    this.addEditProductForm.get('mrp').clearValidators();
    this.addEditProductForm.get('dp').clearValidators();
  }

  editProductPopup(id) {
    debugger;
    this.add_product = false;
    this.edit_product = true;
    this.popup_header = 'Edit Product';
    this.addEditProductForm.reset();
    this.product_service.singleProduct(id).subscribe((data) => {
      this.single_product_data = data;
      this.edit_product_id = data.productID;
      console.log('single_product_data', this.single_product_data);
      this.addEditProductForm.setValue({
        //productID:this.single_product_data.productID,
        productName: this.single_product_data.productName,
        // uploadPhoto: '',
        //uploadPhoto: this.single_product_data.uploadPhoto,
        description: this.single_product_data.description,
        mrp: this.single_product_data.mrp,
        dp: this.single_product_data.dp,
        isAvaialable: this.single_product_data.isAvaialable,
      });
    });
  }

  updateProduct() {
    debugger;

    var msg;
    this.addEditProduct = true;
    if (this.addEditProductForm.invalid) {
      // alert('Error!! :-)\n\n' + JSON.stringify(this.addEditUserForm.value))
      return;
    }
    this.product_data = this.addEditProductForm.value;
    this.product_dto = {
      productID: this.edit_product_id,
      productName: this.product_data.productName,
      description: this.product_data.description,
      mrp: this.product_data.mrp,
      dp: this.product_data.dp,
      isAvaialable: this.product_data.isAvaialable,
    };
    this.product_service.updateProduct(this.product_dto).subscribe(
      (res) => {
        // alert('Updated.');
        jQuery('#addEditProductModal').modal('toggle');
        this.getAllProduct();
      },
      (err) => {
        console.log(err);
      }
    );
  }

  deleteProduct(id) {
    debugger;
    let r = confirm('Do you want to delete the product ID: ' + id + '?');
    if (r == true) {
      this.product_service.deleteProduct(id).subscribe(
        (res) => {
          alert('Deleted');
          //jQuery('#addEditProductModal').modal('toggle');
          this.getAllProduct();
        },
        (err) => {
          console.log(err);
        }
      );
    } else {
      alert('You pressed Cancel!');
    }
  }
  setPage(pages: any, pagesize: any) {
    if ((pages < 1 || pages > this.pager.totalPages) && pages != '') {
      this.page = 1;
      pages = 1;
    }
    this.page = pages;
    // get pager object from service
    this.pager = this.pagerService.getPager(
      this.all_product_data.length,
      pages,
      pagesize
    );
    // get current page of items

    this.productreponse = this.all_product_data.slice(
      this.pager.startIndex,
      this.pager.endIndex + 1
    );

    console.log('in SetPage Function', this.productreponse);
  }
  showErrorPopup(msg: string, heading: string) {
    this.utilityservice.showAlertMessage(msg, MessageType.error);
    var focused = jQuery(':focus');
    jQuery('#alert').on('hidden.bs.modal', function () {
      jQuery(focused).focus();
    })
}

  exportReport() {
    debugger;
    if (this.all_product_data != null && this.all_product_data != undefined && this.all_product_data.length > 0) {
     this.addProductservice.exportProductReport(this.query).finally(() => {}).subscribe(
          (data) => {
            var url = data;
            if (url != null && url != undefined) {
            // this.showErrorPopup('Record exported successfully!', 'Success');
            console.log(url)
            } else {
            //  this.showErrorPopup('There is no record to Export','Product Report');
            console.log('No record found');
            }
          },
          (error) => {
            // this.showErrorPopup('There was an error.product to export','Product Report');
            console.log(error);
          }
        );
    }
  }
}
