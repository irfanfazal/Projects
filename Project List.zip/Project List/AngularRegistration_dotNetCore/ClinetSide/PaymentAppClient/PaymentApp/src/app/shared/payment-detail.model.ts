export class PaymentDetail {
    paymentDetailId: number=0;
    cardOwnerName: string='';
    cardNumber: string='';
    expirationDate: string='';
    securityCode: string='';
}
