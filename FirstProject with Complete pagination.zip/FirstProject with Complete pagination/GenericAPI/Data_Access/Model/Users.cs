﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data_Access.Model
{
 public   class Users
    {
        [Key]
        public int user_id { get; set; }
        public string user_name { get; set; }
    }

    public class Clients
    {  
        public int client_id { get; set; }
        public string client_name  { get; set; }
    }
}
