using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data_Access.Model
{
 public  class CreateCourse
  {

    public string Title { get; set; }

    public string Sort_Desc { get; set; }
    public string FullDesc { get; set; }

    public string Image { get; set; }

    public string Author { get; set; }

    public string IsActive { get; set; }
  }
}
