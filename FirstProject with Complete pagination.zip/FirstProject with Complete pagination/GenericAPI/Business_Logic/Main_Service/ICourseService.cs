using Data_Access.Model;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Business_Logic.Main_Service
{
  public interface ICourseService
  {
    public List<Coursepost> GetAll();

    public Coursepost Update(Coursepost obj);
    public void Update2(Coursepost obj);

    public Coursepost GetByID(int user_id);

    public void create(Coursepost user);

    public IActionResult DeleteByID(int user_id);

  }
}
