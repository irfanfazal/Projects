using Data_Access;
using Data_Access.databaseContext;
using Data_Access.Model;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;

namespace Business_Logic.Main_Service
{
public  class Auth : I_Auth
  {
    private EmployeeDataLayer E_DL;
    TutorialAppDbContext tutorialapp;
    private readonly string key;

    public Auth()
    {
      E_DL = new EmployeeDataLayer();
      tutorialapp = new TutorialAppDbContext();
    }

    public Auth( string key)
    {
      this.key = key;
    }

    public string Authenticate(Login person)
    {
      //        var db = new TutorialappDbContext();
      Employeemaster1 p = new Employeemaster1();

      p = tutorialapp.Employeemaster1.FirstOrDefault(x => x.Fname == person.Fname && x.Password == person.Password);

      //  return p;

      if (p == null)
      {
        return null;
      }

      var tokenHandler = new JwtSecurityTokenHandler();
      var tokenkey = Encoding.ASCII.GetBytes(key);
      var tokenDescriptor = new SecurityTokenDescriptor
      {
        Subject = new ClaimsIdentity(new Claim[]
        {
          new Claim(ClaimTypes.Name, person.Fname)
        }),
        Expires = DateTime.UtcNow.AddHours(1),
        SigningCredentials =
        new SigningCredentials(
          new SymmetricSecurityKey(tokenkey),

          SecurityAlgorithms.HmacSha256Signature)
      };
      var token = tokenHandler.CreateToken(tokenDescriptor);
      return tokenHandler.WriteToken(token);

    }



    public List<Employeemaster1> GetAllEmployees()
    {
      return E_DL.GetAllEmployees();
    }

    public void createEmployee(Employeemaster1 p)
    {
      E_DL.createEmployee(p);
    }

    public string deleteEmployee(int id)
    {
      return E_DL.deleteEmployee(id);  
    }


    public Employeemaster1 GetEmployeeByID(int id)
    {
      var person = E_DL.GetEmployeeByID(id);
      if (person == null)
      {
        throw new Exception("Invalid ID");
      }
      else
      {
        return person;
      }

    }

    public Employeemaster1 Login(Login person)
    {
      var res = E_DL.Login(person);
      //if (res == null)
      //  throw new Exception("Invalid ID/Name");

      return res;

    }

    public Employeemaster1 UpdateUser(Employeemaster1 obj)
    {
      return E_DL.UpdateUser(obj);
    }


  }
}
