using Data_Access;
using Data_Access.Model;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Business_Logic.Main_Service
{
  public class CourseService : ICourseService
  {
    private CoursedataLayer C_DL;

    public CourseService()
    {
      C_DL = new CoursedataLayer();

    }
    public void create(Coursepost p)
    {
      C_DL.create(p);
    }

    public IActionResult DeleteByID(int id)
    {
      return new ObjectResult(C_DL.deleteByID(id));
    }

    public List<Coursepost> GetAll()
    {
     return C_DL.GetAll();
    }

    public Coursepost GetByID(int id)
    {
      return C_DL.GetByID(id);
    }

    public Coursepost Update(Coursepost obj)
    {
      return C_DL.Update(obj);
    }
    public void Update2(Coursepost obj)
    {
       C_DL.Update(obj);
    }

    public void ImageUpload()
    {

    }
  }
}
