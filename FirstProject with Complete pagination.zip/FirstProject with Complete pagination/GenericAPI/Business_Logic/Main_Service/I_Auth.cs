using Data_Access.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Business_Logic.Main_Service
{
 public interface I_Auth
  {
    public List<Employeemaster1> GetAllEmployees();

    public Employeemaster1 GetEmployeeByID(int id);

    public void createEmployee(Employeemaster1 p);

    public string deleteEmployee(int id);

    public Employeemaster1 Login(Login person);

    public Employeemaster1 UpdateUser(Employeemaster1 obj);

    string Authenticate(Login login);


  }
}
