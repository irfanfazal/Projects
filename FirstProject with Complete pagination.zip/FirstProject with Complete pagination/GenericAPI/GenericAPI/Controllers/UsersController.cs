using Business_Logic;
using Business_Logic.Main_Service;
using Data_Access.databaseContext;
using Data_Access.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GenericAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UsersController : ControllerBase
    {
        private readonly IMainService _IMainService;
        public UsersController(IMainService _IMainService)
        {
            this._IMainService = _IMainService;
        }

        [Route("CreateUser")]
        [HttpPut]

        public void createUser([FromBody] Users user)
        {
            _IMainService.createUser(user);
        }

        [Route("GetAll")]
        [HttpGet]

        public List<Users> GetAllUsers()
        {
            var res = _IMainService.GetAllUsrs();
            return res;
        }

    [Route("GetAllEmployees")]
    [HttpGet]
    public List<Employeemaster1> GetAllEmployees()
    {
      var res = _IMainService.GetAllEmployees();
      return res;
    }

    [Route("UpdateUser")]
        [HttpPost]

        public Users UpdateUser(Users user)
        {
            var res = _IMainService.UpdateUser(user);
            return res;
        }

        [Route("GetUserByID")]
        [HttpGet]

        public Users GetUserByID(int user_id)
        {
            var res = _IMainService.GetUserByID(user_id);
            return res;
        }



        [Route("DeleteUserByID")]
        [HttpPost]
        public string DeleteUserByID(int user_id)
        {
          return  _IMainService.DeleteUserByID(user_id);
        }

    }
}
