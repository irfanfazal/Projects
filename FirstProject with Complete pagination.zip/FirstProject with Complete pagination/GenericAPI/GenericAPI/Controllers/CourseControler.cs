using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Business_Logic;
using Business_Logic.Main_Service;
using Data_Access.databaseContext;
using Data_Access.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

using System.Net.Http.Headers;
using System.IO;
using System.Net.Http;
using Microsoft.EntityFrameworkCore;

namespace GenericAPI.Controllers
{

  [Route("api/[controller]")]
  [ApiController]
  public class CourseControler : ControllerBase
  {

    private readonly ICourseService _ICourseService;

    public CourseControler(ICourseService _ICourseService, I_Auth _Auth)
    {
      this._ICourseService = _ICourseService;
    }

    [Route("GetAllCourses")]
    [HttpGet]
    public List<Coursepost> GetAll()
    {
      var res= _ICourseService.GetAll();
      return res;
    }


    [HttpPost]
    [Route("Uploads")]
    //    [HttpPost, DisableRequestSizeLimit]
    public IActionResult Upload()
    {

      try
      {
        var file = Request.Form.Files[0];
        
        var folderName = Path.Combine("assets", "images");
        //   var pathToSave = Path.Combine(Directory.GetCurrentDirectory(), folderName);
        var path1 = "C:\\Angular_Project\\FirstProject\\";
        var pathToSave = Path.Combine(path1, folderName);

        if (file.Length > 0)
        {
          var fileName = ContentDispositionHeaderValue.Parse(file.ContentDisposition).FileName.Trim('"');
          var fullPath = Path.Combine(pathToSave, fileName);
          //var dbPath = Path.Combine(folderName, fileName);
          using (var stream = new FileStream(fullPath, FileMode.Create))
          {
            file.CopyTo(stream);
            
          }
          return Ok(new { fileName });
        }
        else
        {
          return BadRequest();
        }
      }
      catch (Exception ex)
      {
        return StatusCode(500, $"Internal server error: {ex}");
      }

    }
    //public HttpResponseMessage UploadImage()
    //{
    //  string imageName = null;
    //  var httpRequest = HttpContext.Current.Request;
    //  var postedFile = httpRequest.Files["Image"];
    //  string postid = httpRequest["Id"];

    //  if (postedFile != null)
    //  {
    //    imageName = new string(Path.GetFileNameWithoutExtension(postedFile.FileName).Take(10).ToArray()).Replace(" ", "-");
    //    imageName = imageName + DateTime.Now.ToString("yymmssffff") + Path.GetExtension(postedFile.FileName);
    //    var filePath = HttpContent.Current.Server.MapPath("~/Image/" + imageName);
    //    postedFile.SaveAs(filePath);
    //  }
    //  else if (postedFile == null && pistedid != null)
    //  {
    //    imageName = DBNull.Courseposts.Find(Convert.ToInt64(httpRequest["Id"])).Image;
    //  }

    //  //Save to Database
    //  using (DbModels db = new DbModels())
    //  {
    //    Coursepost coursepost = new Coursepost()
    //    {
    //      id = Convert.ToInt64(httpRequest["Id"]),
    //      Title = httpRequest["Title"],
    //      Sort_Desc = httpRequest["Sort_Desc"],
    //      Image = imageName,
    //      EnteredDate = DateTime.Now,
    //      IsActive = 1,
    //    };

    //    if (postid == null || postid == "0")
    //    {
    //      db.Entry(coursepost).state = EntityState.Modified;
    //    }
    //    else
    //    {
    //      db.Entry(coursepost).State = EntityState.Modified;
    //    }
    //    db.SaveChanges();
    //  }
    //  return Request.CreateResponse(HttpStatusCode.Created);
    //}

    [Route("GetCourseByID")]
    [HttpPost]
    public Coursepost GetByID([FromBody] int id)
    {
      return _ICourseService.GetByID(id);
    }
      
    [Route("CreateNewCourse")]
    [HttpPost]
    public void createEmployee([FromBody] Coursepost p)
    {
   
   
      if (p.id <1)
      {
        _ICourseService.create(p);
      }
      else
      {
        _ICourseService.Update(p);
      }
     
    }

    [Route("DeleteCourseByID")]
    [HttpPost]
    //public IActionResult Get(int id)
    //{
    //  var result=_ICourseService.DeleteByID(id);
    //  return new ObjectResult("value: " + result);
    //}
    public IActionResult deletebyId([FromBody] int id)
    {
      return new ObjectResult(_ICourseService.DeleteByID(id));
    }


    [Route("UpdateCourse")]
    [HttpPost]
    public Coursepost UpdateUser(Coursepost obj)
    {
      return _ICourseService.Update(obj);
    }


  }
}
