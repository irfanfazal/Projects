import { Post2 } from './post2';

describe('Post2', () => {
  it('should create an instance', () => {
    expect(new Post2()).toBeTruthy();
  });
});
