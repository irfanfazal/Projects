import { HttpClient, HttpEventType } from '@angular/common/http';
import { Component, ElementRef, OnInit, ViewChild,Directive, EventEmitter, Input, Output, QueryList, ViewChildren } from '@angular/core';
import { FormGroup, Validators,FormBuilder, FormControl } from '@angular/forms';
import { Title } from '@angular/platform-browser';
import { event, post } from 'jquery';
import { Observable } from 'rxjs';
import { Createpost } from '../createpost';
import { PagerService } from '../pager.service';
import { Coursepost, Post } from '../post';
import { PostService } from '../post.service';
import { Post2 } from '../post2';


 
@Component({
  selector: 'app-post',
  templateUrl: './post.component.html',
  styleUrls: ['./post.component.css']
})


export class PostComponent implements OnInit {


  page2: any ;
  pager: any={}
  pagesize: number = 10;
  objCustomerResponseOrignal: Post[];
  objCustomerResponse2: Post[];
  
  title = 'Posts';
  allpost: Post[]=[];
  
  updateData:Post[]=[];
//  coursePost:Coursepost[] =[];
  query: any;
  showGrid=true;
  datasaved:any;
  message:any;
  PostIdtoUpdate=null;
  url='./assets/images/';
  filetoUpload:any;
  selectedFiles?: FileList;
  postImage:any;
  regForm:FormGroup;
  massage:string='test';


  searchTerm: string;
  page = 1;
//  pageSize = 4;
  collectionSize: number;
  currentRate = 8;
  


  
  constructor(private postservice: PostService, private formbuilder: FormBuilder,private http: HttpClient,private pagerService: PagerService) 
  {

    // this.regForm=this.formbuilder.group(
    //   {
    //     Title:['',[Validators.required]],
    //     Sort_Desc:['',[Validators.required]],
    //     FullDesc:['',[Validators.required]],
    //     Author:['',[Validators.required]],
    //     Image:['',[Validators.required]]
    //   })
    this.objCustomerResponseOrignal=[];
    this.objCustomerResponse2=[]
    
   }
   onKeyUp()
   {
     alert("enter pressed ")
   }
   openPDF()
   {
    alert("pdf pressed ")
   }
   ExportToExcelXLS_Library()
   {
     
    alert("ExportToExcelXLS_Library pressed ")
     
   }

   setPage(pages: any, pagesize: any ) {

    
    if ((pages < 1 || pages > this.pager.totalPages) && pages != "") {
        this.page = 1;
        pages = 1;
    }  
    this.page = pages;
    // get pager object from service
     this.pager = this.pagerService.getPager(this.allpost.length, pages, pagesize);
   // get current page of items
   
    this.objCustomerResponse2 = this.allpost.slice(this.pager.startIndex, this.pager.endIndex + 1);
    
    console.log("in SetPage Function",this.objCustomerResponse2)
}





   setFormState(): void {
     this.regForm = this.formbuilder.group({
      Title:['',[Validators.required]],
      Sort_Desc:['',[Validators.required]],
      FullDesc:['',[Validators.required]],
      Author:['',[Validators.required]],
      Image:['']
//      Id!:['']
     })
   }

  ngOnInit() {
    this.setFormState()
    this.loadAllPost();  
    this.showGrid=true;  
      
    console.log("on Inti started");

  }
    // Load All courses
  loadAllPost()
  {
    this.postservice.getposts().subscribe((data) => {
   this.allpost =JSON.parse(JSON.stringify(data))
   this.objCustomerResponseOrignal=JSON.parse(JSON.stringify( data));
   //console.log(this.coursePost)
   this.collectionSize = this.allpost.length;
   this.setPage(1,10) 
    });
  }
//
  search(value: string): void {
    this.allpost = this.allpost.filter((val) => val.title.toLowerCase().includes(value));
    this.collectionSize = this.allpost.length;
  }

//clicked on Add post button
addPost()
{
  this.showGrid=false;
  this.datasaved=false;
  this.message="";
  this.PostIdtoUpdate=null;
//  this.fileToUpload=null;
this.postImage="sampleimage.png"
this.regForm.reset();
}


//Image input Handler...........................................................
handleFileInput(event: any)
{

  this.selectedFiles = event.target.files;
  if (this.selectedFiles && this.selectedFiles[0]) 
  {
      const reader = new FileReader();
      reader.readAsDataURL(this.selectedFiles[0]);
      reader.onload = (e: any) => {
        //Image input preview...........................................................
//        this.postImage=e.target.result;
    };

    this.filetoUpload=this.selectedFiles[0];
// function call to place image and get image name .............
    this.imageupload(this.filetoUpload);
 
  }
  else{
    // if no image picked default image wil choosed............................. 
       this.postImage="sampleimage.png";  
      }

}
//subscribe service to send picked image, store and get name
imageupload(file:File){
    this.postservice.upload(file).subscribe(
      (e:any)=>{
// get file name and store in postImage variable below.........................
        this.postImage=e.fileName;
        console.log("image Name is ",this.postImage);    
        
      }
    );
  }

onSubmit2()
{

//Set post data and Service call to create post  
this.regForm.patchValue({
  Image:this.postImage
})

//let post=this.regForm.value;
let post=this.regForm.value;

  //create course function call
  this.createCourse(post);
//  this.regForm.reset();
  console.log('post data',post);

}
//Subacribe service of create post
createCourse(post:Post2)
{
  debugger;
//post.image=this.postImage;
this.regForm.removeControl("Id");
  this.postservice.createpost(post).subscribe(
    data=>{
      this.datasaved=true;
      this.massage="Post Created";
      this.regForm.reset();
      this.datasaved=false;
      this.showGrid=true;
      this.loadAllPost();
    })
  }

  onEdit(id:number)
{
this.UpdatePost(id);
this.regForm.removeControl("Id");
this.regForm.removeControl("EnteredDate");

}


  UpdatePost(id:number)
  {

    this.postservice.GetByID(id).subscribe(
      postDatabyID=>{

        debugger;

        this.regForm.controls["Title"].setValue(postDatabyID.title);
        this.regForm.controls["Sort_Desc"].setValue(postDatabyID.sort_Desc);
        this.regForm.controls["FullDesc"].setValue(postDatabyID.fullDesc);
        this.regForm.controls["Image"].setValue(postDatabyID.image)
        this.regForm.controls["Author"].setValue(postDatabyID.author)
//        this.regForm.controls["Id"].setValue(postDatabyID.id)
          this.regForm.addControl('Id', new FormControl(postDatabyID.id));
          this.regForm.addControl('EnteredDate', new FormControl(postDatabyID.enteredDate));
        this.postImage=postDatabyID.image;


       this.updateData=JSON.parse(JSON.stringify(postDatabyID));
 
       console.log("data by Id is : ",this.updateData);
this.showGrid=false;
       console.log("reg form data : ",this.regForm.controls); 
       

      //  this.regForm.patchValue({
      //   Image:this.postImage
      //  })
       
//       this.regForm.append()
    //   this.regForm.setValue({Title: this.updateData., last: 'Drew'});

      //  Title:['',[Validators.required]],
      //  Sort_Desc:['',[Validators.required]],
      //  FullDesc:['',[Validators.required]],
      //  Author:['',[Validators.required]],
      //  Image:['',[Validators.required]]




      }
    )

  }


  //clicked on Cancel button in add post
Cancel(){
  this.showGrid=true;
}
onDelete(id:number){
  if(confirm("Are you sure to delete "+id))
  { 
this.Delete(id);
}
}

Delete(id:number){
  this.postservice.DeleteCourse(id).subscribe(
(data)=>
{
  console.log("return is : ",data);
  this.loadAllPost();
}   
 
  );
}




  }

 