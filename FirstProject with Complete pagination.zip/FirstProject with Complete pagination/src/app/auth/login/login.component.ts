import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { EmployeeserviceService } from '../employeeservice.service';
import { Loginemployee } from '../loginemployee';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  loginForm: FormGroup;
  massage: string='';
  Error = false;


  constructor(private employeeservice:EmployeeserviceService, private formbuilder:FormBuilder,private router:Router) 
  {
    this.loginForm = this.formbuilder.group({
      Fname: ['', [Validators.required]],
      Password: ['', [Validators.required]]
    })
   }

  ngOnInit(): void {}

  onSubmit()
  {
    let login=this.loginForm.value;
    this.login(login);
  }
  login(loginEmployee: Loginemployee) {

    console.log(loginEmployee);
    this.employeeservice.loginemployee(loginEmployee).subscribe(
      employee => {
//        debugger;
        var succ = employee;
        if(succ){
        this.loginForm.reset();
        localStorage.setItem("Employee", JSON.stringify(succ));
        this.router.navigate(['dashboard']);
        } else {
          this.Error = true;
          this.massage = "User ID/Password Wrong";
        }
      }
    )
  }


}
