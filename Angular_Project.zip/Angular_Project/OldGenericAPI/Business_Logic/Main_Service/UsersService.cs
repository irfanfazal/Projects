using Data_Access;
using Data_Access.databaseContext;
using Data_Access.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Business_Logic.Main_Service
{
    public class UsersService : IMainService
    {
        private readonly AppDbContext context;
    private readonly TutorialAppDbContext context2;
        private DataAccessService _DAL;
        public UsersService()
        {
            context = new AppDbContext();
            context2 = new TutorialAppDbContext();
            _DAL = new DataAccessService();
        }

        public void createUser(Users user)
        {
            _DAL.createUser(user);
        }

        public string DeleteUserByID(int user_id)
        {
           return  _DAL.DeleteUserByID(user_id);
        }

    public List<Employeemaster1> GetAllEmployees()
    {
      //var res = context2.Employeemaster1.ToList();
      //return res;

      return _DAL.GetAllEmployees();

    }

    public List<Users> GetAllUsrs()
        {
            var res = context.Users.ToList();
            return res;

        }

        public Users GetUserByID(int user_id)
        {
           return _DAL.GetUserByID(user_id);
        }

        public Users UpdateUser(Users obj)
        {
            return _DAL.UpdateUser(obj);
        }



    }
}
