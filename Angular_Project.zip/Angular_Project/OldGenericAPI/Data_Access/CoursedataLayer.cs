using Data_Access.databaseContext;
using Data_Access.Model;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace Data_Access
{
 public class CoursedataLayer :ControllerBase
  {
    TutorialAppDbContext tutorialapp;
    Coursepost myobj;
    public CoursedataLayer()
    {
      tutorialapp = new TutorialAppDbContext();
    }

    public List<Coursepost> GetAll()
    {
      return tutorialapp.Coursepost.ToList();

    }


    public Coursepost GetByID(int id)
    {

      Coursepost p = new Coursepost();

      p = tutorialapp.Coursepost.FirstOrDefault(x => x.id == id);

      return p;
    }

    public void create(Coursepost p)
    {

      p.EnteredDate = System.DateTime.Now;
      tutorialapp.Add(p);
      tutorialapp.SaveChanges();
    }



    public IActionResult deleteByID(int id)
    {

      var p = tutorialapp.Coursepost.FirstOrDefault(x => x.id == id);
      if (p == null)
      {
        return new ObjectResult("Invalid ID");
      }

      else
      {
        tutorialapp.Remove(p);
        tutorialapp.SaveChanges();
        return new ObjectResult("Sucessfully deleted");
      }
    }

    public Coursepost Update(Coursepost obj)
    {
      var res = tutorialapp.Coursepost.FirstOrDefault(res => res.id == obj.id);
      res.Title = obj.Title;
      res.Sort_Desc = obj.Sort_Desc;
      res.Image = obj.Image;
      res.Author = obj.Author;
      res.EnteredDate = obj.EnteredDate;
      res.IsActive = obj.IsActive;

      tutorialapp.SaveChanges();

      var res2 = tutorialapp.Coursepost.FirstOrDefault(re2 => re2.id == obj.id);
      return res2;
    }
    public void Update2(Coursepost obj)
    {
      var res = tutorialapp.Coursepost.FirstOrDefault(res => res.id == obj.id);

  //    Coursepost entereddate = new Coursepost();

     // entereddate.id = GetByID(obj.id);



//    var p = tutorialapp.Coursepost.FirstOrDefault(x => x.id == obj.id);

    
      res.Title = obj.Title;
      res.Sort_Desc = obj.Sort_Desc;
      res.Image = obj.Image;
      res.Author = obj.Author;
//      res.EnteredDate = res.EnteredDate;
      res.IsActive = obj.IsActive;

      tutorialapp.SaveChanges();

      var res2 = tutorialapp.Coursepost.FirstOrDefault(re2 => re2.id == obj.id);
      
    }

  }
}
