using Data_Access.databaseContext;
using Data_Access.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data_Access
{
  public class EmployeeDataLayer
  {
    TutorialAppDbContext tutorialapp;
    public EmployeeDataLayer()
    {
      tutorialapp = new TutorialAppDbContext();
    }

    public List<Employeemaster1> GetAllEmployees()
    {

   //   var db = new TutorialappDbContext();
      return tutorialapp.Employeemaster1.ToList();

    }


    public Employeemaster1 GetEmployeeByID(int id)
    {
//      var db = new TutorialappDbContext();
      Employeemaster1 p = new Employeemaster1();

      p = tutorialapp.Employeemaster1.FirstOrDefault(x => x.Id == id);

      return p;
    }

    public void createEmployee(Employeemaster1 p)
    {

      //      var db = new TutorialappDbContext();
      tutorialapp.Add(p);
      tutorialapp.SaveChanges();
    }



    public string deleteEmployee(int id)
    {

      var p = tutorialapp.Employeemaster1.FirstOrDefault(x => x.Id == id);
      if (p == null)
      {
        return "Invalid ID";
      }

      else
      {
        tutorialapp.Remove(p);
        tutorialapp.SaveChanges();
        return "Sucessfully deleted";
      }
    }

    public Employeemaster1 UpdateUser(Employeemaster1 obj)
    {
      var res = tutorialapp.Employeemaster1.FirstOrDefault(res => res.Id == obj.Id);
      res.Fname = obj.Fname;
      res.Lname = obj.Lname;
      res.EmailId = obj.EmailId;
      res.Role = obj.Role;
    tutorialapp.SaveChanges();

      var res2 = tutorialapp.Employeemaster1.FirstOrDefault(re2 => re2.Id == obj.Id);
      return res2;
    }


    public Employeemaster1 Login(Login person)
    {

//      var db = new TutorialappDbContext();
      Employeemaster1 p = new Employeemaster1();

      p = tutorialapp.Employeemaster1.FirstOrDefault(x => x.Fname == person.Fname && x.Password == person.Password);

      return p;
    }



  }
}
