using Data_Access.databaseContext;
using Data_Access.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data_Access
{
    public class DataAccessService
    {
        AppDbContext data;
        TutorialAppDbContext tutorialapp;
        public DataAccessService()
        {
            data = new AppDbContext();
            tutorialapp = new TutorialAppDbContext();
        }

        //Create User---------------------------------------------------------------------------
        public void createUser(Users user)
        {
            data.Add(user);
            data.SaveChanges();
        }

        //Get All Users---------------------------------------------------------------------------
        public List<Users> GetAllUsers()
        {
            return data.Users.ToList();
        }
    public List<Employeemaster1> GetAllEmployees()
    {
      return tutorialapp.Employeemaster1.ToList();
    }

    //Update User---------------------------------------------------------------------------
    public Users UpdateUser(Users obj)
        {
           var res = data.Users.FirstOrDefault(res=>res.user_id == obj.user_id);
            res.user_name = obj.user_name;
            data.SaveChanges();

            var res2 = data.Users.FirstOrDefault(re2 => re2.user_id == obj.user_id);
            return res2;
        }

        //Get User By ID---------------------------------------------------------------------------
        public Users GetUserByID(int user_id)
        {
            return data.Users.FirstOrDefault(x => x.user_id == user_id);
        }

        //Delete User By ID---------------------------------------------------------------------------
        public string DeleteUserByID(int user_id)
        {
            var user=data.Users.FirstOrDefault(x => x.user_id == user_id);

            if(user==null)
            {
                return "Invalid ID";
            }
            else 
            { 
            data.Remove(user);
                data.SaveChanges();
                return "Sucessfully deleted";
            }

        }
    }
}
