﻿using System;

namespace Data_Access
{
    public class Class1
    {
    }
}
