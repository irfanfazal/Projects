using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data_Access.Model
{
    public  class Employeemaster1
  {
    [Key]
    public long Id { get; set; }

    public string Fname { get; set; }

    public string Lname { get; set; }

    public string EmailId { get; set; }

    public string Role { get; set; }

    public string Password { get; set; }

    public DateTime? Date { get; set; }
    public int? IsActive { get; set; }
  }
}
