using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Business_Logic;
using Business_Logic.Main_Service;
using Data_Access.databaseContext;
using Data_Access.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;



namespace GenericAPI.Controllers
{
  [Route("api/[controller]")]
  [ApiController]
  public class SecondControler :ControllerBase
  {
    private readonly IMainService _IMainService;
    private readonly I_Auth _Auth;
    public SecondControler(IMainService _IMainService, I_Auth _Auth)
    {
      this._IMainService = _IMainService;
      this._Auth = _Auth;
    }


    [Route("GetAllEmployeesFromSecondControler")]
    [HttpGet]
    public List<Employeemaster1> GetAllEmployees()
    {
      var res = _Auth.GetAllEmployees();
      return res;
    }

    [Route("GetEmployeeByID")]
    [HttpGet]
    public Employeemaster1 GetEmployeeByID(int id)
    {
      return _Auth.GetEmployeeByID(id);
    }

    [Route("CreateEmployee")]
    [HttpPost]
    public void createEmployee([FromBody] Employeemaster1 p)
    {
      _Auth.createEmployee(p);
    }

    [Route("DeleteEmployeEByID")]
    [HttpPost]
    public string deleteEmployee(int id)
    {
      return _Auth.deleteEmployee(id);
    }
    [Route("Login")]
    [HttpPost]
    public Employeemaster1 Login(Login person)
    {
      return _Auth.Login(person);
    }

    [Route("authentication")]
    [HttpPost]
    public IActionResult Authenticate(Login userCred)
    {

     var token= _Auth.Authenticate(userCred);
      return Ok(token);
    }



    [Route("UpdateUser")]
    [HttpPost]
    public Employeemaster1 UpdateUser(Employeemaster1 obj)
    {
      return _Auth.UpdateUser(obj);
    }

  }
}
