import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AdminRoutingModule } from './admin-routing.module';
import { LoginComponent } from './login/login.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { AdminCourseListComponent } from './admin-course-list/admin-course-list.component';
import { CourseFormComponent } from './course-form/course-form.component';
import { PostComponent } from './post/post.component';
import { ReactiveFormsModule,FormsModule } from '@angular/forms';
import { SortDirective } from '../sort.directive';
import { SharedPipeModuleModule } from '../shared-pipe-module/shared-pipe-module.module';
import { ListFilterPipe } from '../list-filter.pipe';



@NgModule({
  declarations: [
    LoginComponent,
    DashboardComponent,
    AdminCourseListComponent,
    CourseFormComponent,
    PostComponent,
    SortDirective,
    ListFilterPipe
  ],
  imports: [
    CommonModule,
    AdminRoutingModule,
    ReactiveFormsModule,
    FormsModule,
    SharedPipeModuleModule,

  ]
})
export class AdminModule { }
