export class Post 
{
    test!:any
    id!:number;
    title!:string;
    sort_Desc!:string;
    fullDesc!:string;
    image!:string;
    author!:string
    isActive!:number;
    enteredDate!:Date
}


export class Coursepost{
    Id!:number
    Title!:string
}

