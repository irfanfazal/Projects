export class Post2 {

    Title!:string;
    Id!:number;
    Sort_Desc!:string;
    FullDesc!:string;
    Author!:string;
    Image!:string;

}
