export class Createpost {

    Title!:string;
    Sort_Desc!:string;
    FullDesc!:string;
    Image!:string;
    Author!:string;
    EnteredDate!:Date;


}
