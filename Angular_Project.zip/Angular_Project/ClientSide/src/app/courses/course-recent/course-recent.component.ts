import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-course-recent',
  templateUrl: './course-recent.component.html',
  styleUrls: ['./course-recent.component.css']
})
export class CourseRecentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
