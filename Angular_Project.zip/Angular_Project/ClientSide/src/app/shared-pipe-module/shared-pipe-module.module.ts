import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FilterPipe, HighlightPipe } from '../filter.pipe.spec';



@NgModule({
  declarations: [
    FilterPipe,
    HighlightPipe
  ],
  imports: [
    CommonModule
  ],
  exports:[
    FilterPipe ,
    HighlightPipe
  ]

})
export class SharedPipeModuleModule { }
