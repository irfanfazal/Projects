import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Employee } from './employee';
import { Loginemployee } from './loginemployee';



@Injectable({
  providedIn: 'root'
})

export class EmployeeserviceService {
url='https://localhost:44318/api/SecondControler/';

  constructor(private http:HttpClient)
  { 
  
  }

createemployee(employee:Employee):Observable<Employee>
{
return this.http.post<Employee>(this.url+'CreateEmployee',employee);
}

loginemployee(loginEmployee: Loginemployee): Observable<Employee> 
{
  return this.http.post<Employee>(this.url + 'Login', loginEmployee);
}

}


