export class Employee {

    Fname!: string;
    Lname!:string;
    EmailID!:string;
    Password!:string;
}
