export class Loginemployee {
    Fname!: string;
    Password!:string;
}
