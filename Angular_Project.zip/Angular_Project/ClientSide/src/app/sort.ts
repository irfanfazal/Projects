
export class sort{
    isDesc: any = false;
    private sortOrder=1;
    private collactor= new Intl.Collator(undefined,{
        numeric:true,
        sensitivity:"base",
    }) ; 
   
    constructor()
    {

    }

 public startSort(property:any,order:any,type:any)
    {
  if(order=='desc')
  {
      this.sortOrder=-1
  }
  return (a:any,b:any)=>{
      if(type==='date')
      {
          return this.sortData(new Date(a[property]), new Date(b[property]))
      }
      else if(type==='boolean')
      {
      
          return this.sortData(new Boolean (a[property]),new Boolean (b[property]))

      }
  
      else{
          return this.collactor.compare(a[property],b[property])* this.sortOrder
      }

  }
    }
    sortData(a: any, b:any) {
        if(a<b)
        {
            return -1* this.sortOrder
        }
        else if(a>b)
        {
            return 1 *  this.sortOrder
        }
        else{
            return 0 * this.sortOrder
        }
    }
 

}
