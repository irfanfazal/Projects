import { Createpost } from './createpost';

describe('Createpost', () => {
  it('should create an instance', () => {
    expect(new Createpost()).toBeTruthy();
  });
});
