import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-course-list',
  templateUrl: './admin-course-list.component.html',
  styleUrls: ['./admin-course-list.component.css']
})
export class AdminCourseListComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
