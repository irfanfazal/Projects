import { HttpClient, HttpEvent, HttpRequest } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Createpost } from './createpost';
import { Post, Coursepost } from './post';
import { Post2 } from './post2';

@Injectable({
  providedIn: 'root'
})
export class PostService {
  static filteredColumns: any[];

  url='https://localhost:44318/api/CourseControler/';

  constructor(private http: HttpClient) { }

//Get Courses Function...................................................
getposts():Observable<Coursepost>{    return this.http.get<Coursepost>(this.url+'GetAllCourses');  }

//Image upload function...................................................
upload(file: File): Observable<any> {

  const formData: FormData = new FormData();
   formData.append('file',file ,file.name);
  return this.http.post<File>(this.url+'Uploads',formData);

  }

  //Create Course Function...................................................
  createpost(course:Post2):Observable<Post2> {
    
    return this.http.post<Post2>(this.url+'CreateNewCourse',course); 
  
  } 
   updatepost(course:Post):Observable<Post> {
    
    return this.http.post<Post>(this.url+'CreateNewCourse',course); 
  
  }
  // createpost1(course:Post2):Observable<any> {

  //   const formData: FormData=new FormData();
  //   formData.append('Title',course.Title);
  //   formData.append('Sort_Desc',course.Sort_Desc);
  //   formData.append('FullDesc',course.FullDesc);
  //   formData.append('Author',course.Author);
  //   formData.append('Image',course.Image);

  //   return this.http.post<any>(this.url+'CreateNewCourse',formData); 
  
  // }
  

  DeleteCourse(id: any): Observable<any> 
{
  debugger
  
  var data=this.http.post<any>(this.url + 'DeleteCourseByID',id);
  return data;
}

GetByID(id: any): Observable<any> 
{

var data=this.http.post<any>(this.url+'GetCourseByID',id);
return data;
}



        //Added for the Demographics
        static setFilterColumns(columns: any = []) {
          this.filteredColumns = [];
          if (columns != null && columns != undefined && columns.length > 0) {
              for (var i = 0; i < columns.length; i++) {
                  this.filteredColumns.push(columns[i]);
              }
          }
      }

}
