import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { BannerComponent } from './banner/banner.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { CoursesModule } from './courses/courses.module';
import { StaticpagesModule } from './staticpages/staticpages.module';
import { AuthModule } from './auth/auth.module';
import { HttpClientModule} from '@angular/common/http';
import { EmployeeserviceService } from './auth/employeeservice.service';
import { ReactiveFormsModule,FormsModule } from '@angular/forms';
import { CommonModule }   from '@angular/common';
import { AdminModule } from './admin/admin.module';
import { PostService } from './admin/post.service';

import { FilterPipe } from './filter.pipe';
import { ListFilterPipe } from './list-filter.pipe';
import { PagerService } from './admin/pager.service';




@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    BannerComponent,
    PageNotFoundComponent,

    FilterPipe,
//     ListFilterPipe
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    CoursesModule,
    AuthModule,
    StaticpagesModule,
    HttpClientModule,
    ReactiveFormsModule,
    FormsModule,
    CommonModule,
    AdminModule,
    

  ],
  providers: [
    EmployeeserviceService,
    PostService,
    PagerService
    
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
