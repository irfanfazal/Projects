import { Loginemployee } from './loginemployee';

describe('Loginemployee', () => {
  it('should create an instance', () => {
    expect(new Loginemployee()).toBeTruthy();
  });
});
