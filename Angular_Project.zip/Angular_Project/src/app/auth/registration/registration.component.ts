import { Component, OnInit } from '@angular/core';
import { FormBuilder,Validators,FormGroup, ReactiveFormsModule,FormControl } from '@angular/forms';
import { EmployeeserviceService } from '../employeeservice.service';
import { Employee } from '../employee';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {

  massage:string='test';
  regForm:FormGroup;
  datasaved=false;

  constructor(private formbuilder:FormBuilder, private employeeservice:EmployeeserviceService) {

    this.regForm=this.formbuilder.group(
      {
        Fname:['',[Validators.required]],
        Lname:['',[Validators.required]],
        EmailID:['',[Validators.required]],
        Password:['',[Validators.required]]
      })
   }

  ngOnInit(): void {

    this.setformstate();
  }


  setformstate():void{  }



  onSubmit()
  {
    let employee=this.regForm.value;
    this.createemployee(employee);
    this.regForm.reset();

    console.log(employee);

  }
  

  createemployee(employee:Employee){

    this.employeeservice.createemployee(employee).subscribe(
      ()=>{
        this.datasaved=true;
        this.massage="user Created";
        this.regForm.reset();
        
        this.datasaved=false;
      }

    )
  }

}
