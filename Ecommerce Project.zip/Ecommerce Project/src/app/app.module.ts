import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { OrdersModule } from './orders/orders.module';
import { SiteLayoutModule } from './site-layout/site-layout.module';
import { ComponentComponent } from './component/component.component';
import { RouterModule } from '@angular/router';
import { ProductService } from './products/product.service';
import { HttpClientModule } from '@angular/common/http';

@NgModule({
  declarations: [
    AppComponent,
    ComponentComponent
  ],
  imports: [
    RouterModule,
    AppRoutingModule,
    BrowserModule,
    OrdersModule,
    CommonModule,
    HttpClientModule,
    SiteLayoutModule
  ],
  providers: [ProductService],
  bootstrap: [AppComponent]
})
export class AppModule { }
