export class Category {
    id: string;
    categoryName:string

}
