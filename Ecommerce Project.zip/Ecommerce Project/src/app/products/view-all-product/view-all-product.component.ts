import { Component, OnInit } from '@angular/core';
import { ProductService } from '../product.service';


@Component({
  selector: 'app-view-all-product',
  templateUrl: './view-all-product.component.html',
  styleUrls: ['./view-all-product.component.css']
})
export class ViewAllProductComponent implements OnInit {

  constructor(private productService: ProductService) { }

  Products=[
    {
      name:'first',
      price:20
    },
    {
      name:'Second',
      price:50
    },
    {
      name:'third',
      price:60
    },
    {
      name:'Fourth',
      price:80
    },
    {
      name:'Sixth',
      price:100
    },
    {
      name:'Seventh',
      price:180
    },
    {
      name:'Eighth',
      price:90
    },
    {
      name:'Nineth',
      price:200
    }
  ];

  ngOnInit(): void {
  }

}
