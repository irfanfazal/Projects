import { Component, OnInit } from '@angular/core';
import { ProductService } from '../product.service';

@Component({
  selector: 'app-add-product',
  templateUrl: './add-product.component.html',
  styleUrls: ['./add-product.component.css']
})
export class AddProductComponent implements OnInit {

  constructor(private productService:ProductService) { }

  ngOnInit(): void {
  }

  addNewProduct(form)
  {
    console.log(form.value);

    let newProduct={
      id:5,
      name:form.value.productName,
      category_id:form.value.categoryId,
      description:form.value.description,
      rating:form.value.rating,
      color:form.value.productColor,
      is_available:form.value.isAvailable,
      review:form.value.productReview,
      price:form.value.productPrice

    }
console.log("new product is: ",newProduct)

this.productService.createProduct(newProduct).subscribe(data=>
  {
    console.log("added");
  })
  }

}
