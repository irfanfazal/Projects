import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Product } from '../product';
import { ProductService } from '../product.service';

@Component({
  selector: 'app-view-product',
  templateUrl: './view-product.component.html',
  styleUrls: ['./view-product.component.css']
})
export class ViewProductComponent implements OnInit {

  Data:any;
  productDetail:Product;
  constructor(private activatedRoute: ActivatedRoute, private productService: ProductService) { }
  productID: any;
  ngOnInit(): void {

  

    this.activatedRoute.params.subscribe((data)=>
      {
        this.Data=JSON.parse(JSON.stringify(data));
        this.productID=this.Data.id;

        console.log("data is : ", data);
        console.log("Id is : ", this.productID);
        console.log("data is : ", this.Data);



      })
      this.productService.viewProduct(this.productID).subscribe(data=>{
        this.productDetail=JSON.parse(JSON.stringify(data));

        console.log("data by id is :", this.productDetail);
      })


    }



}
