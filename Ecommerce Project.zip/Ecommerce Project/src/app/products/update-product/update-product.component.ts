import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-update-product',
  templateUrl: './update-product.component.html',
  styleUrls: ['./update-product.component.css']
})
export class UpdateProductComponent implements OnInit {


  Data:any;
  constructor(private activatedRoute: ActivatedRoute) { }
  productID: any;
  ngOnInit(): void {

  

    this.activatedRoute.params.subscribe((data)=>
      {
        this.Data=JSON.parse(JSON.stringify(data));
        this.productID=this.Data.id;

        console.log("data is : ", data);
        console.log("Id is : ", this.productID);
        console.log("data is : ", this.Data);
      })
  }

}
