import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-product-by-date',
  templateUrl: './view-product-by-date.component.html',
  styleUrls: ['./view-product-by-date.component.css']
})
export class ViewProductByDateComponent implements OnInit {

  constructor() { }

  Products =[
    {
      name:'first',
      price:20
    },
    {
      name:'Second',
      price:50
    },
    {
      name:'third',
      price:60
    },
    {
      name:'Fourth',
      price:80
    },
    {
      name:'Sixth',
      price:100
    },
    {
      name:'Seventh',
      price:180
    },
    {
      name:'Eighth',
      price:90
    },
    {
      name:'Nineth',
      price:200
    }
  ];

  ngOnInit(): void {
  }

}
