import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Category } from 'src/app/site-layout/category';
import { Product } from '../product';
import { ProductService } from '../product.service';


@Component({
  selector: 'app-view-product-by-category',
  templateUrl: './view-product-by-category.component.html',
  styleUrls: ['./view-product-by-category.component.css']
})
export class ViewProductByCategoryComponent implements OnInit {

  searchcategory: Product[];
  productList : Product[];
  test:Product[];
  Data:any;
  constructor(private activatedRoute:ActivatedRoute, private productService: ProductService) { }



  ngOnInit(): void {

   

    this.activatedRoute.params.subscribe(data=>{

      this.Data=JSON.parse(JSON.stringify(data));

      this.searchcategory=this.Data.id;
      console.log("Product is : ",this.searchcategory);

      this.productService.searchCategoryProduct(this.searchcategory).subscribe(categoryData=>{

        this.productList=JSON.parse(JSON.stringify(categoryData));
    
        console.log("Product by category is : ",this.productList);

    })




    })


  }

}