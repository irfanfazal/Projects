import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { from, Observable } from 'rxjs';

import { Category } from '../site-layout/category';
import { Product } from './product';

@Injectable({
  providedIn: 'root'
})
export class ProductService {

   ProductsURL="http://localhost:8000/products";
   CategoryURL="http://localhost:8000/categories";
   constructor(private httpClient:HttpClient) { }

  createProduct(productBody):Observable<Product>
  {
  //  const ProductsURL="http://localhost:8000/product";
   return this.httpClient.post<Product>(this.ProductsURL,productBody);
   }

   viewProduct(productid: any):Observable<Product>{
    return this.httpClient.get<Product>(this.ProductsURL+'/'+productid);
  }
  viewAllProducts():Observable<Product>{
    return this.httpClient.get<Product>(this.ProductsURL);
  }
  
  updateProduct(productid: any,productBody:Product):Observable<Product>{
    return this.httpClient.put<Product>(this.ProductsURL+'/'+productid,productBody);
  }
  
  deleteProduct(productid: any):Observable<Product>{
    return this.httpClient.delete<Product>(this.ProductsURL+'/'+productid);
  }  
    
  searchCategoryProduct(category_id: any):Observable<Product>{
    return this.httpClient.get<Product>(this.ProductsURL+'?category_id='+category_id);
  }
      
  searchDateProduct(dateparm:any):Observable<Product>{
    return this.httpClient.get<Product>(this.ProductsURL+'/date='+dateparm);
  }
      
  getCategories():Observable<Category>{
      const url="http://localhost:8000/categories";
    return this.httpClient.get<Category>(url);
  }
  


}
