import { Component, OnInit } from '@angular/core';
import { Product } from './product';
import { ProductService } from './product.service';

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit {

  listAll : Product[];
  constructor(private productService: ProductService) { }



  ngOnInit(): void {
    this.productService.viewAllProducts().subscribe(data=>{
      this.listAll=JSON.parse(JSON.stringify(data));
      console.log("categorylist is : ", this.listAll);
      
    })
  }

}