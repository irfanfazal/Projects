export interface Product {
    id: string;
    name:string,
    category_id:string,
    descriptions: string,
    price:number,
    is_available:string,
    productImg:string;
    rating: string,
    review:string,
    vendor_name:string,
    waranty:string,
    color:string

}


