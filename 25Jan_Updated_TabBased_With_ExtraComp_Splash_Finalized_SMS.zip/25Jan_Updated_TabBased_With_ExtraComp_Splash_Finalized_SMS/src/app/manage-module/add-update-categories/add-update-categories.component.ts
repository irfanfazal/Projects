import { Component } from '@angular/core';

@Component({
  selector: 'app-add-update-categories',
  templateUrl: './add-update-categories.component.html',
  styleUrls: ['./add-update-categories.component.scss']
})
export class AddUpdateCategoriesComponent {

}
