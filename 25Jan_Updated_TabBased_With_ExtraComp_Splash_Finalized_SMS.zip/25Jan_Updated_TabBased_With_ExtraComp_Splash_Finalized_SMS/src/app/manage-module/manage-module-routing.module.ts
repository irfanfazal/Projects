import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AddUpdateCategoriesComponent } from './add-update-categories/add-update-categories.component';
import { AddUpdateProductsComponent } from './add-update-products/add-update-products.component';
import { ManageModuleComponent } from './manage-module.component';
import { ViewCategoriesComponent } from './view-categories/view-categories.component';
import { ViewProductsComponent } from './view-products/view-products.component';

// const routes: Routes = [
//   { path: '', component: ManageModuleComponent },
//   { path: 'add_update_categories', component: AddUpdateCategoriesComponent },
//   { path: 'add_update_products', component: AddUpdateProductsComponent },
//   { path: 'view_products', component: ViewProductsComponent },
//   { path: 'view_categories', component: ViewCategoriesComponent },

// ];


const routes: Routes = [




  { path: '', component: ManageModuleComponent, children:[

    
  { path: 'add_update_categories', component: AddUpdateCategoriesComponent, outlet:'childOutlet' },
  { path: 'add_update_products', component: AddUpdateProductsComponent, outlet:'childOutlet' },
  { path: 'view_products', component: ViewProductsComponent, outlet:'childOutlet' },
  { path: 'view_categories', component: ViewCategoriesComponent, outlet:'childOutlet' },

  ]              },


  

];




@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ManageModuleRoutingModule { }


