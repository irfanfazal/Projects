import { Component } from '@angular/core';

@Component({
  selector: 'app-add-update-products',
  templateUrl: './add-update-products.component.html',
  styleUrls: ['./add-update-products.component.scss']
})
export class AddUpdateProductsComponent {

}
