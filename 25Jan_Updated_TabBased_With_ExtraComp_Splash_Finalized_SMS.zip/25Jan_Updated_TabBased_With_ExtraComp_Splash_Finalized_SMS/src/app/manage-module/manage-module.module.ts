import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ManageModuleRoutingModule } from './manage-module-routing.module';
import { ManageModuleComponent } from './manage-module.component';
import { AddUpdateCategoriesComponent } from './add-update-categories/add-update-categories.component';
import { AddUpdateProductsComponent } from './add-update-products/add-update-products.component';
import { ViewProductsComponent } from './view-products/view-products.component';
import { ViewCategoriesComponent } from './view-categories/view-categories.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';


@NgModule({
  declarations: [
    ManageModuleComponent,
    AddUpdateCategoriesComponent,
    AddUpdateProductsComponent,
    ViewProductsComponent,
    ViewCategoriesComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    RouterModule,
    ManageModuleRoutingModule,
    HttpClientModule,
    ReactiveFormsModule,
  
  ]
})
export class ManageModuleModule { }
