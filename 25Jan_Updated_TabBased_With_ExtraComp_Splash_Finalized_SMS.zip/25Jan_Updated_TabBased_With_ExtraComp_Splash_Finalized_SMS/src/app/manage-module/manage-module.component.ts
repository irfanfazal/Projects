import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { MethodFilter, removeComponentStateFunction, State } from '../Services/component-state-management/decorator';
import { BillingUtills } from '../Services/generic/billing-utills';
import { Tab } from '../tabs';




declare let $: any;


@State({
  nameOfComponent: "ManageModuleComponent",
  properties: ["reportTabs"],
  functionsToExecuteAfterGettingState: ["afterGettingComponentState"],
  whenToGetState: MethodFilter.BeforeExecution,
  whenToSaveState: MethodFilter.AfterExecution,
})


@Component({
  selector: 'app-manage-module',
  templateUrl: './manage-module.component.html',
  styleUrls: ['./manage-module.component.scss']
})
export class ManageModuleComponent {

        arrTabs: Tab[];
        public myItems;
      
        //strings
        routeName: string = "";
        routeTitle: string = "";
        reportFilter: string = "";
        textSearch: string = "";
        //booleans
        activeTabMain: boolean = true;
        showTabPatient: boolean = false;
        reportsTab: boolean = false;
        foxPractice: boolean = false;
        //any
    
        constructor(private _route: ActivatedRoute,public router: Router) {
            this.initializeObjects();
        }
    
    

        initializeObjects() {
            this.routeName = "manage_products";
            this.routeTitle = "manage_products";
            this.activeTabMain = true;
            this.arrTabs = [];
        }    
    
        selectReportsTab() {
            let address: string = window.location.href;
            let array = BillingUtills.isNullOrUndefined(address) ? [] : address.split("/");
            if (!BillingUtills.isNullOrUndefined(array)) {
                if (array[array.length - 1] == "manage_products" && !this.reportsTab) {
                    this.reportsTab = false;
                    this.resetReportsTabs();
                }
            }
        }
    
        resetReportsTabs() {
            this.routeName = "manage_products";
            this.routeTitle = "manage_products";
            this.activeTabMain = true;

            this.showTabPatient = false;
            this.arrTabs = [];
        }
    
        resetTabs() {
          debugger;
            this.arrTabs.forEach(tab => tab.active = false);

            this.reportsTab = false;
        }
    
        selectFirstTab() {
            this.resetTabs();
            this.reportsTab = true;
            this.routeName = "manage_products";
            this.routeTitle = "manage_products";
            this.loadRoute();
        }
    
        selectTab(tab: Tab, isPatientTab: boolean = false) {
            this.resetTabs();
            tab.active = true;
            debugger;
            this.routeName = tab.route;
            this.routeTitle = tab.title;

            this.loadRoute();
        }
    
        createTab(routeName: string, routeTitle: string, callFrom: string = "") {
            debugger;
            if (BillingUtills.isStringNullOrEmpty(routeName)) {
                return;
            }
            if (BillingUtills.isNullOrUndefined(this.arrTabs)) {
                this.arrTabs = [];
            }
            if (!BillingUtills.isNullOrUndefined(this.arrTabs) && this.arrTabs.length == 10) {
                alert('You cannnot open more than 10 tabs');
                return;
            }
        

            this.resetTabs();
            if (!BillingUtills.isStringNullOrEmpty(routeName)) {
                this.routeName = routeName;
                this.routeTitle = BillingUtills.isStringNullOrEmpty(routeTitle) ? "" : routeTitle;
                this.loadRoute();
            } else {
                this.activeTabMain = true;
                console.log("Active Main Tab: "+this.activeTabMain)
            }
        }
    
        loadRoute(removeComponentRoute: string = "") {
    
          debugger;
          let link: any[] = [];
          let link2: any[] = [];
            if (this.routeName == "manage_products") {
                this.activeTabMain = true;
                link = ["/manage_products"];
            }
            else {
              
                 if (this.arrTabs.some(x => x.route == this.routeName)) {


                    this.arrTabs.find(arrayTab => arrayTab.route == this.routeName).active = true;

                    link = ["" + this.routeName];
                    
                } 
                

                
                else {
                    let newTab = new Tab();
                    newTab.route = this.routeName;
                    newTab.title = this.routeTitle;
                    newTab.active = true;
                    this.arrTabs.push(newTab);
                    
                    
                    link = ["" + this.routeName];
                }


                this.activeTabMain = false;
            }

            if (link) {
                if(link.toString()=='/manage_products')
                {
                    this.router.navigate(['/manage_products'])    
                }
                else{
                    this.router.navigate([{ outlets: { childOutlet: link } }], { relativeTo: this._route.parent });
                }

            }
        }
    
        removeTab(index: number = -1) {
            this.resetTabs();
            let removeComponentRoute: string = "";
            if (index == -1 && this.routeName == "BillingDemographics") {
                if (confirm("Information entered in this profile will be lost. Do you want to Save?")) {
                    return;
    
                } else {
                    this.routeName = "manage_products";
                    this.routeTitle = "manage_products";
                    removeComponentRoute = "";
                    this.showTabPatient = false;
                    this.reportsTab = true;
                }
            }
            if (BillingUtills.isNullOrUndefined(this.arrTabs)) {
                this.arrTabs = [];
            }
            if (index == -1 && !BillingUtills.isNullOrUndefined(this.arrTabs) && this.arrTabs.length == 0) {
                //First Tab
                this.routeName = "manage_products";
                this.routeTitle = "manage_products";
                removeComponentRoute = "";
                this.showTabPatient = false;
                this.reportsTab = true;
            } else if (!BillingUtills.isNullOrUndefined(this.arrTabs) && index != -1 && (this.arrTabs.length - 1) == 0) {
                //First Tab
                this.routeName = "manage_products";
                this.routeTitle = "manage_products";
                removeComponentRoute = this.arrTabs[this.arrTabs.length - 1].route;
                this.arrTabs.splice(0, 1);
                this.reportsTab = true;
            } else if (!BillingUtills.isNullOrUndefined(this.arrTabs) && index != -1 && index == 0) {
                //First Tab
                this.routeName = "manage_products";
                this.routeTitle = "manage_products";
                removeComponentRoute = this.arrTabs[this.arrTabs.length - 1].route;
                this.arrTabs.splice(index, 1);
                this.reportsTab = true;
            } else if (!BillingUtills.isNullOrUndefined(this.arrTabs) && index == -1 && this.arrTabs.length > 0) {
                index = this.arrTabs.length - 1;
                this.arrTabs[index].active = true;
                this.routeName = this.arrTabs[index].route;
                this.routeTitle = this.arrTabs[index].title;
                removeComponentRoute = "";
                this.showTabPatient = false;
            } else {
                this.arrTabs[index - 1].active = true;
                this.routeName = this.arrTabs[index - 1].route;
                this.routeTitle = this.arrTabs[index - 1].title;
                removeComponentRoute = this.arrTabs[index].route;
                this.arrTabs.splice(index, 1);
            }
            //this.setLoadingModules(removeComponentRoute);
            this.loadRoute(removeComponentRoute);
        }
        isActiveTab(url: string) {
            if (this.router.url.indexOf(url) !== -1 && this.router.url.includes(url)) {
                return true;
            } else {
                return false;
            }
        }
    
        removeState(routeName: string) {
            if (!routeName) return;
            routeName = routeName.replace("/", "");
            let componentName = "";
            componentName = routeName + "Component";
            removeComponentStateFunction(componentName);
        }
    
        ifShowLink(linkText: string): boolean {
            let patt1 = /\S+\s+/i;
            let patt2 = /\S+/g;
            let result = this.textSearch.match(patt1);
            let result2 = this.textSearch.match(patt2);
            if (result2 == null && result == null) return true;
            else if (linkText.toLowerCase().indexOf(this.textSearch.toLowerCase()) > -1) {
                if (linkText == "Improvement Activities") return false;
                return true;
            }
            else return false;
        }
    
        ifShowHeading(Arr: Array<string>): number {
            if (!BillingUtills.isNullOrUndefined(Arr)) {
                for (let j = 0; j < Arr.length; j++) {
                    let patt1 = /\S+\s+/i;
                    let patt2 = /\S+/g;
                    let result = this.textSearch.match(patt1);
                    let result2 = this.textSearch.match(patt2);
                    if (result2 == null && result == null) return 1;
                    if (Arr[j].toLocaleLowerCase().indexOf(this.textSearch.toLowerCase()) > -1) { return j; }
                }
            }
            return -1;
        }    


}
