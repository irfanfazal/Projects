import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { BillingRoutingModule } from './billing-routing.module';
import { BillingComponent } from './billing.component';
import { AddUpdateSaleComponent } from './add-update-sale/add-update-sale.component';
import { AddUpdateCartComponent } from './add-update-cart/add-update-cart.component';


@NgModule({
  declarations: [
    BillingComponent,
    AddUpdateSaleComponent,
    AddUpdateCartComponent
  ],
  imports: [
    CommonModule,
    BillingRoutingModule
  ]
})
export class BillingModule { }
