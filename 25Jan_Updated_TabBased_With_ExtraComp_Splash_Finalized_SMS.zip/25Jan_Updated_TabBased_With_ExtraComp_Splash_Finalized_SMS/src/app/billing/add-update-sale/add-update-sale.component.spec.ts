import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddUpdateSaleComponent } from './add-update-sale.component';

describe('AddUpdateSaleComponent', () => {
  let component: AddUpdateSaleComponent;
  let fixture: ComponentFixture<AddUpdateSaleComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddUpdateSaleComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AddUpdateSaleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
