import { Component } from '@angular/core';

@Component({
  selector: 'app-add-update-sale',
  templateUrl: './add-update-sale.component.html',
  styleUrls: ['./add-update-sale.component.scss']
})
export class AddUpdateSaleComponent {

}
