import { Component } from '@angular/core';

@Component({
  selector: 'app-add-update-cart',
  templateUrl: './add-update-cart.component.html',
  styleUrls: ['./add-update-cart.component.scss']
})
export class AddUpdateCartComponent {

}
