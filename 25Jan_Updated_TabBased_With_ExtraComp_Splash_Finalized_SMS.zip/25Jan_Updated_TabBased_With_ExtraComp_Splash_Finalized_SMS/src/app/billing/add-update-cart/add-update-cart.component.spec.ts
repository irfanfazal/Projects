import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddUpdateCartComponent } from './add-update-cart.component';

describe('AddUpdateCartComponent', () => {
  let component: AddUpdateCartComponent;
  let fixture: ComponentFixture<AddUpdateCartComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddUpdateCartComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AddUpdateCartComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
