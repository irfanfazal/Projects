import { Component, OnDestroy, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Tab } from './tabs';
import { MethodFilter, removeComponentStateFunction, State } from './Services/component-state-management/decorator';
import { BillingUtills } from './Services/generic/billing-utills';


declare var $: any;

@State({
    nameOfComponent: "ReportMainComponent",
    properties: ["reportTabs"],
    functionsToExecuteAfterGettingState: ["afterGettingComponentState"],
    whenToGetState: MethodFilter.BeforeExecution,
    whenToSaveState: MethodFilter.AfterExecution,
})

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {

    public myItems;
    public title="Title in AppComponent"
    
    constructor(public router: Router, private _route: ActivatedRoute) {

    }


    
    ngOnInit(): void {
        // let data=this._route.snapshot.data['myItems']
        //   .subscribe(res => {
        //     this.myItems = res;
        //   })

        //   console.log("Data is : "+data);
      }



  
}
