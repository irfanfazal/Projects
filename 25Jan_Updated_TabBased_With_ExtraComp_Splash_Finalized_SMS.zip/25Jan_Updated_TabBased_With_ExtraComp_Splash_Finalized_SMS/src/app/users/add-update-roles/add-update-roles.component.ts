import { Component } from '@angular/core';

@Component({
  selector: 'app-add-update-roles',
  templateUrl: './add-update-roles.component.html',
  styleUrls: ['./add-update-roles.component.scss']
})
export class AddUpdateRolesComponent {

}
