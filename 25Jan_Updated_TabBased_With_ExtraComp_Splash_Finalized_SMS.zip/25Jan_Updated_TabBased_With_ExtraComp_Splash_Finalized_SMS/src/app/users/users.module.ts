import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { UsersRoutingModule } from './users-routing.module';
import { UsersComponent } from './users.component';
import { AddUpdateUsersComponent } from './add-update-users/add-update-users.component';
import { AddUpdateRolesComponent } from './add-update-roles/add-update-roles.component';
import { ViewRolesComponent } from './view-roles/view-roles.component';
import { SalesReportComponent } from './sales-report/sales-report.component';


@NgModule({
  declarations: [
    UsersComponent,
    AddUpdateUsersComponent,
    AddUpdateRolesComponent,
    ViewRolesComponent,
    SalesReportComponent
  ],
  imports: [
    CommonModule,
    UsersRoutingModule
  ]
})
export class UsersModule { }
