
export class ExternalSourceLoginResponse {
    public EXTERNAL_USER_ID: number;
    public USER_NAME: string;
    public EMAIL: string;
    public DESIGNATION: string;
    public PASSWORDS: string;
    public FILE_CABINET: string;
    public STATUS: string;
    public EXTERNAL_SOURCE_ID: number;
    public EXTERNAL_SOURCE_NAME: string;
    public FLAG: string;
}

export class ExternalSourceLoginRequest {
    USER_ID: string;
    PRACTICE_CODE: string;
    constructor() {
        this.USER_ID = '';
        this.PRACTICE_CODE = '';
    }
}

export class ExternalSourceLoginLogReq {
    public External_Login_Id: number;
    public Created_By: string;
}

export class Flag {
    private static _S1: string = '&8/gi';
    private static _S2: string = '%6/gr';
    private static _S3: string = '@4/lk';
    private static _S4: string = '*2/Lt';
    private static _S5: string = '$9+cr';
    private static _L1: string = '#q+0y';
    private static _L2: string = '+l=7j';
    private static _L3: string = '^m-4r';
    private static _L4: string = '!i+1d';
    private static _L5: string = '#g+7q';
    static get S1() { return this._S1; }
    static get S2() { return this._S2; }
    static get S3() { return this._S3; }
    static get S4() { return this._S4; }
    static get S5() { return this._S5; }
    static get L1() { return this._L1 }
    static get L2() { return this._L2 }
    static get L3() { return this._L3 }
    static get L4() { return this._L4 }
    static get L5() { return this._L5 }
}