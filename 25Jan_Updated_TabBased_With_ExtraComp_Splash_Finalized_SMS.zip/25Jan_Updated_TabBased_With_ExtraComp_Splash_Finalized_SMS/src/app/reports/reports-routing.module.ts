import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ReportsComponent } from './reports.component';
import { SalesReportComponent } from './sales-report/sales-report.component';
import { UsersReportComponent } from './users-report/users-report.component';

const routes: Routes = [
  
  { path: '', component: ReportsComponent },
  { path: 'salesreport', component: SalesReportComponent },
  { path: 'usersreport', component: UsersReportComponent },

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ReportsRoutingModule { }
