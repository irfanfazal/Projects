import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ReportsRoutingModule } from './reports-routing.module';
import { ReportsComponent } from './reports.component';
import { SalesReportComponent } from './sales-report/sales-report.component';
import { ProductsReportComponent } from './products-report/products-report.component';
import { UsersReportComponent } from './users-report/users-report.component';


@NgModule({
  declarations: [
    ReportsComponent,
    SalesReportComponent,
    ProductsReportComponent,
    UsersReportComponent
  ],
  imports: [
    CommonModule,
    ReportsRoutingModule
  ]
})
export class ReportsModule { }
