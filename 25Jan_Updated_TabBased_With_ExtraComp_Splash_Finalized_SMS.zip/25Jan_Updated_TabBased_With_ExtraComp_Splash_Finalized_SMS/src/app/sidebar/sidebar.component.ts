import { Component } from '@angular/core';

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.scss']
})
export class SidebarComponent {

  myArray: {image: string, name: string, link:string}[]
  

ngOnInit()
{

this.myArray=[
  {image: 'home.png', name: 'Home',link:'dashboard'},
  {image: 'manage_products.png', name: 'Manage Products',link:'manage_products'},
  {image: 'Manage_Users.png', name: 'Mange Users',link:'users'},
  {image: 'Reporting.png', name: 'Reporting',link:'reports'},
  {image: 'Setup.png', name: 'Setup',link:'users'}
];
}


  
}
