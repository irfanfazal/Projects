import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { SplashScreenStateService } from '../splash-screen-state.service';


@Injectable()
export class HomepageResolver implements Resolve<any> {

  public ary:Array<string>=[];

  constructor(private splashScreenStateService: SplashScreenStateService) {

    this.ary=["as","df","gh"];




   }


  public resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Promise<Observable<any>> {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        this.splashScreenStateService.stop();
      //  resolve(of(['item1', 'item2']));
      
      resolve(of(this.ary));
    
    
    }, 1000);
    });
  }

}
