export class Tab {
    patAccount: any;
    title: string;
    active: boolean;
    //Billing
    claimNumber: any;
    route: string;
    tabId: string;
    constructor() {
        this.patAccount = 0;
        this.active = false;
        //Billing
        this.claimNumber = 0;
        this.title = "";
        this.route = "";
    }
       
}