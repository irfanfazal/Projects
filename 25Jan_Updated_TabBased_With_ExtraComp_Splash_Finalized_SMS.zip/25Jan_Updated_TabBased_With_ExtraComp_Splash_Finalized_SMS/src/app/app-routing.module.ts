import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AppComponent } from './app.component';
import { BillingAgingComponent } from './billing-aging/billing-aging.component';
import { ClaimStatusComponent } from './claim-status/claim-status.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { MonthEndComponent } from './month-end/month-end.component';
import { HomepageComponent } from './pages/homepage/homepage.component';
import { HomepageResolver } from './resolvers/homepage.resolver';
import { TabCompComponent } from './tab-comp/tab-comp.component';


const routes: Routes = [

  {
  path: '',
  redirectTo: 'dashboard',
  pathMatch: 'full'
},

// { path: 'ReportMain', component: TabCompComponent,resolve: {'itemsList2': HomepageResolver},
{ path: 'ReportMain', component: TabCompComponent,
  children:[
    {path:'BillingAging',component:BillingAgingComponent},
    {path:'BillingAgingClaimStatus',component:ClaimStatusComponent},
    {path:'BillingMonthEndAging',component:MonthEndComponent}
  ]
},


  {path:'dashboard', component: DashboardComponent},

  { path: 'manage_products', loadChildren: () => import('./manage-module/manage-module.module').then(m => m.ManageModuleModule) },

  { path: 'users', loadChildren: () => import('./users/users.module').then(m => m.UsersModule) },

  { path: 'reports', loadChildren: () => import('./reports/reports.module').then(m => m.ReportsModule) },

  { path: 'billing', loadChildren: () => import('./billing/billing.module').then(m => m.BillingModule) },

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
