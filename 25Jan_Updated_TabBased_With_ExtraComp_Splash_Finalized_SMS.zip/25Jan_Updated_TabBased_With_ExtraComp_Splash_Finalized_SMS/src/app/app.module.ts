import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { RouterModule } from '@angular/router';
import { AFUtillsService } from './afutills.service';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BillingAgingComponent } from './billing-aging/billing-aging.component';
import { ClaimStatusComponent } from './claim-status/claim-status.component';
import { MonthEndComponent } from './month-end/month-end.component';
import { SplashScreenStateService } from './splash-screen-state.service';
import { TabCompComponent } from './tab-comp/tab-comp.component';
import { SplashComponent } from './splashcomponent/splash/splash.component';
import { HomepageResolver } from './resolvers/homepage.resolver';
import { HomepageComponent } from './pages/homepage/homepage.component';
import { SidebarComponent } from './sidebar/sidebar.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { FooterComponent } from './footer/footer.component';



@NgModule({
  declarations: [
    AppComponent,
    BillingAgingComponent,
    ClaimStatusComponent,
    MonthEndComponent,
    TabCompComponent,
    SplashComponent,
    HomepageComponent,
    SidebarComponent,
    DashboardComponent,
    FooterComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    BrowserModule,
    RouterModule,
    HttpClientModule,
    ReactiveFormsModule,
    AppRoutingModule,
  
  ],
  providers: [AFUtillsService,SplashScreenStateService,HomepageResolver],
  bootstrap: [AppComponent]
})
export class AppModule { }
