import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BillingAgingComponent } from './billing-aging.component';

describe('BillingAgingComponent', () => {
  let component: BillingAgingComponent;
  let fixture: ComponentFixture<BillingAgingComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BillingAgingComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(BillingAgingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
