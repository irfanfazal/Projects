﻿function ShowHidePopups(elementToHide, elementToShow)
{
    if (elementToHide !== "" && elementToShow !== "" && elementToHide !== "undefined" && elementToShow !== "undefined")
    {
        $("#" + elementToHide + "").css("display", "none"); $("#" + elementToShow + "").css("display", "block");
    }
}