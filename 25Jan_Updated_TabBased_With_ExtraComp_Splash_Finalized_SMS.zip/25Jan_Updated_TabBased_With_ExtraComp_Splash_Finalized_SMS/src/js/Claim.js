

//  =======Page Modal/Popup Style=======//

$("#amazing-fusion .modal-page .modal-right .close-panel a").click(function (e) {
    $("#amazing-fusion .modal-page .modal-dialog .modal-left").toggle('slow');
    $("#amazing-fusion .modal-page .modal-right .close-panel a i").toggleClass("app-icon-IconSet-1-70");
});