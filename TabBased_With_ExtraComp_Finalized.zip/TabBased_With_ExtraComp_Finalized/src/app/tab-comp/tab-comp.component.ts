import { Component, OnDestroy, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Tab } from '../tabs';
import { MethodFilter, removeComponentStateFunction, State } from '../Services/component-state-management/decorator';
import { BillingUtills } from '../Services/generic/billing-utills';


declare var $: any;


@State({
  nameOfComponent: "ReportMainComponent",
  properties: ["reportTabs"],
  functionsToExecuteAfterGettingState: ["afterGettingComponentState"],
  whenToGetState: MethodFilter.BeforeExecution,
  whenToSaveState: MethodFilter.AfterExecution,
})

@Component({
  selector: 'app-tab-comp',
  templateUrl: './tab-comp.component.html',
  styleUrls: ['./tab-comp.component.scss']
})
export class TabCompComponent implements OnInit, OnDestroy{

        //objects
        objPatientTab: Tab;
        //arrays
        arrTabs: Tab[];
      
        //strings
        routeName: string = "";
        routeTitle: string = "";
        reportFilter: string = "";
        textSearch: string = "";
        //booleans
        activeTabMain: boolean = true;
        showTabPatient: boolean = false;
        reportsTab: boolean = false;
        foxPractice: boolean = false;
        //any
    
        constructor(private _router: Router, private _route: ActivatedRoute,public router: Router) {
            this.initializeObjects();
        }
    
      ngOnInit() {
      
      }
    
      ngOnDestroy() {
        
      }  
    
        afterGettingComponentState() {
    
        }
    
        ngAfterViewChecked() {
    
        }

        initializeObjects() {
            this.routeName = "ReportMain";
            this.routeTitle = "Reports";
            this.activeTabMain = true;
            this.objPatientTab = new Tab();
            this.objPatientTab.title = "Patient Details";
            this.arrTabs = [];
        }    
    
        selectReportsTab() {
            let address: string = window.location.href;
            var array = BillingUtills.isNullOrUndefined(address) ? [] : address.split("/");
            if (!BillingUtills.isNullOrUndefined(array)) {
                if (array[array.length - 1] == "ReportMain" && !this.reportsTab) {
                    this.reportsTab = false;
                    this.resetReportsTabs();
                }
            }
        }
    
        resetReportsTabs() {
            this.routeName = "ReportMain";
            this.routeTitle = "Reports";
            this.activeTabMain = true;
            this.objPatientTab = new Tab();
            this.objPatientTab.title = "Patient Details";
            this.showTabPatient = false;
            this.arrTabs = [];
        }
    
        resetTabs() {
          debugger;
            this.arrTabs.forEach(tab => tab.active = false);
        //    this.activeTabMain = false;
          //  this.objPatientTab.active = false;
            this.reportsTab = false;
        }
    
        selectFirstTab() {
            this.resetTabs();
            this.reportsTab = true;
            this.routeName = "ReportMain";
            this.routeTitle = "Reports";
            this.loadRoute();
        }
    
        selectTab(tab: Tab, isPatientTab: boolean = false) {
            this.resetTabs();
            tab.active = true;
            this.routeName = tab.route;
            this.routeTitle = tab.title;
  
    
            // if (isPatientTab) {
            //     this.routeName = BillingUtills.routePatientTab;
            // }
            this.loadRoute();
        }
    
        createTab(routeName: string, routeTitle: string, callFrom: string = "") {
            debugger;
            if (BillingUtills.isStringNullOrEmpty(routeName)) {
                return;
            }
            if (BillingUtills.isNullOrUndefined(this.arrTabs)) {
                this.arrTabs = [];
            }
            if (!BillingUtills.isNullOrUndefined(this.arrTabs) && this.arrTabs.length == 10) {
                alert('You cannnot open more than 10 tabs');
                return;
            }
            // if (routeName == "BillingClaim") {
            //     if (BillingUtills.routePatientAccount == "0" || BillingUtills.isStringNullOrEmpty(BillingUtills.routePatientAccount)) {
            //         return;
            //     }
            // }
            this.resetTabs();
            if (!BillingUtills.isStringNullOrEmpty(routeName)) {
                this.routeName = routeName;
                this.routeTitle = BillingUtills.isStringNullOrEmpty(routeTitle) ? "" : routeTitle;
                this.loadRoute();
            } else {
                this.activeTabMain = true;
                console.log("Active Main Tab: "+this.activeTabMain)
            }
        }
    
        loadRoute(removeComponentRoute: string = "") {
    
            let link: any[] = [];
            if (this.routeName == "ReportMain") {
                this.activeTabMain = true;
                link = ["/ReportMain"];
            }
            else {
              
                if (this.routeName == "BillingClaim" || this.routeName == "BillingDemographics" || this.routeName == "NewDemographics" ||
                    this.routeName == "BillingClaimSummary" || this.routeName == "BillingPatientLedger") {
                    this.objPatientTab.active = true;
                    this.objPatientTab.route = this.routeName;
                    this.showTabPatient = true;
                    if (this.routeName == "BillingClaim") {
                      //  link = ["/ReportMain/BillingClaim", BillingUtills.isStringNullOrEmpty(BillingUtills.routePatientAccount) ? "0" : BillingUtills.routePatientAccount, BillingUtills.isStringNullOrEmpty(BillingUtills.routeClaimNo) ? "0" : BillingUtills.routeClaimNo];
                    } else if (this.routeName == "BillingDemographics") {
                      //  link = ["/ReportMain/BillingDemographics", BillingUtills.isStringNullOrEmpty(BillingUtills.routePatientAccount) ? "0" : BillingUtills.routePatientAccount];
                    } else if (this.routeName == "NewDemographics") {
                        link = ["/ReportMain/BillingDemographics", 0];
                    } else if (this.routeName == "BillingClaimSummary") {
                      //  link = ["/ReportMain/BillingClaimSummary", BillingUtills.isStringNullOrEmpty(BillingUtills.routePatientAccount) ? "0" : BillingUtills.routePatientAccount];
                    } else if (this.routeName == "BillingPatientLedger") {
                    //    link = ["/ReportMain/BillingPatientLedger", BillingUtills.isStringNullOrEmpty(BillingUtills.routePatientAccount) ? "0" : BillingUtills.routePatientAccount];
                    }
                } else if (this.arrTabs.some(x => x.route == this.routeName)) {
                    this.arrTabs.find(arrayTab => arrayTab.route == this.routeName).active = true;
                    if (this.routeName == "BillingSecureSupport") {
                      //  link = ["/ReportMain/BillingSecureSupport", BillingUtills.isStringNullOrEmpty(BillingUtills.routeCaseNo) ? "0" : BillingUtills.routeCaseNo, BillingUtills.isStringNullOrEmpty(BillingUtills.routeClaimNo) ? "0" : BillingUtills.routeClaimNo];
                    } else if (this.routeName == "BillingDepositSlip") {
                    //    link = ["/ReportMain/BillingDepositSlip", BillingUtills.routeDSId, BillingUtills.routeDSPracticeCode];
                    } else {
                        link = ["/ReportMain/" + this.routeName];
                    }
                } 
                

                
                else {
                    var newTab = new Tab();
                    newTab.route = this.routeName;
                    newTab.title = this.routeTitle;
                    newTab.active = true;
                    this.arrTabs.push(newTab);
                    if (this.routeName == "BillingSecureSupport") {
                    //    link = ["/ReportMain/BillingSecureSupport", BillingUtills.isStringNullOrEmpty(BillingUtills.routeCaseNo) ? "0" : BillingUtills.routeCaseNo, BillingUtills.isStringNullOrEmpty(BillingUtills.routeClaimNo) ? "0" : BillingUtills.routeClaimNo];
                    } else if (this.routeName == "BillingDepositSlip") {
                    //    link = ["/ReportMain/BillingDepositSlip", BillingUtills.routeDSId, BillingUtills.routeDSPracticeCode];
                    } 
                    
                    
                    
                    else
                        link = ["/ReportMain/" + this.routeName];
                }


                this.activeTabMain = false;
            }
            if (link) {
                let reset = this.resetGlobalValues(this.routeName);
                this._router.navigate(link).then(_ => {
                    if (removeComponentRoute) {
                        this.removeState(removeComponentRoute);
                    }
                });
            }
            console.log("Active Main Tab: "+this.activeTabMain)
        }
    
        removeTab(index: number = -1) {
            this.resetTabs();
            let removeComponentRoute: string = "";
            if (index == -1 && this.routeName == "BillingDemographics") {
                if (confirm("Information entered in this profile will be lost. Do you want to Save?")) {
                    return;
    
                } else {
                    this.routeName = "ReportMain";
                    this.routeTitle = "Reports";
                    removeComponentRoute = "";
                    this.showTabPatient = false;
                    this.reportsTab = true;
                }
            }
            if (BillingUtills.isNullOrUndefined(this.arrTabs)) {
                this.arrTabs = [];
            }
            if (index == -1 && !BillingUtills.isNullOrUndefined(this.arrTabs) && this.arrTabs.length == 0) {
                //First Tab
                this.routeName = "ReportMain";
                this.routeTitle = "Reports";
                removeComponentRoute = "";
                this.showTabPatient = false;
                this.reportsTab = true;
            } else if (!BillingUtills.isNullOrUndefined(this.arrTabs) && index != -1 && (this.arrTabs.length - 1) == 0) {
                //First Tab
                this.routeName = "ReportMain";
                this.routeTitle = "Reports";
                removeComponentRoute = this.arrTabs[this.arrTabs.length - 1].route;
                this.arrTabs.splice(0, 1);
                this.reportsTab = true;
            } else if (!BillingUtills.isNullOrUndefined(this.arrTabs) && index != -1 && index == 0) {
                //First Tab
                this.routeName = "ReportMain";
                this.routeTitle = "Reports";
                removeComponentRoute = this.arrTabs[this.arrTabs.length - 1].route;
                this.arrTabs.splice(index, 1);
                this.reportsTab = true;
            } else if (!BillingUtills.isNullOrUndefined(this.arrTabs) && index == -1 && this.arrTabs.length > 0) {
                index = this.arrTabs.length - 1;
                this.arrTabs[index].active = true;
                this.routeName = this.arrTabs[index].route;
                this.routeTitle = this.arrTabs[index].title;
                removeComponentRoute = "";
                this.showTabPatient = false;
            } else {
                this.arrTabs[index - 1].active = true;
                this.routeName = this.arrTabs[index - 1].route;
                this.routeTitle = this.arrTabs[index - 1].title;
                removeComponentRoute = this.arrTabs[index].route;
                this.arrTabs.splice(index, 1);
            }
            //this.setLoadingModules(removeComponentRoute);
            this.loadRoute(removeComponentRoute);
        }
    
        isActiveTab(url: string) {
            if (this._router.url.indexOf(url) !== -1 && this._router.url.includes(url)) {
                return true;
            } else {
                return false;
            }
        }
    
        resetGlobalValues(routeName: string): boolean {
            return true;
        }
    
        removeState(routeName: string) {
            if (!routeName) return;
            routeName = routeName.replace("/", "");
            let componentName = "";
            componentName = routeName + "Component";
            removeComponentStateFunction(componentName);
        }
    
        ifShowLink(linkText: string): boolean {
            var patt1 = /\S+\s+/i;
            var patt2 = /\S+/g;
            var result = this.textSearch.match(patt1);
            var result2 = this.textSearch.match(patt2);
            if (result2 == null && result == null) return true;
            else if (linkText.toLowerCase().indexOf(this.textSearch.toLowerCase()) > -1) {
                if (linkText == "Improvement Activities") return false;
                return true;
            }
            else return false;
        }
    
        ifShowHeading(Arr: Array<string>): number {
            if (!BillingUtills.isNullOrUndefined(Arr)) {
                for (var j = 0; j < Arr.length; j++) {
                    var patt1 = /\S+\s+/i;
                    var patt2 = /\S+/g;
                    var result = this.textSearch.match(patt1);
                    var result2 = this.textSearch.match(patt2);
                    if (result2 == null && result == null) return 1;
                    if (Arr[j].toLocaleLowerCase().indexOf(this.textSearch.toLowerCase()) > -1) { return j; }
                }
            }
            return -1;
        }
    
    
    
    
    
    
    
    
    
    
}
