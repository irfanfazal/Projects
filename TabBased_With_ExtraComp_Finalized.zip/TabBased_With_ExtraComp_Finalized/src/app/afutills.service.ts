import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpResponse } from '@angular/common/http';
import { DatePipe } from '@angular/common';
import { Observable, throwError } from 'rxjs';
import { map, catchError } from 'rxjs/operators';
import * as bigInt from 'json-bigint';
import * as _ from "lodash";
import * as moment from 'moment';

declare var $: any;
@Injectable({
  providedIn: 'root'
})
export class AFUtillsService {
  private myDomain: string;
  // coolHttp: CoolHttp;
  headers: HttpHeaders;
  private myUrl: string;
  domainUtills = new DomainUtills();
  baseUrl = new BaseUrl();
  constructor(public http: HttpClient) {
      this.myDomain = this.domainUtills.GetDomain();
      this.headers = this.getHeaders();
      //this.coolHttp = coolHttp;
      //this.coolHttp._globalHeaders = [];
      //coolHttp.registerGlobalHeader(new HttpHeader('Token', localStorage.getItem("AuthToken")));
      //coolHttp.registerGlobalHeader(new HttpHeader('Content-Type', 'application/json; charset=UTF-8'));
      //coolHttp.registerGlobalHeader(new HttpHeader('Accept', 'application/json'));
      //coolHttp.registerResponseInterceptor({
      //    afterResponseAsync: function (response) {
      //        return new Promise((resolve) => {
      //            if (response.status == 401) {
      //                localStorage.clear();
      //                window.location.href = window.location.origin + '/StagingAccount/SecureLogin';

      //            } else {
      //                resolve(false);
      //            }
      //        });
      //    }
      //});
      //if (localStorage.getItem("AuthToken") == null) {
      //    window.location.href = 'http://localhost:33541/StagingAccount/SecureLogin';
      //}
      //
  }
  // PARAMETERS
  // 1:-> callType   [post/get]
  // 2:-> controlerActionName    Patient/GetPatientDemographics
  // 3:-> token   '4dc8ee08-1e89-f624-4ead-a569e48c478e'
  // 4:-> data    any type
  GenericServiceCallMethod(callType: string, controlerActionName: string, token: string, data: any): any {
      let myUrl = "";
      let myCallType = "";
      if (callType != "" && controlerActionName != "") {
          // MAKING COMPLETE URL ,  SETTING CALL TYPE [POST / GET]  AND MAKING HEADERS
          $("#spinnerLoaderXhr").show();
          myUrl = this.myDomain + controlerActionName;
          myCallType = callType;
          this.headers = this.headers.set('Request-Date', new Date().toLocaleString());

          if (myCallType == "post") {
              if (data != null) {
                  return this.http.post(myUrl, data, { responseType: 'text', headers: this.headers }).pipe(
                      map((res) => {
                          $("#spinnerLoaderXhr").hide();
                          return bigInt.parse(res);
                      }),
                      catchError(e => {
                          $("#spinnerLoaderXhr").hide();
                          if (e.status === 401) {
                              localStorage.clear();
                              window.location.href = window.location.origin + '/StagingAccount/SecureLogin';
                              return throwError(new Error('Unauthorized'));
                          }
                          else {
                              return throwError(e);
                          }
                      }));
              }
              else {
                  return JSON.stringify("Please send data");
              }
          }
          else if (myCallType == "get") {
              return this.http.get(myUrl, { responseType: 'text', headers: this.headers }).pipe(
                  map((res) => {
                      $("#spinnerLoaderXhr").hide();
                      return bigInt.parse(res);
                  }),
                  catchError(e => {
                      $("#spinnerLoaderXhr").hide();
                      if (e.status === 401) {
                          localStorage.clear();
                          window.location.href = window.location.origin + '/StagingAccount/SecureLogin';
                          return throwError(new Error('Unauthorized'));
                      }
                      else {
                          return throwError(e);
                      }
                  }));
          }
          else {
              return JSON.stringify("Please enter a valid call type [post get]");
          }
      } else {
          return JSON.stringify("Controler/Action name or type [post get] required");
      }
  }
  //Generic External Caller Start
  GenericExternalServiceCaller(callType: string, URL: string, data: any): any {

      let myCallType = "";
      if (callType != "" && URL != "") {
          myCallType = callType;
          if (myCallType == "post") {
              if (data != null) {
                  return this.http.post(URL, JSON.stringify(data), { headers: this.headers }).pipe(
                      map((res) => {
                          return bigInt.parse(JSON.stringify(res));
                      }));
              }
              else {
                  return JSON.stringify("Please send data");
              }
          }
          else if (myCallType == "get") {
              return this.http.get(URL);
          }
          else {
              return JSON.stringify("Please enter a valid call type [post get]");
          }
      } else {
          return JSON.stringify("Controler/Action name or type [post get] required");
      }
  }
  //Generic External Caller End
  //Export - Start
  GenericServiceCallMethodForExport(callType: string, controlerActionName: string, token: string, data: any): any {

      //Testing Purpse
      let myUrl = "";
      let myCallType = "";
      if (callType != "" && controlerActionName != "") {
          // MAKING COMPLETE URL ,  SETTING CALL TYPE [POST / GET]  AND MAKING HEADERS
          myUrl = this.baseUrl.ApplicationUrl + controlerActionName;
          myCallType = callType;
          if (myCallType == "post") {
              if (data != null) {
                  return this.http.post(myUrl, JSON.stringify(data), { headers: this.headers });
              }
              else {
                  return JSON.stringify("Please send data");
              }
          }
          else if (myCallType == "get") {
              return this.http.get(myUrl, { headers: this.headers });
          }
          else {
              return JSON.stringify("Please enter a valid call type [post get]");
          }
      } else {
          return JSON.stringify("Controler/Action name or type [post get] required");
      }
  }
  //Export - End
  //Billing Files Upload Start
  GenericServiceCallMethodForUpload(controlerActionName: string, data: FormData): Observable<any> {
      return Observable.create(observer => {
          let formData: FormData = data,
              xhr: XMLHttpRequest = new XMLHttpRequest();
          xhr.onreadystatechange = () => {
              if (xhr.readyState === 4) {
                  if (xhr.status === 200) {
                      observer.next(JSON.parse(xhr.response));
                      observer.complete();
                  } else {
                      observer.error(xhr.response);
                  }
              }
          };
          //xhr.upload.onprogress = (event) => {
          //    this.progress = Math.round(event.loaded / event.total * 100);
          //    this.progressObserver.next(this.progress);
          //};

          xhr.open('POST', this.myDomain + controlerActionName, true);
          xhr.setRequestHeader('Token', this.headers.get("Token"));
          xhr.send(formData);
      });
  }
  //Billing Files Upload End

  //Generic Service without wait for api response
  GenericServiceLongCallMethod(callType: string, controlerActionName: string, token: string, data: any): any {
      let myUrl = "";
      let myCallType = "";
      if (callType != "" && controlerActionName != "") {
          // MAKING COMPLETE URL ,  SETTING CALL TYPE [POST / GET]  AND MAKING HEADERS
          myUrl = this.myDomain + controlerActionName;
          myCallType = callType;
          this.headers = this.headers.set('Request-Date', new Date().toLocaleString());

          if (myCallType == "post") {
              if (data != null && data != undefined) {
                  return this.http.post(myUrl, data, { responseType: 'text', headers: this.headers }).pipe(
                      map((res) => {
                          return bigInt.parse(res);
                      }),
                      catchError(e => {
                          if (e.status === 401) {
                              localStorage.clear();
                              window.location.href = window.location.origin + '/StagingAccount/SecureLogin';
                              return throwError(new Error('Unauthorized'));
                          }
                          else {
                              return throwError(e);
                          }
                      })).subscribe();
              }
              else {
                  return JSON.stringify("Please send data");
              }
          }
          else if (myCallType == "get") {
              return this.http.get(myUrl, { responseType: 'text', headers: this.headers }).pipe(
                  map((res) => {
                      return bigInt.parse(res);
                  }),
                  catchError(e => {
                      if (e.status === 401) {
                          localStorage.clear();
                          window.location.href = window.location.origin + '/StagingAccount/SecureLogin';
                          return throwError(new Error('Unauthorized'));
                      }
                      else {
                          return throwError(e);
                      }
                  })).subscribe();
          }
          else {
              return JSON.stringify("Please enter a valid call type [post get]");
          }
      } else {
          return JSON.stringify("Controler/Action name or type [post get] required");
      }
  }
  //Generic Service without wait for api response end

  private getHeaders() {
      let headers = new HttpHeaders();
      headers = headers.append('Access-Control-Allow-Origin', '*');
      headers = headers.append("Access-Control-Allow-Credentials", "true");
      headers = headers.append('Access-Control-Allow-Headers', '*');
      headers = headers.append('Token', localStorage.getItem("AuthToken"));
      headers = headers.append('serverID', localStorage.getItem("siteId"));
      headers = headers.append('Content-Type', 'application/json; charset=UTF-8');
      headers = headers.append('Accept', 'application/json');
      headers = headers.append('Request-Date', new Date().toLocaleString())
      return headers;
  }
  public getLocalDate(UTCDate: Date) {
      var date = UTCDate.toDateString() + ' ' + UTCDate.toTimeString().substring(0, 8) + ' UTC';
      return new Date(date)
  }
  public insertActivityLog(logFor: string, logMessage: string) {
      let objRequest = new ClientActivityLog();
      objRequest.logFor = logFor;
      objRequest.logMessage = logMessage;
      //this.GenericServiceCallMethod("post", "Log/InserActivityLog", "", "");
      return this.http.post(this.myDomain + "Log/InserActivityLog", objRequest, { headers: this.headers }).subscribe((res) => { }, (err) => {
          if (err.status === 401) {
              localStorage.clear();
              window.location.href = window.location.origin + '/StagingAccount/SecureLogin';
              return throwError(new Error('Unauthorized'));
          }
                // rerturn 0 added by HZ15
      return 0;
      }, () => { });
  }
  //public getClock() {
  //    //this.GenericServiceCallMethod("post", "Log/InserActivityLog", "", "");
  //    return this.http.get("/Setting/GetServerTime", { headers: this.headers }).toPromise().catch(e => {
  //        if (e.status === 401) {
  //            localStorage.clear();
  //            window.location.href = window.location.origin + '/StagingAccount/SecureLogin';
  //            return throwError(new Error('Unauthorized'));
  //        }
  //    });
  //}

  getClock() {
      return this.http.get("/Setting/GetServerTime", { headers: this.headers }).toPromise().catch(e => {
          if (e.status === 401) {
              localStorage.clear();
              window.location.href = window.location.origin + '/StagingAccount/SecureLogin';
              return throwError(new Error('Unauthorized'));
          };
                // rerturn 0 added by HZ15
      return 0;
      });
  }
  //downloadFile(fileId: string): Observable<File> {
  //    let url = ""; //`${APIConfig.BaseUrl}/documents/download/${fileId}/`;

  //    let headers = new Headers({ 'Content-Type': 'application/json', 'MyApp-Application' : 'AppName', 'Accept': 'application/json' });
  //    let options = new RequestOptions({ headers: headers, responseType: ResponseContentType.Blob });

  //    return this.http.post(url, '', options)
  //        .map(this.extractContent)
  //        .catch(this.handleError);
  //}
  //private extractContent(res: Response) {
  //    let  blob: Blob = res.blob();
  //    window['saveAs'](blob, 'test.pdf');
  //}
  public setCookie(name: string, value: string, expireDays: number, path: string = "") {
      let d: Date = new Date();
      d.setTime(d.getTime() + expireDays * 24 * 60 * 60 * 1000);
      let expires: string = "expires=" + d.toUTCString();
      document.cookie = name + "=" + value + "; " + expires + (path.length > 0 ? "; path=" + path : "");
  }
  public deleteCookie(name) {
      this.setCookie(name, "", -1, "/");
  }
  public getCookie(name: string) {
      let ca: Array<string> = document.cookie.split(';');
      let caLen: number = ca.length;
      let cookieName = name + "=";
      let c: string;

      for (let i: number = 0; i < caLen; i += 1) {
          c = ca[i].replace(/^\s\+/g, "");
          if (c.indexOf(cookieName) == 0) {
              return c.substring(cookieName.length, c.length);
          }
      }
      return "";
  }

  isDesc: boolean = false;
  //sorting method (generic, added by solat)
  sortList(property, itemList, event) {
      var self = this;

      //reset the sorting icons
      this.reset_SortIcons();

      //change the direction
      this.isDesc = !this.isDesc;

      //only apply sorting if atleast 1 value is different.
      if (!!itemList.reduce(function (a, b) { return (a[property] === b[property]) ? a : NaN; })) {

          var orderClass = (this.isDesc) ? 'headerSortDown' : 'headerSortUp';
          event.target.classList.add(orderClass)
          return itemList;
      }

      //sort array in respective order
      var theItem; var i = 0; var value; var data = itemList; var allNumbers = true; var allDates = true; var allBoolean = true;
      var allEmpty = true; var allAMPMTimeFormat = false;

      //check if this property values are all numeric or not..
      try {
          var sortOrder;
          for (i = 0; i < itemList.length; i++) {

              //current item
              theItem = itemList[i];
              value = theItem[property];

              if (value != "" && value != null && value != undefined) {

                  allEmpty = false;

                  //check if boolean
                  if (value != true && value != false && typeof (value) != "boolean") {
                      allBoolean = false
                  }
                  //sattar change
                  else {
                      //value is a boolean
                      allNumbers = false;
                      allDates = false;
                  }
                  //sattar change
                  if (!allBoolean) {

                      value = value.toString();
                      //check if number
                      if (isNaN(value) && !$.isNumeric(value)) {

                          allNumbers = false;

                          //string value
                          if (allBoolean == false) {
                              if (!self.isValidDate(value)) {
                                  allDates = false;
                              }

                              //CHECK AM/PM TIME FORMAT
                              if (value.indexOf("AM") != -1 || value.indexOf("PM") != -1)
                                  allAMPMTimeFormat = true;
                          }
                      }
                  }
              }
          }


          if (allEmpty) {
              //console.log("All empty list, do  not sort..");
              data = itemList;
          }
          else {
              if (allNumbers) {

                  if (this.isDesc) {
                      sortOrder = -1;
                  }
                  else {
                      sortOrder = 1;
                  }

                  //if all values in this column are numeric...
                  data = itemList.sort(function (a, b) {
                      function getValue(v) {

                          if (v == null || v == undefined)
                              v = "";

                          v = v.toString();
                          if (!v.includes(".") && !v.includes(",")) {
                              return v;
                          }

                          if (v.includes(".") && v.includes(",")) {
                              return v.replace('.', '').replace(',', '');
                          }
                          else if (v.includes(".") && !v.includes(",")) {
                              return v.replace('.', '');
                          }
                          else if (!v.includes(".") && v.includes(",")) {
                              return v.replace(',', '');
                          }
                          else {
                              return v.replace(/,/g, '').replace(/./g, '');
                          }
                      }
                      var number1 = getValue(a[property]);
                      var number2 = getValue(b[property]);
                      var result = (+a[property] < +b[property]) ? -1 : (+a[property] > +b[property]) ? 1 : 0;
                      return result * sortOrder;


                  });
              }
              else {
                  if (allBoolean) {
                      data = itemList.sort(
                          function (a, b) {
                              let bool1 = a[property];
                              let bool2 = b[property];

                              if (self.isDesc) {
                                  //descending order
                                  if (bool1 == bool2) return 0;
                                  else return ((bool2 && !bool1) ? 1 : -1);
                              }
                              else {
                                  //ascending order
                                  if (bool1 == bool2) return 0;
                                  else return ((!bool2 && bool1) ? 1 : -1);
                              }
                          }
                      );
                  }
                  else {
                      //set empty string
                      for (i = 0; i < itemList.length; i++) {

                          //current item
                          theItem = itemList[i];
                          value = theItem[property];
                          if (value == null || value == undefined) {
                              theItem[property] = "";
                          }
                          if (value != null && value != undefined && value != "") {
                              allEmpty = false;
                          }
                      }

                      if (allDates) {
                          data = itemList.sort(
                              function (a, b) {
                                  let date1 = a[property];
                                  let date2 = b[property];
                                  var result;
                                  if (self.isDesc) {
                                      if (date1 == "" && date2 == "") {
                                          result = 0;
                                      }

                                      if (date1 == "") {
                                          result = 1;
                                      }
                                      else if (date2 == "") {
                                          result = -1;
                                      }
                                      else {
                                          date1 = new Date(date1);
                                          date2 = new Date(date2);

                                          if (date1.getTime() === date2.getTime())
                                              result = 0;
                                          else
                                              return (date2 > date1) ? 1 : -1;
                                      }
                                  }
                                  else {
                                      if (date1 == "" && date2 == "") {
                                          result = 0;
                                      }

                                      if (date1 == "") {
                                          result = -1;
                                      }
                                      else if (date2 == "") {
                                          result = 1;
                                      }
                                      else {
                                          date1 = new Date(date1);
                                          date2 = new Date(date2);

                                          if (date1.getTime() === date2.getTime())
                                              result = 0;
                                          else
                                              result = (date2 < date1) ? 1 : -1;
                                      }
                                  }
                                  return result;
                              }
                          );
                      }
                      else {

                          //check if string contains "AM/PM" (New requirement)
                          if (allAMPMTimeFormat) {

                              data = itemList.sort(function (a, b) {
                                  function getValue(v) {

                                      if (v == null || v == undefined)
                                          v = "";

                                      v = v.toString();

                                      var time1 = getValue(a[property]);
                                      var time2 = getValue(b[property]);
                                      var compareResult = self.compareTime(time1, time2);
                                      console.log("Compare result: " + compareResult);
                                      return compareResult * sortOrder;
                                  }
                              });
                          }
                          else
                              data = _.orderBy(itemList, [property], [(this.isDesc) ? 'desc' : 'asc']);
                      }
                  }
              }
          }

          //change the sorting icon
          var orderClass = (this.isDesc) ? 'headerSortDown' : 'headerSortUp';
          event.target.classList.add(orderClass)

          //return the sorted array

          return data;
      }
      catch (e) {
          console.log(e);
      }
  }

  compareTime(time1, time2) {
      var re = /^([012]?\d):([0-6]?\d)\s*(a|p)m$/i;
      time1 = time1.match(re);
      time2 = time2.match(re);
      if (time1 && time2) {
          var is_pm1 = /p/i.test(time1[3]) ? 12 : 0;
          var hour1 = (time1[1] * 1 + is_pm1) % 12;
          var is_pm2 = /p/i.test(time2[3]) ? 12 : 0;
          var hour2 = (time2[1] * 1 + is_pm2) % 12;
          if (hour1 != hour2) return (hour1 > hour2) ? 1 : 0;

          var minute1 = time1[2] * 1;
          var minute2 = time2[2] * 1;
          return (minute1 > minute2) ? 1 : 0;
      }
            // rerturn 0 added by HZ15
            return 0;
  }

  isValidDate(date) {
      var rxDatePattern = /^(\d{1,2})(\/|-)(\d{1,2})(\/|-)(\d{4})$/; //Declare Regex
      var dtArray = date.match(rxDatePattern); // is format OK?
      return (dtArray != null) ? true : false;
  }
  reset_SortIcons() {
      $("table.tablesorter th").each(function () {
          $(this).removeClass("headerSortUp");
          $(this).removeClass("headerSortDown");
          $(this).addClass("header");
      });
  }


  MaintainanceCheck() {
      let modalutil: ModelUtills = new ModelUtills();
      var mainchk = localStorage.getItem("MainCK");
      if (mainchk == "true") {
          modalutil.showAlertMessage("This section is undergoing an upgrade activity and will be accessible in a few hours. Sorry for the inconvenience.", MessageType.warning);
          return false;
      }
      return true;
  }
  MaintainanceCheckforBanner() {
      var mainchk = localStorage.getItem("MainCK");
      if (mainchk == "true") {
          return false;
      }
      return true;
  }
}


export class ListUtill {
  GetDropDownSelectedTextValue(evnt: Event): any {
      if (evnt != null && evnt != undefined) {
          var textvalue = new TextValue();
          textvalue.value = (evnt.target as HTMLSelectElement).value;
          textvalue.text = (evnt.target as HTMLSelectElement).selectedOptions[0].textContent;
          return textvalue;
      }
  }
  GetDropDownSelectedValue(evnt: Event): any {
      if (evnt != null && evnt != undefined) {
          var value;
          value = (evnt.target as HTMLSelectElement).value;
          return value;
      }
  }
  GetDropDownSelectedText(evnt: Event): any {
      if (evnt != null && evnt != undefined) {
          var text;
          text = (evnt.target as HTMLSelectElement).selectedOptions[0].textContent;
          return text;
      }
  }
  GetCheckBoxSelectedTextValue(evnt: Event): any {
      if (evnt != null && evnt != undefined) {
          var textvalue = new TextValue();
          textvalue.value = (evnt.target as HTMLInputElement).value;
          textvalue.text = (evnt.target as HTMLInputElement).textContent;
          return textvalue;
      }
  }
  GetCheckBoxSelectedValue(evnt: Event): any {
      if (evnt != null && evnt != undefined) {
          var value;
          value = (evnt.target as HTMLInputElement).value;
          return value;
      }
  }
  GetCheckBoxSelectedText(evnt: Event): any {
      if (evnt != null && evnt != undefined) {
          var text;
          text = (evnt.target as HTMLInputElement).textContent;
          return text;
      }
  }
  IsCheckBoxChecked(evnt: Event): any {
      var isChecked = false;
      if (evnt != null && evnt != undefined) {
          isChecked = (evnt.target as HTMLInputElement).checked;
          return isChecked;
      }
  }
  formatDate(date: string) {
      if (date == null || date == "" || date == undefined) {
          return 0;
      }
      else {
          var OldDate = date.toString().split("T");
          var year = OldDate[0].split("-")[0];
          var month = OldDate[0].split("-")[1];
          var day = OldDate[0].split("-")[2];
          var newDate = month + "/" + day + "/" + year;
          return newDate;
      }
  }
  getDateInFormat(date: any) {
      let FormatedDate = "";
      if (date != undefined && date != "") {
          var defaultLocale: string = 'en-US';
          var datePipe = new DatePipe(defaultLocale);
          FormatedDate = datePipe.transform(new Date(date), 'MM/dd/yyyy');
      }
      return FormatedDate;
  }

  formatPhoneNumber(s) {
      var s2 = ("" + s).replace(/\D/g, '');
      var m = s2.match(/^(\d{3})(\d{3})(\d{4})$/);
      return (!m) ? null : "(" + m[1] + ") " + m[2] + "-" + m[3];
  }
  getAge(fromdate: Date, todate:any) {

      try {
          //changes
          var now = new Date();
          var yearNow = now.getFullYear();
          var monthNow = now.getMonth();
          var dateNow = now.getDate();

          var dob = new Date
              (
              new Date(fromdate.toString()).getFullYear(),
              new Date(fromdate.toString()).getMonth(),
              new Date(fromdate.toString()).getDate()
              );
          var yearDob = dob.getFullYear();
          var monthDob = dob.getMonth();
          var dateDob = dob.getDate();
          var age = {};

          let yearAge = yearNow - yearDob;

          if (monthNow >= monthDob)
              var monthAge = monthNow - monthDob;
          else {
              yearAge--;
              var monthAge = 12 + monthNow - monthDob;
          }

          if (dateNow >= dateDob)
              var dateAge = dateNow - dateDob;
          else {
              monthAge--;
              var dateAge = 30 + dateNow - dateDob;

              if (monthAge < 0) {
                  monthAge = 11;
                  yearAge--;
              }
          }

          let [ydiff, mdiff, ddiff] = [yearAge, monthAge, dateAge]

          //For children 2 + years à age in years(Yrs)
          if (ydiff >= 2) {
              return `${ydiff} yrs`;
          }
          //For children up to 1 month à age in weeks(wks and days)
          else if (ydiff == 0 && mdiff == 0 && ddiff > 0) {
              // age>=7 Days (weeks and days Calculation)
              if (ddiff >= 7) {
                  var weeks = Number.parseInt((ddiff / 7).toString());
                  var Days = Number.parseInt((ddiff % 7).toString());
                  return `${weeks} wks and ${Days} days`;
              }
              else // child's age < a week
              {
                  return `${ddiff} days`;
              }

          }
          else if (ydiff == 0 && mdiff == 0 && ddiff == 0) {
              return "1 day";
          }

          //For children 1 month to 23 months à age in months(mos)
          else if ((ydiff >= 0 && ydiff < 2) || (mdiff >= 1)) {
              var Months = (ydiff * 12) + mdiff;
              return `${Months} mos`;
          }

      }
      catch (error) {
          return '';
      }
      // rerturn 0 added by HZ15
      return 0;
  }

  getPlainTextFromRTFText(text: string) {
      return text != undefined && text != "" ? String(text).replace(/<[^>]+>/gm, '') : '';
  }
}
export class AFDateConverter {
  ConverttoLocalDate(date): Date {
      if (!date) return null;

      if (date instanceof Date) {
          date = this.hasTimezone(date) ? this.removeZ(date) : date;
          date = moment(date).format('Y-MM-DD h:mm:ss');
          date = new Date(date);
      }

      return date;
  }

  ConvertDate(date): any {
      if (!date) return null;

      if (date instanceof Date) {
          date = this.hasTimezone(date) ? this.removeZ(date) : date;
          date = moment(date).format('Y-MM-DD h:mm:ss');
      }

      return date;
  }

  StringTimeToDateTime(objTime: string) {
      if (!objTime) 
      {
        return 0;
      }

      return new Date("01/01/1900 " + objTime);
  }

  DateTimeToTime(date) {
      if (!date) return '';

      return moment(date).format('HH:mm:ss');
  }

  formatTimeAMPM(time) {
      if (!time) return time;

      return moment(this.StringTimeToDateTime(time)).format('hh:mm A');
  }

  /**
* Request Date type variable,
* Returns Date in MM/DD/YYYY format and binds with datepicker.
*/
  formatDate(date): any {
      if (!date) return;

      date = this.hasTimezone(date) ? this.removeZ(date) : new Date(date);
      return moment(date).format('MM/DD/YYYY');
  }
  CheckIfValidYearIsEntered(date: any): any {
      if (date != null) {
          var enteredDateYear = date.getFullYear();

          if (enteredDateYear < new Date().getFullYear()) {
              return date = null;
          }
          if (enteredDateYear > new Date().getFullYear()) {
              return date = null;
          }
          return date;
      }
      else
          return new Date();
  }
  getCurrentDateTime() {
      return new Date().getTime();
  }
  toDateTime(stringDate) {
      return new Date(stringDate).getTime();
  }

  private hasTimezone(value) {
      if (typeof value !== 'string') return false;
      return (value.includes('T') || value.includes('t'));
  }

  private removeZ(value) {
      if (!value) return '';
      return value.replace(/z|Z/, '');
  }
  //Waleed
  getBussinessDay(date) {
      let day = new Date(date).getDay();
      if (day != 0 && day != 6) {
          return date;
      }

      else {
          return false;
      }

  }
  getMonthlyWeekday(n, d, m, y) {
      //         * Parameters:
      //         * n = 1 - 5 for first, second, third, fourth or fifth weekday of the month
      //         * d = full spelled out weekday Monday - Friday
      //         * m = Full spelled out month like June
      //         * y = Four digit representation of the year like 2017
      var targetDay, curDay = 0, i = 1, seekDay;
      if (d == "Sunday") seekDay = 0;
      else if (d == "Monday") seekDay = 1;
      else if (d == "Tuesday") seekDay = 2;
      else if (d == "Wednesday") seekDay = 3;
      else if (d == "Thursday") seekDay = 4;
      else if (d == "Friday") seekDay = 5;
      else if (d == "Saturday") seekDay = 6;
      else if (!isNaN(d)) seekDay = d;
      while (curDay < n && i < 31) {
          targetDay = new Date(i++ + " " + m + " " + y);
          if (targetDay.getDay() == seekDay) curDay++;
      }
      if (curDay == n) {
          return targetDay;
      }
      else {
          return false;
      }
  }
  getLastSpecificDay(specificDay, month, year) {
      var n;
      if (specificDay == "Sunday") n = 0;
      else if (specificDay == "Monday") n = 1;
      else if (specificDay == "Tuesday") n = 2;
      else if (specificDay == "Wednesday") n = 3;
      else if (specificDay == "Thursday") n = 4;
      else if (specificDay == "Friday") n = 5;
      else if (specificDay == "Saturday") n = 6;
      else if (!isNaN(specificDay)) n = specificDay;
      var d = new Date();
      if (year) {
          d.setFullYear(year);
      }
      d.setDate(1); // Roll to the first day of ...
      d.setMonth(month || d.getMonth() + 1); // ... the next month.
      do { // Roll the days backwards until Monday.
          d.setDate(d.getDate() - 1);
      }
      while (d.getDay() !== n);
      return d;
  }
  addMonthsToDate(date, n) {
      return new Date(date.setMonth(date.getMonth() + n));
  }
  getCurrentMonthName(date) {
      const monthNames = ["January", "February", "March", "April", "May", "June",
          "July", "August", "September", "October", "November", "December"
      ];
      return monthNames[date.getMonth()];
  }
  getMaxDate(datesList) {
      let dates = datesList.map(d => moment(d)),
          maxDate = moment.max(dates);
      return maxDate;
  }
  getSpecificDayofCurrentWeek(date, day: number) {
      var ret = new Date(date ? date : new Date());
      ret.setDate(ret.getDate() + (day - 1 - ret.getDay() + 7) % 7 + 1);
      return ret;
  }
  getDateFromTimeString(timeString: string) {
      let timeFormat = timeString.replace(/[^a-z]/gi, '');
      let hourdigits = timeString.replace(timeFormat, '');
      let hour, minutes;
      let Time = new Array<string>();
      Time = hourdigits.split(":");
      if (Time.length > 0) {
          hour = Time[0];
          hour = parseInt(hour);
          minutes = Time[1];
          minutes = parseInt(minutes);
      }
      let d = new Date();
      let currentDate = (d.getMonth() + 1) + '/' + d.getDate() + '/' + d.getFullYear();
      currentDate = currentDate + ' ' + hour + ':' + minutes + ' ' + timeFormat;
      let result = new Date(currentDate);
      return result;
  }
}
class TextValue {
  text: any;
  value: any;
}
export class InputValidations {
  phoneValidation(event: any) {
      let value: any = (event.target as HTMLInputElement).value;

      if (event.which === 32 && !value.length) {
          event.preventDefault();
          return;
      }
      if (event.which === 37) {
          event.preventDefault();
          return;
      }

      if ((event.which === 110 || event.which === 190) && !value.length) {
          event.preventDefault();
          return;
      }
      if ((event.which < 48 || event.which > 57) && (event.which != 8) && (event.keyCode != 9)) {
          event.preventDefault();
          return;
      }
  }
  NumberValidationWithDot(event: any) {
      let value: any = (event.target as HTMLInputElement).value;

      if (event.which === 32 && !value.length) {
          event.preventDefault();
          return;
      }
      if (event.which === 37) {
          event.preventDefault();
          return;
      }

      if ((event.which === 110 || event.which === 190 || (event.which === 47)) && !value.length) {
          event.preventDefault();
          return;
      }
      if ((event.which < 46 || event.which > 57) && (event.which != 8) && (event.keyCode != 9)) {
          event.preventDefault();
          return;
      }
  }
  QuantityValidationWithGreaterthanZero(event: any) {

      let value: any = (event.target as HTMLInputElement).value;

      if ((event.which === 96 || event.which === 48) && !value.length) {
          event.preventDefault();
          return;
      }

      if (event.which === 37) {
          event.preventDefault();
          return;
      }

      if (event.which === 32 && !value.length) {
          event.preventDefault();
          return;
      }

      if ((event.which === 110 || event.which === 190) && !value.length) {
          event.preventDefault();
          return;
      }

      if ((event.which < 48 || event.which > 57) && (event.which != 8) && (event.keyCode != 9)) {
          event.preventDefault();
          return;
      }
  }
  nameValidation(event: any) {
      let value: any = (event.target as HTMLInputElement).value;
      if (event.which === 91 || event.which === 92 || event.which === 93 || event.which === 94 || event.which === 95) {
          event.preventDefault();
          return;
      }
      if ((event.which < 65 || event.which > 122) && (event.which != 8) && (event.keyCode != 9) && (event.which != 45)) {
          event.preventDefault();
          return;
      }
  }
  middlenameValid(event: any) {
      let value: any = (event.target as HTMLInputElement).value;
      if (event.which === 91 || event.which === 92 || event.which === 93 || event.which === 94 || event.which === 95 || event.which === 96) {
          event.preventDefault();
          return;
      }
      if ((event.which < 65 || event.which > 122) && (event.which != 8) && (event.keyCode != 9) && (event.which != 45)) {
          event.preventDefault();
          return;
      }
  }
  alphanumeric(event: any) {

      let value: any = (event.target as HTMLInputElement).value;
      if (event.which === 91 || event.which === 92 || event.which === 93 || event.which === 94 || event.which === 95 || event.which === 96) {
          event.preventDefault();
          return;
      }
      if ((event.which < 48 || event.which > 122) && (event.which != 8) && (event.keyCode != 9) && (event.which != 45)) {
          event.preventDefault();
          return;
      }
  }
  alphanumericWithSpaces(event: any) {
      let value: any = (event.target as HTMLInputElement).value;
      if (!value && event.which === 32) {
          event.preventDefault();
          return;
      }

      if (event.which === 91 || event.which === 92 || event.which === 93 || event.which === 94 || event.which === 95 || event.which === 96 ||
          event.which === 58 || event.which === 59 || event.which === 60 || event.which === 61 || event.which === 62 || event.which === 63 || event.which === 64) {
          event.preventDefault();
          return;
      }
      if ((event.which < 48 || event.which > 122) && (event.which != 8) && (event.keyCode != 9) && (event.which != 32)) {
          event.preventDefault();
          return;
      }
  }
  alphaWithSpaces(event: any) {
      let value: any = (event.target as HTMLInputElement).value;
      if (event.which === 91 || event.which === 92 || event.which === 93 || event.which === 94 || event.which === 95 || event.which === 96) {
          event.preventDefault();
          return;
      }
      if ((event.which < 65 || event.which > 122) && (event.which != 8) && (event.keyCode != 9) && (event.which != 32)) {
          event.preventDefault();
          return;
      }
  }
  ICDCPTValidate(event: any) {
      var filter = /[().,a-zA-Z0-9-]/;
      var key = "\\" + String.fromCharCode(!event.charCode ? event.which : event.charCode);
      if (filter.test(key) == false) {
          event.preventDefault();
          return;
      }
  }
}
class ClientActivityLog {
  logFor: string;
  logMessage: string;
}
export class DomainUtills {
  baseUrl = new BaseUrl();
  GetDomain(): any {
      return this.baseUrl.ApiUrl + "api/";
  }

  GetClientDomain(isProduction: boolean = true): string {
      if (window.location.origin.includes('localhost')) {
          return this.baseUrl.ApiUrl;
      }
      else
          return this.baseUrl.ApplicationUrl;
  }
}
export class ModelUtills {
  onModelOpen() {

      let divToappend = "<div id='backdrop' class='modal-backdrop fade in'></div>";
      $("body").addClass("modal-open");
      $("body").append(divToappend);
  }
  onModelClose() {
      $("body").removeClass("modal-open");
      $("#backdrop").remove();
      $(".modal-backdrop").remove();
  }
  showAlertMessage(message, type: number) {
      (document.getElementById("alertMessage") as HTMLDivElement).innerHTML = "";
      if (message != undefined && message != "" && type != null) {
          var div = $("#alertMessage");
          if (div == undefined || div == null) {
              return;
          }
          div.on("mouseenter", function () {
              clearTimeout(timeOutFunction);
          });
          div.on("mouseleave", function () {
              div.fadeOut(1000);
          });
          var innerhtml = "";
          if (type === 0) {
              innerhtml = "<div class='alert alert-danger alert-content' id='alert' ><p><span class='glyphicon glyphicon-exclamation-sign margin-r5'></span> " + message + "</p></div>";
              div.append(innerhtml);
              div.css("display", "block");
              var timeOutFunction = setTimeout(() => {
                  div.find("[id$='alert']").fadeOut(1000);
                  div.find("[id$='alert']").remove();
                  div.css("display", "none");
              }, 3000);
          }
          else if (type === 1) {
              var innerhtml = "<div class='alert alert-success alert-content' id='alert' ><p><span class='glyphicon glyphicon-ok margin-r5'></span> " + message + "</p></div>";
              div.append(innerhtml);
              div.css("display", "block");
              var timeOutFunction = setTimeout(() => {
                  //Changes By Billing
                  //div.find("[id$='alert']").fadeOut(100);
                  div.find("[id$='alert']").fadeOut(1000);
                  div.find("[id$='alert']").remove();
                  div.css("display", "none");
              }, 3000);
          }

          else if (type === 2) {
              innerhtml = "<div class='alert alert-warning alert-content' id='alert' ><p><span class='glyphicon glyphicon-exclamation-sign margin-r5'></span> " + message + "</p></div>";
              div.append(innerhtml);
              div.css("display", "block");
              var timeOutFunction = setTimeout(() => {
                  div.find("[id$='alert']").fadeOut(1000);
                  div.find("[id$='alert']").remove();
                  div.css("display", "none");
              }, 4000);
          }
          else if (type === 3) {
              innerhtml = "<div class='alert alert-info alert-content' id='alert' ><p><span class='glyphicon glyphicon-exclamation-sign margin-r5'></span> " + message + "</p></div>";
              div.append(innerhtml);
              div.css("display", "block");
              var timeOutFunction = setTimeout(() => {
                  div.find("[id$='alert']").fadeOut(1000);
                  div.find("[id$='alert']").remove();
                  div.css("display", "none");
              }, 4000);
          }
      }

      return;
  }
  formatZipNumber(str:any, n:any) {
      var ret = [];
      var i;
      var len;
      for (i = 0, len = str.length; i < len; i += n) {
          ret.push(str.substr(i, n))
      }
      return ret;
  };
  showBotAlertMessage(message:any, type: number) {
      (document.getElementById("alertMessage") as HTMLDivElement).innerHTML = "";
      if (message != undefined && message != "" && type != undefined)
          var div = $("#alertMessage");
      div.on("mouseenter", function () {
          clearTimeout(timeOutFunction);
      });
      div.on("mouseleave", function () {
          div.fadeOut(2000);
      });
      var innerhtml = "";
      if (type === 0) {
          innerhtml = "<div class='alert alert-danger alert-content' id='alert' ><p><span class='glyphicon glyphicon-exclamation-sign margin-r5'></span> " + message + "</p></div>";
          div.append(innerhtml);
          div.css("display", "block");
          var timeOutFunction = setTimeout(() => {
              div.find("[id$='alert']").fadeOut(1000);
              div.find("[id$='alert']").remove();
              div.css("display", "none");
          }, 7000);
      }
      else if (type === 1) {
          var innerhtml = "<div class='alert alert-success alert-content' id='alert' ><p><span class='glyphicon glyphicon-ok margin-r5'></span> " + message + "</p></div>";
          div.append(innerhtml);
          div.css("display", "block");
          var timeOutFunction = setTimeout(() => {
              div.find("[id$='alert']").fadeOut(100);
              div.find("[id$='alert']").remove();
              div.css("display", "none");
          }, 500);
      }

      else if (type === 2) {
          innerhtml = "<div class='alert alert-warning alert-content' id='alert' ><p><span class='glyphicon glyphicon-exclamation-sign margin-r5'></span> " + message + "</p></div>";
          div.append(innerhtml);
          div.css("display", "block");
          var timeOutFunction = setTimeout(() => {
              div.find("[id$='alert']").fadeOut(1000);
              div.find("[id$='alert']").remove();
              div.css("display", "none");
          }, 4000);
      }
      else if (type === 3) {
          innerhtml = "<div class='alert alert-info alert-content' id='alert' ><p><span class='glyphicon glyphicon-exclamation-sign margin-r5'></span> " + message + "</p></div>";
          div.append(innerhtml);
          div.css("display", "block");
          var timeOutFunction = setTimeout(() => {
              div.find("[id$='alert']").fadeOut(1000);
              div.find("[id$='alert']").remove();
              div.css("display", "none");
          }, 4000);
      }

      return;
  }

  showMultipleAlertMessages(SuccessMessages: Array<string>, FailureMessages: Array<string>) {

      (document.getElementById("alertMessage") as HTMLDivElement).innerHTML = "";
      var innerhtml = "";
      let IsSuccess = false;
      let IsError = false;
      IsSuccess = SuccessMessages != undefined && SuccessMessages != null && SuccessMessages.length > 0 ? true : false;
      IsError = FailureMessages != undefined && FailureMessages != null && FailureMessages.length > 0 ? true : false;

      if (IsSuccess || IsError) {
          var div = $("#alertMessage");
          div.on("mouseenter", function () {
              clearTimeout(timeOutFunction);
          });
          div.on("mouseleave", function () {
              div.fadeOut(1000);
          });
          innerhtml = "<div id='alert' style='position:absolute;width:100%;height:auto;top:30%;'>";
          if (IsSuccess) {
              for (let i = 0; i < SuccessMessages.length; i++) {
                  innerhtml += "<div style='position:relative; width:75%;' class='alert alert-success alert-content'><span class='glyphicon glyphicon-ok margin-r5'></span><b>Success:&nbsp; </b> " + SuccessMessages[i] + "</div></br> ";
              }
          }
          if (IsError) {
              for (let i = 0; i < FailureMessages.length; i++) {
                  innerhtml += "<div style='position:relative; width:75%;' class='alert alert-danger alert-content'><span class='glyphicon glyphicon-exclamation-sign margin-r5'></span><b>Error:&nbsp; </b> " + FailureMessages[i] + "</div></br> ";
              }
          }
          innerhtml += "</div>";
          div.append(innerhtml);
          div.fadeIn(1000);
          div.css("display", "block");
          var timeOutFunction = setTimeout(() => {
              div.find("[id$='alert']").fadeOut(1000);
              div.find("[id$='alert']").remove();
              div.css("display", "none");
              div.html("");
          }, 3000);
          return;

      }
  }


  toTitleCase(str: string) {
      if (str != null && str != undefined) {
          return str.replace(/\w\S*/g, function (txt) { return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase(); });
      } else {
          return "";
      }
  }

  toTitleCaseProvider(str: string) {
      if (str != null && str != undefined) {
          str = str.replace(/\w\S*/g, (txt => txt[0].toUpperCase() + txt.substr(1).toLowerCase()));
          let ProviderTitleArray = str.split(',');
          if (ProviderTitleArray.length > 2) {
              str = str.replace(ProviderTitleArray[2], ProviderTitleArray[2].toUpperCase());
              return str;
          }
          else
              return str;
      } else {
          return "";
      }
  }

  USFormatedPhone(val: any) {
      if (val != null && val != "" && val != undefined && val.indexOf("(") == -1) {
          val = "(" + val.substring(0, 3) + ") " + val.substring(3, 6) + "-" + val.substring(6, 10);
      }
      return val;
  }
  ZipCodeFormat(val: any) {
      if (val != null && val != "" && val != undefined) {
          if (val.length == 9) {
              val = val.substring(0, 5) + "-" + val.substring(5, 9);
          }
      }
      return val;
  }

  resetPhoneNumber(value: any) {
      if (value != null && value != "" && value != undefined) {
          value = value.replace("(", "").replace(")", "").replace("-", "").replace("-", "").replace(" ", "").trim();
      }
      return value;
  }
  NegativeAmount(input: number) {
      if (input != undefined && input != null && input < 0) {
          return ("(" + input * -1 + ")").toString();
      }
      else if (input != undefined && input != null && input > 0) {
          return input.toString();
      }
      else
          return "0.00";
  }
  roundOff(value:any, exp:any) {
      if (typeof exp === 'undefined' || +exp === 0)
          return Math.round(value);

      value = +value;
      exp = +exp;

      if (isNaN(value) || !(typeof exp === 'number' && exp % 1 === 0))
          return NaN;

      // Shift
      value = value.toString().split('e');
      value = Math.round(+(value[0] + 'e' + (value[1] ? (+value[1] + exp) : exp)));

      // Shift back
      value = value.toString().split('e');
      return +(value[0] + 'e' + (value[1] ? (+value[1] - exp) : -exp));
  }
  IsNullUndefinedOrEmpty(value: any) {
      if (value != null) { if (value != undefined) { if (value.toString().trim() != "") { return false; } } }
      return true;
  }

  isObjectEmpty(obj:any, toExclude: string[] = []) {
      for (var prop in obj) {
          if (obj.hasOwnProperty(prop) && !toExclude.includes(prop) && obj[prop])
              return false;
      }
      return true
  }

  ValidateSearch(val: any) {
      if (val == null || $.trim(val).length == 0 || typeof (val) == 'undefined') {
          return true;
      }
      else {
          return false;
      }
  }
  parseTheDateandSetHours(val: any) {
      if (Date.parse(val)) {
          return new Date(val).setHours(0, 0, 0, 0);
      }
            // rerturn 0 added by HZ15
            return 0;
  }
  CheckIfValidDateEntered(dateEntered: any): boolean {

      if (dateEntered) {
          let enteredDate = dateEntered.getFullYear();
          if (enteredDate < 1900) {
              return false;
          } else {
              return true;
          }
      }
            // rerturn 0 added by HZ15
            return false;
  }
  //applySorter() {
  //    if ($('.tablesorter th').hasClass('header')) {
  //        $('.tablesorter th.headerSortUp').removeClass('headerSortUp');
  //        $('.tablesorter th.headerSortDown').removeClass('headerSortDown');
  //        $('.tablesorter').trigger("update");
  //    } else {
  //        $('.tablesorter').tablesorter('sort');
  //        $('.tablesorter').trigger("update");
  //    }
  //}



}
export enum MessageType {
  error = 0,
  success = 1,
  warning = 2,
  info = 3

}

// export function debounce(functionToCall: Function, waitTimeInMilliseconds:any) {
//   let timeout: any;
//   return function () {
//       timeout && clearTimeout(timeout);
//       timeout = setTimeout(functionToCall.bind(this, ...Array.from(arguments)), waitTimeInMilliseconds)
//   }
// }
// To show popover correctly
// and don't modify this by any means
// export function showPopoverWithBody() {
//   if (!this.popover || !this.popover.getElement())
//       return;
//   var p = this.positionElements(this.popover.getElement(), this.popoverDiv.nativeElement, this.placement, true);
//   this.displayType = "block";
//   this.top = p.top;
//   this.left = p.left;
//   this.isIn = true;
// };
// export function showPopoverWithMargin() {
//   if (!this.popover || !this.popover.getElement())
//       return;
//   this.top += parseInt($(this.parentOffsetEl(this.popover.getElement())).parent().parent().css('marginTop')) - 20;
// };
export class BaseUrl {
  private applicationUrl: string;
  private apiUrl: string;
  constructor() {
      this.applicationUrl = window.location.origin + "/";
      this.apiUrl = this.getApiUrl();
  }
  get ApplicationUrl() {
      return this.applicationUrl;
  }
  get ApiUrl() {
      return this.apiUrl;
  }
  getApiUrl() {
      let originalPath = window.location.origin;
      let domain: string = "";
      if (originalPath.includes("localhost")) {
          domain = "http://localhost:33541/";
      }
      else if (originalPath.includes("10.20.25.33:8060")) {
          domain = "http://10.20.25.33:8061/";
      }
      else if (originalPath.includes("securesoft.mtbc.com")) {
          domain = "https://securesoftapi.mtbc.com/";
      }
      else if (originalPath.includes("10.20.25.33:6060")) {
          domain = "http://10.20.25.33:6061/";
      }
      else if (originalPath.includes("securesoft2.mtbc.com")) {
          domain = "https://securesoft2api.mtbc.com/";
      }
      else if (originalPath.includes("172.25.0.36:6060")) {
          domain = "http://172.25.0.36:6061/";
      }
      else if (originalPath.includes("securesoft3.mtbc.com")) {
          domain = "https://securesoft3api.mtbc.com/";
      }
      else if (originalPath.includes("10.20.25.34:7070")) {
          domain = "http://10.20.25.34:7069/";
      }
      else if (originalPath.includes("10.20.25.32:4440")) {
          domain = "http://10.20.25.32:4441/";
      }
      else if (originalPath.includes("stagingsoft.mtbc.com")) {
          domain = "https://stagingsoftapi.mtbc.com/";
      }
      else if (originalPath.includes("10.20.25.34:6060")) {
          domain = "http://10.20.25.34:6061/";
      }
      else if (originalPath.includes("testingsoft.mtbc.com")) {
          domain = "https://testingsoftapi.mtbc.com/";
      }
      else if (originalPath.includes("testingsoft2.mtbc.com")) {
          domain = "https://testingsoft2api.mtbc.com/";
      }
      else if (originalPath.includes("10.20.25.32:8060")) {
          domain = "http://10.20.25.32:8061/";
      }
      else if (originalPath.includes("172.16.0.27:9131")) {
          domain = "http://172.16.0.27:9132/";
      }
      else if (originalPath.includes("10.20.25.32:4406")) {
          domain = "http://10.20.25.32:4407/";
      }
      else if (originalPath.includes("10.20.25.32:3306")) {
          domain = "http://10.20.25.32:3307/";
      }
      else if (originalPath.includes("172.16.0.27:9995")) {
          domain = "http://172.16.0.27:9996/";
      }
      else if (originalPath.includes("172.16.0.27:2020")) {
          domain = "http://172.16.0.27:2021/";
      }
      else if (originalPath.includes("10.20.25.32:8097")) {
          domain = "http://10.20.25.32:8098/";
      }
      else if (originalPath.includes("10.20.35.70:8086")) {
          domain = "http://10.20.35.70:8087/";
      }
      else if (originalPath.includes("10.20.25.32:2255")) {
          domain = "http://10.20.25.32:2256/";
      }
      else if (originalPath.includes("10.20.25.32:1087")) {
          domain = "http://10.20.25.32:1088/";
      }
      else if (originalPath.includes("172.16.0.27:2222")) {
          domain = "http://172.16.0.27:2221/";
      }
      else if (originalPath.includes("172.16.0.27:1010")) {
          domain = "http://172.16.0.27:1011/";
      }
      else if (originalPath.includes("172.16.0.27:1596")) {
          domain = "http://172.16.0.27:1597/";
      }
      else if (originalPath.includes("10.20.25.32:8097")) {
          domain = "http://10.20.25.32:8098/";
      }
      else if (originalPath.includes("10.20.25.32:4475")) {
          domain = "http://10.20.25.32:4476/";
      }
      else if (originalPath.includes("172.16.0.27:1596")) {
          domain = "http://172.16.0.27:1597/";
      }
      else if (originalPath.includes("172.16.0.27:5542")) {
          domain = "http://172.16.0.27:5543/";
      }
      else if (originalPath.includes("10.20.25.32:2255")) {
          domain = "http://10.20.25.32:2256/";
      }
      else if (originalPath.includes("10.20.25.32:4408")) {
          domain = "http://10.20.25.32:4409/";
      }
      else if (originalPath.includes("10.20.25.32:1072")) {
          domain = "http://10.20.25.32:1073/";
      }
      else if (originalPath.includes("10.20.25.32:4447")) {
          domain = "http://10.20.25.32:4446/";
      }
      else if (originalPath.includes("172.16.0.27:9091")) {
          domain = "http://172.16.0.27:9092/";
      }
      else if (originalPath.includes("172.16.0.27:9091")) {
          domain = "http://172.16.0.27:9092/";
      }
      else if (originalPath.includes("172.16.0.27:9130")) {
          domain = "http://172.16.0.27:9129/";
      }
      else if (originalPath.includes("172.16.0.27:9104")) {
          domain = "http://172.16.0.27:9103/";
      }
      else if (originalPath.includes("172.16.0.27:9106")) {
          domain = "http://172.16.0.27:9105/";
      }
      else if (originalPath.includes("10.20.25.32:9104")) {
          domain = "http://10.20.25.32:9103/";
      }
      return domain;
  }
}

//Faisal Siddique Excel Report
export function removeTdFromTr(item, tdSelector) {
  let tr = '<tr>' + item.innerHTML + '</tr>';
  let newHtml = $(tr);
  $(tdSelector, newHtml).remove();
  return '<tr>' + newHtml.html() + '</tr>';
}
//Faisal siddique Excel report