import { Component } from '@angular/core';

@Component({
  selector: 'app-month-end',
  templateUrl: './month-end.component.html',
  styleUrls: ['./month-end.component.scss']
})
export class MonthEndComponent {

}
