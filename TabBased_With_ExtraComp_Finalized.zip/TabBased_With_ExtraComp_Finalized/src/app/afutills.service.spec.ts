import { TestBed } from '@angular/core/testing';

import { AFUtillsService } from './afutills.service';

describe('AFUtillsService', () => {
  let service: AFUtillsService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AFUtillsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
