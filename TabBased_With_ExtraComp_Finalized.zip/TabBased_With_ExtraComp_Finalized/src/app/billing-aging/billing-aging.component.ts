import { Component } from '@angular/core';

import { MethodFilter, removeComponentStateFunction, State } from '../Services/component-state-management/decorator';


declare var $: any;
@State({
    nameOfComponent: "BillingAgingComponent",
    properties: ["textSearch", "AgingRequestObj"],
    functionsToExecuteAfterGettingState: ['afterGettingComponentState'],
    whenToGetState: MethodFilter.BeforeExecution,
    whenToSaveState: MethodFilter.AfterExecution,
})


@Component({
  selector: 'app-billing-aging',
  templateUrl: './billing-aging.component.html',
  styleUrls: ['./billing-aging.component.scss']
})
export class BillingAgingComponent {

textSearch: "";
  /**
   *
   */
  constructor() {




    
  }
}
