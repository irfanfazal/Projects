import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AppComponent } from './app.component';
import { BillingAgingComponent } from './billing-aging/billing-aging.component';
import { ClaimStatusComponent } from './claim-status/claim-status.component';
import { MonthEndComponent } from './month-end/month-end.component';
import { TabCompComponent } from './tab-comp/tab-comp.component';


const routes: Routes = [

  //{ path: '', component:AppComponent, pathMatch: 'full'  },
  { path: 'ReportMain', component: TabCompComponent,
  children:[
    {path:'BillingAging',component:BillingAgingComponent},
    {path:'BillingAgingClaimStatus',component:ClaimStatusComponent},
    {path:'BillingMonthEndAging',component:MonthEndComponent}
  ]
},



//  {path:'BillingAging',component:BillingAgingComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
