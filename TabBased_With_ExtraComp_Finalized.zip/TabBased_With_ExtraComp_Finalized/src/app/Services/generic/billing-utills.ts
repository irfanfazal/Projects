import { Injectable } from '@angular/core';
import { MessageType, ModelUtills } from 'src/app/afutills.service';
import * as _ from "lodash";
import * as moment from 'moment';
import { Flag } from 'src/app/Classes/Common/external-source-login';
import * as CryptoJS from 'crypto-js';
//import $ from 'jquery';
//declare var $: any;
import * as $ from 'jquery';
@Injectable()
export class BillingUtills {


    static filteredColumns: any[];
    isDesc: boolean = false;
    static webIP: string = "http://172.16.0.27:5555/";
    
    DatePickerOptionsFD = {
        autoclose: true,
        todayHighlight: true,
        placeholder: 'MM/DD/YYYY'
    };
    // Disable prior date only for current and future date
    DatePickerOptionsDisablePD = {
        autoclose: true,
        todayHighlight: true,
        startDate: new Date(),
        placeholder: 'MM/DD/YYYY',
    };
    // Disable Future Date only for current and prior date
    DatePickerOptions = {
        autoclose: true,
        todayHighlight: true,
        endDate: "0d",
        placeholder: 'MM/DD/YYYY'
    };

    DatePickerOptionsCFD = {
        autoclose: true,
        todayHighlight: true,
        placeholder: 'MM/DD/YYYY',
        startDate: new Date()
    };
    DatePickerOptionsEST = {
        autoclose: true,
        todayHighlight: true,
        endDate: "0d",
        placeholder: 'MM/DD/YYYY',
        time: new Date().toLocaleString('en-US', { timeZone: 'America/New_York' })

    };


    /**
     *
     */
    constructor(private _modelUtills: ModelUtills) {
        
        

    }



        //**** DATE FUNCTIONS *****/
        static validateDateRegex(date) {
            var date_regex = /^(0[1-9]|1[0-2])\/(0[1-9]|1\d|2\d|3[01])\/(19|20)[0-9]{2}$/;
            return date_regex.test(date);
        }
        //**** VALIDATE EMAIL *****/
        static validateEmailRegex(email) {
            var date_regex = /^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$/;
            return date_regex.test(email);
        }
    
        validateDate(p: any, callfrom: string = "") {
            debugger
            var isValid = false;
            if (p) {
                if (typeof (p) == "string")
                    isValid = BillingUtills.validateDateRegex(p);
                else {
                    if (p && p.srcElement) {
                    //    isValid = BillingUtills.isStringNullOrEmpty($("#" + p.srcElement.id).val()) ? true : BillingUtills.validateDateRegex($("#" + p.srcElement.id).val());
                    }
                }
            }
            if (!isValid) {
                if (callfrom == "") {
                    this._modelUtills.showAlertMessage("Invalid date format.", MessageType.error);
                }
                else if (callfrom == "DpImmEffDate") {
                    this._modelUtills.showAlertMessage("Provide a valid Immunization Registry Effective Date.", MessageType.error);
                } else if (callfrom == "immPublicityDate") {
                    this._modelUtills.showAlertMessage("Provide a valid Publicity Effective Date.", MessageType.error);
                } else if (callfrom == "immIndicatorDate") {
                    this._modelUtills.showAlertMessage("Provide a valid Protection Indicator Effective Date.", MessageType.error);
                }
            }
        }
    
        static dateDiffInDays(date1, date2) {
            let dt1 = new Date(date1);
            let dt2 = new Date(date2);
            return Math.floor((Date.UTC(dt2.getFullYear(), dt2.getMonth(), dt2.getDate()) - Date.UTC(dt1.getFullYear(), dt1.getMonth(), dt1.getDate())) / (1000 * 60 * 60 * 24));
        }
    
        static isStringNullOrEmpty(value: string) {
            
            return (value == null || value == undefined || $.trim(value) == "") ? true : false;
        }
    
        isStringNullOrEmpty(value: string) {
            return (value == null || value == undefined || $.trim(value) == "") ? true : false;
        }
    
        static getString(value: any): string {
            try {
                if (value != null && value != undefined) {
                    value = value.toString();
                    return value;
                } else {
                    return "";
                }
            } catch (e) {
                return "";
            }
        }
    
        static convertToNumber(value: any): number {
            try {
                if (value != null && value != undefined && !isNaN(value)) {
                    value = value.toString();
                    let result: number = 0;
                    result = Number(Number(value).toFixed(2));
                    return result;
                } else {
                    return 0.00;
                }
            } catch (e) {
                return 0.00;
            }
        }
    
        static toNumberString(value: any): any {
            try {
                if (value == null || value == undefined || String(value) == "" || String(value).trim() == "" || isNaN(value)) {
                    return "0";
                } else {
                    return value;
                }
            } catch (e) {
                return 0;
            }
        }
    
        static validateNumeric(value: string): boolean {
            var date_regex = /^[0-9]+$/;
            return date_regex.test(value);
        }
    
        static validatePhoneNo(value: string): boolean {
            var date_regex = /^[0-9- ()]+$/;
            return date_regex.test(value);
        }
    
        static validateAlphaNumericOnly(value: string): boolean {
            var date_regex = /^[a-zA-Z0-9]*$/;
            return date_regex.test(value);
        }
        static validateAlphaNumericWithDot(value: string): boolean {
            var date_regex = /^[a-zA-Z0-9-.]*$/;
            return date_regex.test(value);
        }
    
        static validateAlphaNumeric(value: string): boolean {
            var date_regex = /^[a-zA-Z0-9- ]*$/;
            return date_regex.test(value);
        }
    
        static validateAlpha(value: string): boolean {
            var alpha = /^[a-zA-Z ]*$/;
            return alpha.test(value);
        }
    
        static validateAlphaNumericComma(value: string): boolean {
            var anc_regex = /^[a-zA-Z0-9_, ]*$/;
            return anc_regex.test(value);
        }
    
        static validateEmail(mail: string): boolean {
            var email_regex = /^(([^<>()\[\]HYPERLINK "\\.,;:\s@"\\.,;:\s@"]+(\.[^<>()\[\]HYPERLINK "\\.,;:\s@"\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
            return email_regex.test(mail);
        }
    
        static validateEmail2(email: string): boolean {
            try {
                var date_regex = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
                return date_regex.test(email);
            } catch (e) {
                console.log(e);
                return false;
            }
        }
    
        static getToUpper(value: any): string {
            try {
                if (value != null && value != undefined) {
                    value = value.toString().toUpperCase();
                    return value;
                } else {
                    return "";
                }
            } catch (e) {
                return "";
            }
        }
    
        static getEligStatusColor(eligiblitystatus: string, subScriberName: string, elgDifrnce: string, PRI_SEC_OTH_TYPE: string) {
            eligiblitystatus == '1' ? "" : eligiblitystatus
            let eligiblity = eligiblitystatus != null ? eligiblitystatus.trim().toUpperCase() : "";
            let subscriberName = subScriberName != null ? subScriberName : "";
            let colorClass = "";
            PRI_SEC_OTH_TYPE = PRI_SEC_OTH_TYPE != null ? PRI_SEC_OTH_TYPE.trim().toUpperCase() : "";
            let elgDif = elgDifrnce != null ? elgDifrnce.toUpperCase() : "";
            if (eligiblity == "ACTIVE") {
                colorClass = "green";
            } else
                if (eligiblity == "INACTIVE") {
                    colorClass = "red";
                }
                else if
                    (eligiblity == "Rejected") {
                    colorClass = "magenta";
                }
                else if
                    (eligiblity == "" || eligiblity == "S") {
    
                    colorClass = "gray";
                } else if
                    (subscriberName == "") {
                    colorClass = "gray";
                }
    
    
            if ((eligiblity.toUpperCase() == "A" || eligiblity.toUpperCase() == "ACTIVE") && (elgDif == "P3" || elgDif == "PRP")
                && (PRI_SEC_OTH_TYPE.trim().toUpperCase() == "P")) {
                colorClass = "orange";
            }
            else if ((eligiblity.toUpperCase() == "A" || eligiblity.trim().toUpperCase() == "ACTIVE") && (elgDif == "P3" || elgDif == "SEP")
                && PRI_SEC_OTH_TYPE == "S") {
                colorClass = "orange";
            }
    
            return colorClass;
        }
    
        GetFilesNames(event) {
            let filesName = "";
            if (event != undefined) {
                for (let i = 0; i < event.target.files.length; i++) {
                    filesName += event.target.files[i].name + "/";
                }
            }
            return filesName != "" ? filesName.substr(0, filesName.length - 1) : "";
        }
    
        //Added for the Demographics
        static setFilterColumns(columns: any = []) {
            this.filteredColumns = [];
            if (columns != null && columns != undefined && columns.length > 0) {
                for (var i = 0; i < columns.length; i++) {
                    this.filteredColumns.push(columns[i]);
                }
            }
        }
    
        //static CheckUserModule(module: string): boolean {
        //    if (this.userPrivileges != undefined && this.userPrivileges != null && this.userPrivileges.length > 0) {
        //        for (var i = 0; i < this.userPrivileges.length; i++) {
        //            if (this.userPrivileges[i]["Module_Id"] == module) {
        //                return true;
        //            }
    
        //        }
        //    }
        //    return false;
        //}
        //Ended for the Demographics
    
        isValidDate(date) {
            var rxDatePattern = /^(\d{1,2})(\/|-)(\d{1,2})(\/|-)(\d{4})$/; //Declare Regex
            var dtArray = date.match(rxDatePattern); // is format OK?
            return (dtArray != null) ? true : false;
        }
    
        //region sorting method (generic, added by solat)
        sortList(property, itemList, event) {
            var self = this;
    
            //reset the sorting icons
            this.reset_SortIcons();
    
            //change the direction
            this.isDesc = !this.isDesc;
    
            if (!!itemList.reduce(function (a, b) { return (a[property] === b[property]) ? a : NaN; }, 0)) {
    
                var orderClass = (this.isDesc) ? 'headerSortDown' : 'headerSortUp';
                event.target.classList.add(orderClass)
                return itemList;
            }
    
            //sort array in respective order
            var theItem; var i = 0; var value; var data = itemList; var allNumbers = true; var allDates = true; var allBoolean = true;
            var allEmpty = true;
    
            //check if this property values are all numeric or not..
            try {
                for (i = 0; i < itemList.length; i++) {
                    //current item
                    theItem = itemList[i];
                    value = theItem[property];
                    if (value != "" && value != null && value != undefined) {
    
                        allEmpty = false;
    
                        //check if boolean
                        if (value != true && value != false && typeof (value) != "boolean") {
                            allBoolean = false
                        }
                        else {
                            //value is a boolean
                            allNumbers = false;
                            allDates = false;
                        }
    
                        if (!allBoolean) {
                            value = value.toString();
                            //check if number
                            if (isNaN(value)) {
    
                                allNumbers = false;
    
                                //string value
                                if (allBoolean == false) {
                                    if (!self.isValidDate(value)) {
                                        allDates = false;
                                    }
                                }
                            }
                        }
                    }
                }
                if (allEmpty) {
                    //console.log("All empty list, do  not sort..");
                    data = itemList;
                }
                else {
                    if (allNumbers) {
                        //if all values in this column are numeric...
                        data = itemList.sort(function (a, b) {
                            function getValue(v) {
    
                                if (v == null || v == undefined)
                                    v = "";
    
                                v = v.toString();
                                if (!v.includes(".") && !v.includes(",")) {
                                    return v;
                                }
    
                                if (v.includes(".") && v.includes(",")) {
                                    return parseFloat(v).toFixed(0).replace(',', '');
                                }
                                else if (v.includes(".") && !v.includes(",")) {
                                    return parseFloat(v).toFixed(0);
                                }
                                else if (!v.includes(".") && v.includes(",")) {
                                    return parseFloat(v).toFixed(0).replace(',', '');
                                }
                                else {
                                    return parseFloat(v).toFixed(0).replace(/,/g, '').replace(/./g, '');
                                }
                            }
                            var number1 = getValue(a[property]);
                            var number2 = getValue(b[property]);
                            if (self.isDesc) {
                                //descending order
                                if (number1 == number2) return 0;
                                else if (number2 == null) return -1;
                                else if (number1 == null) return 1;
                                else return number2 - number1;
                            }
                            else {
                                //ascending order
                                if (number1 == number2) return 0;
                                else if (number1 == null) return -1;
                                else if (number2 == null) return 1;
                                else return number1 - number2;
                            }
                        });
                    }
                    else {
                        if (allBoolean) {
                            data = itemList.sort(
                                function (a, b) {
                                    let bool1 = a[property];
                                    let bool2 = b[property];
    
                                    if (self.isDesc) {
                                        //descending order
                                        if (bool1 == bool2) return 0;
                                        else return ((bool2 && !bool1) ? 1 : -1);
                                    }
                                    else {
                                        //ascending order
                                        if (bool1 == bool2) return 0;
                                        else return ((!bool2 && bool1) ? 1 : -1);
                                    }
                                }
                            );
                        }
                        else {
                            //set empty string
                            for (i = 0; i < itemList.length; i++) {
    
                                //current item
                                theItem = itemList[i];
                                value = theItem[property];
                                if (value == null || value == undefined) {
                                    theItem[property] = "";
                                }
                                if (value != null && value != undefined && value != "") {
                                    allEmpty = false;
                                }
                            }
    
                            if (allDates) {
                                data = itemList.sort(
                                    function (a, b) {
                                        let date1 = a[property];
                                        let date2 = b[property];
                                        var result;
                                        if (self.isDesc) {
                                            if (date1 == "" && date2 == "") {
                                                result = 0;
                                            }
    
                                            if (date1 == "") {
                                                result = 1;
                                            }
                                            else if (date2 == "") {
                                                result = -1;
                                            }
                                            else {
                                                date1 = new Date(date1);
                                                date2 = new Date(date2);
    
                                                if (date1.getTime() === date2.getTime())
                                                    result = 0;
                                                else
                                                    return (date2 > date1) ? 1 : -1;
                                            }
                                        }
                                        else {
                                            if (date1 == "" && date2 == "") {
                                                result = 0;
                                            }
    
                                            if (date1 == "") {
                                                result = -1;
                                            }
                                            else if (date2 == "") {
                                                result = 1;
                                            }
                                            else {
                                                date1 = new Date(date1);
                                                date2 = new Date(date2);
    
                                                if (date1.getTime() === date2.getTime())
                                                    result = 0;
                                                else
                                                    result = (date2 < date1) ? 1 : -1;
                                            }
                                        }
                                        return result;
                                    }
                                );
                            }
                            else {
                                data = _.orderBy(itemList, [property], [(this.isDesc) ? 'desc' : 'asc']);
                            }
                        }
                    }
                }
    
                //change the sorting icon
                var orderClass = (this.isDesc) ? 'headerSortDown' : 'headerSortUp';
                event.target.classList.add(orderClass)
    
                //return the sorted array
                return data;
            }
            catch (e) {
                console.log(e);
            }
        }
    
        reset_SortIcons() {
            $(".sortable-table-with-freezeHeader th").each(function () {
                $(this).removeClass("headerSortUp");
                $(this).removeClass("headerSortDown");
                $(this).addClass("header");
            });
            this.removeSortingIcons();
        }
    
        // compareTime(time1, time2) {
        //     var re = /^([012]?\d):([0-6]?\d)\s*(a|p)m$/i;
        //     time1 = time1.match(re);
        //     time2 = time2.match(re);
        //     if (time1 && time2) {
        //         var is_pm1 = /p/i.test(time1[3]) ? 12 : 0;
        //         var hour1 = (time1[1] * 1 + is_pm1) % 12;
        //         var is_pm2 = /p/i.test(time2[3]) ? 12 : 0;
        //         var hour2 = (time2[1] * 1 + is_pm2) % 12;
        //         if (hour1 != hour2) return (hour1 > hour2) ? 1 : 0;
    
        //         var minute1 = time1[2] * 1;
        //         var minute2 = time2[2] * 1;
        //         return (minute1 > minute2) ? 1 : 0;
        //     }
        // }
    
        //compareTime with 24 hour formate ( Parameters nowTime = '01:12:00 AM' , givenTime = '01:12:00 AM' )
        // compareTimeStanderdFormate(givenTime, nowTime) {
        //     nowTime = moment(nowTime, 'hh:mm A').format('HH:mm');     // converting to 24 hours formate
        //     givenTime = moment(givenTime, 'hh:mm A').format('HH:mm'); // converting to 24 hours formate
        //     var re = /^([01]\d|2[0-3]):?([0-5]\d)$/i;
        //     nowTime = nowTime.match(re);
        //     givenTime = givenTime.match(re);
        //     if (nowTime && givenTime) {
        //         if (nowTime[1] != givenTime[1]) return (nowTime[1] > givenTime[1]) ? true : false; // hours compare;
        //         return (nowTime[2] > givenTime[2]) ? true : false; // minutes compare
        //     }
        // }
    
        applySortIcons() {
            //apply sort icons
            $("table.sortable-table-with-freezeHeader th").each(function () {
                $(this).addClass("header");
            });
            this.removeSortingIcons();
        }
    
        applySortIcons_and_FreezeHeaders() {
            let theTable: any = $("table.sortable-table-with-freezeHeader");
    
            //apply sort icons
            $("table.sortable-table-with-freezeHeader th").each(function () {
                $(this).addClass("header");
            });
    
            this.removeSortingIcons();
    
            //freeze headers (using float-Thead jquery plugin)
            theTable.floatThead({
                position: 'fixed',
                scrollContainer: function ($table) {
                    return theTable.closest('.table-responsive');
                },
                autoReflow: true,
                debug: true
            });
        }
    
        destroyFixedHeader() {
            var theTable = $("table.sortable-table-with-freezeHeader");
        //    theTable.floatThead('destroy');
        }
    
        //endregion
    
        //region Common Methods
    






        static getObjectFromLocalStorage(userId: string, name: string): string {
            var value = localStorage.getItem(userId + "_" + name);
            if (value == null || value == undefined) return "0";
            else return value.toString();
        }
    
        // static compareDate(date1: string, date2: string): number {
        //     let d1 = new Date(date1); let d2 = new Date(date2);
        //     // Check if the first is greater than second
        //     if (d1 > d2) return 1;
        //     // Check if the first is less than second
        //     if (d1 < d2) return -1;
        // }
    
        static getFilePath(fileName: string, type: string = "temp"): string {
            let originalPath = window.location.origin;
            let virtualPath: string = "";
            let isLivePath: boolean = false;
            let result: string = "";
    
            if (originalPath.includes("10.20.25.34:8060") || originalPath.includes("10.20.25.34:7070")) {
                //Live Deploy
                virtualPath = "http://172.16.0.120:5555/";
                if (type == "temp" || type == "temp_fax") {
                    result = "http://10.20.25.34:5555/" + type + "/" + fileName;
                } else {
                    result = virtualPath + type + "/" + fileName;
                }
            } else if (originalPath.includes("10.20.25.33") || originalPath.includes("10.20.25.34")) {
                //NJ Deploy
                virtualPath = "http://10.10.30.70:5555/";
                result = virtualPath + type + "/" + fileName;
            } else if (originalPath.includes("localhost") || originalPath.includes("172.16.0.27") || originalPath.includes("172.16.0.49") || originalPath.includes("10.20.25.32")) {//for emr-srv1
                //Local
                virtualPath = "http://172.16.0.27:5555/";
                result = virtualPath + type + "/" + fileName;
            } else {
                virtualPath = BillingUtills.getWebAddress();
                result = virtualPath + type + "/" + fileName;
            }
    
            return result;
        }
    
        static getWebAddress(): string {
            //let host = window.location.host;
            let host = window.location.origin;
            //let address = "http://" + host + "/";
            let address = host + "/";
            BillingUtills.webIP = address;
            return address;
        }
    
        removeSortingIcons() {
            $("table.sortable-table-with-freezeHeader th.no-sorting, table.sortable-table-with-freezeHeader th.no-sorting-icon, table.sortable-table-with-freezeHeader th.no-sort-icon").each(function () {
                $(this).removeClass("header");
            });
        }
    
        static isNullOrUndefined(value: any) {
            return (value == null || value == undefined) ? true : false;
        }
    
        notNullOrUndefined(value: any) {
            return (value == null || value == undefined) ? true : false;
        }
    
        static isNullOrZero(value: any) {
            return (value == null || value == undefined || value == 0) ? true : false;
        }
    
        static isArrayNullOrZero(value: any) {
            return (value == null || value == undefined || value.length == 0) ? true : false;
        }
    
        static showHideLoader() {
            if ($("#spinnerLoaderCustom").css("display") == "none") {
                $("#spinnerLoaderCustom").show();
            } else {
                $("#spinnerLoaderCustom").hide();
            }
        }
    
        static hideLoader() {
            $("#spinnerLoaderCustom").hide();
        }
    
        isChildModuleActive(): boolean {
            return false;
        }
    
        static validateSpecialCharacter(event): boolean {
            var k;
            k = event.charCode;  //         k = event.keyCode;  (Both can be used)
            return ((k > 64 && k < 91) || (k > 96 && k < 123) || k == 8 || k == 32 || (k >= 48 && k <= 57));
        }
    
        static validateDecimal(value: string): boolean {
            var date_regex = /^(-?\d*)((\.(\d{0,2})?)?)$/;
            //if (value.split('.').length > 2)
            //   return false;
            return date_regex.test(value);
    
        }
    
        static isTimeDifference24Hours(date: any, called_from: string = ""): boolean {
            debugger
            if (BillingUtills.isStringNullOrEmpty(date)) return false;
            var createdDatetime = new Date(date);
            var currentDateTime = new Date();
            var diff = (currentDateTime.getTime() - createdDatetime.getTime()) / 1000;
            diff = diff / (60 * 60);
            if (called_from == "") {
                if (diff <= 13) return true;
                else return false;
            }
            else if (called_from == "sscm") {
                if (diff <= 24) return true;
                else return false;
            }
            else return false;
        }
    
        static validateTime(value: string): boolean {
            var date_regex = /^(0[0-9]|1[0-9]|2[0-3]):[0-5][0-9]$/;
            return date_regex.test(value);
        }
    
        static setPhoneFormat(value) {
            if (value) {
                if (this.isStringNullOrEmpty(value))
                    return;
                var org = value.toString();
                value = value.toString();
                value = value.replace("(", "").replace(")", "").replace("-", "").replace(" ", "");
                if (value.length == 10) {
                    if (!isNaN(value)) {
                        return "(" + value.substring(0, 3) + ") " + value.substring(3, 6) + "-" + value.substring(6, 10);
                    } else {
                        return value;
                    }
                } else {
                    return value;
                }
            } else {
                return org;
            }
        }
    
        static formatZip(zip: string) {
            debugger
            var newzip = zip;
            if (!BillingUtills.isStringNullOrEmpty(zip)) {
                if (zip.length > 5 && zip.length < 10) {
                    newzip = zip.substring(0, 5) + '-' + zip.substring(5);
                }
            }
            return newzip;
        }
    

        
    validateDateSearch(dateFrom: any, dateTo: any, dateFromElementId: string = "datefrom", dateToElementId: string = "dateto") {
        dateFrom = $("#" + dateFromElementId + " input").val();
        dateTo = $("#" + dateToElementId + " input").val();

        if ((BillingUtills.isStringNullOrEmpty(dateFrom) || dateFrom == "01/01/1900" || dateTo == "1/1/1900")) {
            this._modelUtills.showAlertMessage("Select From Date.", MessageType.error);
            $("#" + dateFromElementId + " input").focus();
            return false;
        }
        if (!BillingUtills.validateDateRegex(dateFrom)) {
            this._modelUtills.showAlertMessage("Invalid From Date (MM/DD/YYYY).", MessageType.error);
            $("#" + dateFromElementId + " input").focus();
            return false;
        }
        if ((BillingUtills.isStringNullOrEmpty(dateTo) || dateTo == "01/01/1900" || dateTo == "1/1/1900")) {
            this._modelUtills.showAlertMessage("Select To Date.", MessageType.error);
            $("#" + dateToElementId + " input").focus();
            return false;
        }
        if (!BillingUtills.validateDateRegex(dateTo)) {
            this._modelUtills.showAlertMessage("Invalid To Date (MM/DD/YYYY).", MessageType.error);
            $("#" + dateToElementId + " input").focus();
            return false;
        }
        if (new Date(dateFrom) > new Date(dateTo)) {
            this._modelUtills.showAlertMessage("From Date should be prior than To Date.", MessageType.error);
            $("#" + dateToElementId + " input").focus();
            return false;
        }
        if (dateFrom != null && dateFrom != "" && dateFrom != undefined) {
            if ((new Date(dateFrom).getFullYear() > new Date().getFullYear())) {
                this._modelUtills.showAlertMessage("Date must be equal or prior to current date.", MessageType.error);
                $("#" + dateFromElementId + " input").focus();
                return false;
            }
        }
        if (dateTo != null && dateTo != "" && dateTo != undefined) {
            if ((new Date(dateTo).getFullYear() > new Date().getFullYear())) {
                this._modelUtills.showAlertMessage("Date must be equal or prior to current date.", MessageType.error);
                $("#" + dateToElementId + " input").focus();
                return false;
            }
        }
        return true;
    }

    hideCalender() {
        $('.datepicker.datepicker-dropdown').css("display", "none");
    }

    static decryptData(data) {
        try {
            const bytes = CryptoJS.AES.decrypt(data, "talkEHR");
            if (bytes.toString()) {
                return JSON.parse(bytes.toString(CryptoJS.enc.Utf8));
            }
            return data;
        } catch (e) {
            console.log(e);
        }
    }

    // static encryptData(data) {
    //     try {
    //         return CryptoJS.AES.encrypt(JSON.stringify(data), "talkEHR").toString();
    //     } catch (e) {
    //         console.log(e);
    //     }
    // }

    static encryptFlag(flag, pass: string) {
        let newPass = '';
        if (flag == 1) {
            newPass = pass.substring(0, 1) + Flag.S1 + pass.substring(1, pass.length - 1) + Flag.L1 + pass.substring(pass.length - 1);
        }
        if (flag == 2) {
            newPass = pass.substring(0, 2) + Flag.S2 + pass.substring(2, pass.length - 2) + Flag.L2 + pass.substring(pass.length - 2);
        }
        if (flag == 3) {
            newPass = pass.substring(0, 3) + Flag.S3 + pass.substring(3, pass.length - 3) + Flag.L3 + pass.substring(pass.length - 3);
        }
        if (flag == 4) {
            newPass = pass.substring(0, 4) + Flag.S4 + pass.substring(4, pass.length - 4) + Flag.L4 + pass.substring(pass.length - 4);
        }
        if (flag == 5) {
            newPass = pass.substring(0, 5) + Flag.S5 + pass.substring(5, pass.length - 5) + Flag.L5 + pass.substring(pass.length - 5);
        }
        return newPass;
    }

    static decryptFlag(flag, pass) {
        let newPass = '';
        if (flag == 1) {
            newPass = pass.substring(0, 1) + pass.substring(6, pass.length - 6) + pass.substring(pass.length - 1);
        }
        if (flag == 2) {
            newPass = pass.substring(0, 2) + pass.substring(7, pass.length - 7) + pass.substring(pass.length - 2);
        }
        if (flag == 3) {
            newPass = pass.substring(0, 3) + pass.substring(8, pass.length - 8) + pass.substring(pass.length - 3);
        }
        if (flag == 4) {
            newPass = pass.substring(0, 4) + pass.substring(9, pass.length - 9) + pass.substring(pass.length - 4);
        }
        if (flag == 5) {
            newPass = pass.substring(0, 5) + pass.substring(10, pass.length - 10) + pass.substring(pass.length - 5);
        }
        return newPass;

    }

    static getRandomNumberBetween(min: number, max: number) {
        return Math.floor(Math.random() * (max - min + 1) + min);
    }

    static makeRandString(length) {
        var result = '';
        var characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
        var charactersLength = characters.length;
        for (var i = 0; i < length; i++) {
            result += characters.charAt(Math.floor(Math.random() * charactersLength));
        }
        return result;
    }
    setRowStyle(boolValue: boolean) {
        let styles;
        if (boolValue) {
            styles = {
                'background-color': 'lightyellow',
                'color': 'green',
                'font-weight': 'bold',
            };
        } else {
            styles = {
            };
        }
        return styles;
    }


    static getFormattedYear(stringDate: string) {
        stringDate = BillingUtills.isStringNullOrEmpty(stringDate) ? "" : stringDate;
        stringDate = new Date(stringDate).toLocaleDateString('en-US', { year: "numeric", month: "2-digit", day: "2-digit" });

        return stringDate.split("/")[2];
    }

    // static getFormattedMonth(stringDate: string) {
    //     stringDate = BillingUtills.isStringNullOrEmpty(stringDate) ? "" : stringDate;
    //     stringDate = new Date(stringDate).toLocaleDateString('en-US', { year: "numeric", month: "2-digit", day: "2-digit" });

    //     var month = stringDate.split("/")[0].toString();
    //     if (month == "01" || month == "1") return "January";
    //     else if (month == "02" || month == "2") return "February";
    //     else if (month == "03" || month == "3") return "March";
    //     else if (month == "04" || month == "4") return "April";
    //     else if (month == "05" || month == "5") return "May";
    //     else if (month == "06" || month == "6") return "June";
    //     else if (month == "07" || month == "7") return "July";
    //     else if (month == "08" || month == "8") return "August";
    //     else if (month == "09" || month == "9") return "September";
    //     else if (month == "10") return "October";
    //     else if (month == "11") return "November";
    //     else if (month == "12") return "December";
    // }

    static getFormattedDate(stringDate: string) {
        stringDate = BillingUtills.isStringNullOrEmpty(stringDate) ? "" : stringDate;
        stringDate = new Date(stringDate).toLocaleDateString('en-US', { year: "numeric", month: "2-digit", day: "2-digit" });

        let day: string = stringDate.split("/")[1];
        let month: string = stringDate.split("/")[0];
        let year: string = stringDate.split("/")[2];
        year = year[2] + year[3];
        return month + day + year;
    }













}