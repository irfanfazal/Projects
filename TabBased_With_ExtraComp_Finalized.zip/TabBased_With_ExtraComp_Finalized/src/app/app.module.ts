import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { RouterModule } from '@angular/router';
import { AFUtillsService } from './afutills.service';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BillingAgingComponent } from './billing-aging/billing-aging.component';
import { ClaimStatusComponent } from './claim-status/claim-status.component';
import { MonthEndComponent } from './month-end/month-end.component';
import { TabCompComponent } from './tab-comp/tab-comp.component';


@NgModule({
  declarations: [
    AppComponent,
    BillingAgingComponent,
    ClaimStatusComponent,
    MonthEndComponent,
    TabCompComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    BrowserModule,
    RouterModule,
    HttpClientModule,
    ReactiveFormsModule,
    AppRoutingModule
  ],
  providers: [AFUtillsService],
  bootstrap: [AppComponent]
})
export class AppModule { }
