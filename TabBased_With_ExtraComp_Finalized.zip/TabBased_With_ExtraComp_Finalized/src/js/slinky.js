! function (e) {
    var s;
    e.fn.slinky = function (a) {
        var t = e.extend({
            label: "Back",
            title: !1,
            speed: 300,
            resize: !0,
            activeClass: "active",
            headerClass: "header",
            headingTag: "<h2>",
            backFirst: !1
        }, a),
            i = e(this),
            n = i.children().first();
        i.addClass("slinky-menu");
        var l = function (e, s) {
            var a = Math.round(parseInt(n.get(0).style.left)) || 0;
            n.css("left", a - 100 * e + "%"), "function" == typeof s && setTimeout(s, t.speed)
        },
            r = function (e) {
                i.height(e.outerHeight())
            },
            d = function (e) {
                i.css("transition-duration", e + "ms"), n.css("transition-duration", e + "ms")
            };
        if (d(t.speed), e("a + ul", i).prev().addClass("next"), e("li > ul", i).prepend('<li class="' + t.headerClass + '">'), t.title === !0 && e("li > ul", i).each(function () {
                var s = e(this).parent().find("span").first().text(),
                    a = e(t.headingTag).text(s);
                e("> ." + t.headerClass, this).append(a)
        }), t.title || t.label !== !0) {
            var c = e("<a>").text(t.label).prop("href", "#").addClass("back");
            t.backFirst ? e("." + t.headerClass, i).prepend(c) : e("." + t.headerClass, i).append(c)
        } else e("li > ul", i).each(function () {
            var s = e(this).parent().find("a").first().text(),
                a = e("<a>").text(s).prop("href", "#").addClass("back");
            t.backFirst ? e("> ." + t.headerClass, this).prepend(a) : e("> ." + t.headerClass, this).append(a)
        });
        e("a", i).on("click", function (a) {
            if (s + t.speed > Date.now()) return !1;
            s = Date.now();
            var n = e(this);
            (/\B#/.test(this.href) || n.hasClass("next") || n.hasClass("back")) && a.preventDefault(), n.hasClass("next") ? (i.find("." + t.activeClass).removeClass(t.activeClass), n.next().show().addClass(t.activeClass), l(1), t.resize && r(n.next())) : n.hasClass("back") && (l(-1, function () {
                i.find("." + t.activeClass).removeClass(t.activeClass), n.parent().parent().hide().parentsUntil(i, "ul").first().addClass(t.activeClass)
            }), t.resize && r(n.parent().parent().parentsUntil(i, "ul")))
        }), this.jump = function (s, a) {
            s = e(s);
            var n = i.find("." + t.activeClass);
            n = n.length > 0 ? n.parentsUntil(i, "ul").length : 0, i.find("ul").removeClass(t.activeClass).hide();
            var c = s.parentsUntil(i, "ul");
            c.show(), s.show().addClass(t.activeClass), a === !1 && d(0), l(c.length - n), t.resize && r(s), a === !1 && d(t.speed)
        }, this.home = function (s) {
            s === !1 && d(0);
            var a = i.find("." + t.activeClass),
                n = a.parentsUntil(i, "li").length;
            n > 0 && (l(-n, function () {
                a.removeClass(t.activeClass)
            }), t.resize && r(e(a.parentsUntil(i, "li").get(n - 1)).parent())), s === !1 && d(t.speed)
        }, this.destroy = function () {
            e("." + t.headerClass, i).remove(), e("a", i).removeClass("next").off("click"), i.removeClass("slinky-menu").css("transition-duration", ""), n.css("transition-duration", "")
        };
        var h = i.find("." + t.activeClass);
        return h.length > 0 && (h.removeClass(t.activeClass), this.jump(h, !1)), this
    }
}(jQuery);