

//  =======Tabs Remain Selected on page refresh=======//
$(function() { 
		  //for bootstrap 3 use 'shown.bs.tab' instead of 'shown' in the next line
	$('a[data-toggle="tab"]').on('click', function (e) {
			//save the latest tab; use cookies if you like 'em better:
			localStorage.setItem('lastTab', $(e.target).attr('href'));
	});
		
		  //go to the latest tab, if it exists:
	var lastTab = localStorage.getItem('lastTab');
		
		  if (lastTab) {
			  $('a[href="'+lastTab+'"]').click();
	}
});
		
		
//  =======Popover on click=======//
$(function () {
	$("[data-toggle=popover]").popover();
	
	$(".popover-section").css("display","none");
	
	$('.popover-bottom').popover({
		html:true,
		placement:'auto bottom',
		//trigger: 'hover',
		content:function(){
			return $($(this).data('popwrapper')).html();
		}
	});
	
	$('.popover-left').popover({
		html:true,
		placement: 'auto left',
		//trigger: 'hover',
		content:function(){
			return $($(this).data('popwrapper')).html();
		}
	});
	
	$('.popover-top').popover({
		html:true,
		placement: 'auto top',
		//trigger: 'hover',
		content:function(){
			return $($(this).data('popwrapper')).html();
		}
	});
	
	$('.popover-right').popover({
		html:true,
		placement: 'auto right',
		//trigger: 'hover',
		content:function(){
			return $($(this).data('popwrapper')).html();
		}
	});
	
	
	//$('.popover-bottom-right').popover({
//		html:true,
//		placement:'position = {top: pos.top + pos.height, right: pos.left + pos.width - actualWidth};',
//		content:function(){
//			return $($(this).data('popwrapper')).html();
//		}
//	});

});

//  =======PopOver close=======//

//color Picker
$('.colorpicker').colorpicker();
///////////
	var $elements = $('[rel=popover]');
	$elements.each(function () {
	var $element = $(this);

	$element.on('shown.bs.popover', function () {
		var popover = $element.data('bs.popover');
		if (typeof popover !== "undefined") {
			var $tip = popover.tip();
			zindex = $tip.css('z-index');
			
			$tip.find('.close').bind('click', function () {
				popover.hide();
			});
			$tip.find('.pop-cancel').bind('click', function () {
				popover.hide();
			});
			
		}
	});
});



//$(document).ready(function() {
//	
//	
//    $('table td .popover-right').click(function() {
//	    if($('.popover').hasClass('in')) {
//	      $(this).parent().parent().parent().parent().addClass('disabled-content');
//			$(this).addClass('enable-content');
//			
//	    }
//	   else {
//	      $(this).parent().parent().parent().parent().removeClass('disabled-content');
//			$(this).removeClass('enable-content');
//	    }
//	});
//	
//	$('.popover .popup-title .close').click(function() {
//	    $('table').removeClass('disabled-content');
//	});
//
//});



//  =======Add Responsive class outside of table=======//

	!$('table').parent().hasClass('table-responsive') && $('table').wrap('<div class="table-responsive" />');


//  =======Patient List Note Settings=======//
$("#notes .note-settings .icon").click(function(e){
	$("#notes .note-settings .note-setting-list").slideToggle();
});


//  =======Patient List Note Columns Slides=======//
$("#notes .slide-panel").click(function(e){
	//$( "#notes .notes-content .notes-list" ).toggle( "slide" );
	//$("#notes .notes-content").toggleClass("full-width");
});


//  =======Page Modal/Popup Style=======//
$("#amazing-fusion .modal .modal-right .close-panel a").off('click').click(function(e){
        $("#amazing-fusion .modal .modal-dialog .modal-left" ).toggle( 'slow' );
        $("#amazing-fusion .modal .modal-right .close-panel a i").toggleClass("app-icon-IconSet-1-70");
});

//  =======Family History Modal/Popup Style=======//

$("#amazing-fusion .modal-page .modal-right .family-history-popup").click(function(e){
	$( "#past-medical-history" ).css('display','none');
});

$("#amazing-fusion #family-history .family-history-close").click(function(e){
	$( "#past-medical-history" ).css('display','block');
});


//  =======Social History Modal/Popup Style=======//

$("#amazing-fusion .modal-page .modal-right .social-history-popup").click(function(e){
	$( "#past-medical-history" ).css('display','none');
});

$("#amazing-fusion #patient-social-history .social-history-close").click(function(e){
	$( "#past-medical-history" ).css('display','block');
});


//  =======Date and Time Picker Style=======//
	  

  
  
//  =======Scroll for width Style=======//  
//$(".scroller-width").mCustomScrollbar({
//	axis:"x",
//	advanced:{
//		autoExpandHorizontalScroll:true
//	}
//});

  
 //  =======Recent Notes Menu=======// 

$('#patient-list #notes .notes-list li').click(function(e){
	$('#patient-list #notes .notes-list li').removeClass('selected');
	$(this).addClass('selected');
});
  
 
//  =======Add Scroller Height outside the Modal Body=======// 
$(".mCustomScrollbar").mCustomScrollbar({
    mouseWheelPixels: 70
});



//  =======Document Change on next and previous=======// 
$(".next-doc").click(function(e) {
	$("#document-viewer iframe").attr("src","documents/doc.jpg");  
});
$(".prev-doc").click(function(e) {
	$("#document-viewer iframe").attr("src","documents/doc.pdf");  
});
  
 //  =======Popover=======// 
 
$(function () {
  $('[data-toggle="popover"]').popover()
})

 
 //  =======Switch ON/Off change text=======// 
 
$(".switch input").click(function() {
	if($(this).is(':checked')) {
		$(".switch .value").text("Active");
	} else {
		$(".switch .value").text("Inactive");
	}
});

  

 //  =======On Width 767px hide note listing=======// 
$(document).ready(function() {
	function checkWidth() {
		var windowSize = $(window).width();

		if (windowSize < 767) {
			$("#patient-list #details #notes .notes-content").addClass("full-width");
		}
	}
	// Execute on load
	checkWidth();
	// Bind event listener
	$(window).resize(checkWidth);
	if (!$('.sliding-modules').hasClass('slinky-menu'))
	{
	    $('.sliding-modules').slinky({
	        title: true,
	    });
	}
});
 
  //  =======Medication Alert Popup=======// 
 $("#Medicine-alert").click(function(e) {
	$("#Medicine-alert-box").slideToggle();
});
 $("#Medicine-alert-box .medicine-close").click(function(e) {
	$("#Medicine-alert-box").slideToggle();
});
 
 
 
  //  =======Medication Build Sig=======// 
   $("#build-sig").click(function(e) {
	$("#build-sig-box").slideToggle();
});
 $("#build-sig-box .build-sig-close").click(function(e) {
	$("#build-sig-box").slideToggle();
});

$("#build-sig-box .build-sig-box ul li").click(function(e) {
	$("#build-sig-box .build-sig-box ul li").removeClass("active");
	$(this).addClass("active");
});

  
  
 
 //  =======Immunizations Inventory Setup Popup=======// 
 $("#amazing-fusion #immunizations .inventory-setup").click(function(e){
	$( "#immunizations" ).css('display','none');
});

$("#amazing-fusion #inventory-setup .inventory-setup-close").click(function(e){
	$( "#immunizations" ).css('display','block');
});
 
 
 
 
 
 //  =======Message Main Navigation=======// 
 
$("#messages .message-navigation li").click(function() {
	$("#messages .message-navigation li").removeClass("active");
	$(this).addClass("active");
});



 //  =======Text Editor=======// 
editor();
htmlEditor('.editor', '');
//$('[title]').tooltip();
$('body').tooltip({selector: '.template-view-setting a:first-child' , trigger :'hover'});


function IstouchDevice() { 
    var isMobile = false; //initiate as false
        // device detection
        if (/(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|ipad|iris|kindle|Android|Silk|lge |maemo|midp|mmp|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows (ce|phone)|xda|xiino/i.test(navigator.userAgent)
            || /1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i.test(navigator.userAgent.substr(0, 4))) {
            isMobile = true;
            }
        return isMobile;
        }
if (IstouchDevice() === false) {
    $("[rel='tooltip']").tooltip();
}
if (IstouchDevice() === true) {
$('[title]').tooltip("disable");
}

// //  =======Table Dragable=======// 
//$(".table-row-dragable").rowSorter({});


// //  =======List Dragable=======// 

//$( ".sortable" ).sortable();
//$( ".sortable" ).disableSelection();





//  =======Enable Search if has value=======// 

$('.search input.form-control').on('keyup', function () {
	$(".search input.form-control").filter(function () {
		this.value == '' ? $('.search').addClass('empty-field') : $('.search').removeClass('empty-field')
	});
});


//  =======collapsible table rows=======// 
$('.collapsable-table .collapse-row').click(function(){
   $(this).find('span').text(function(_, value){return value=='+'?'-':'+'});
	$(this).nextUntil('tr.collapse-row').toggle();
});



//  =======Generic Dropdown=======// 
$(".slide-click").click(function(e) {
	$(this).parent().next(".slide-content").slideToggle(300);
	e.stopPropagation();
});



//  =======Right Panel Edit=======// 

$(".edit-items").click(function(e) {
	$("ul.add-review-list").toggleClass("sortable");
});

//  =======Message Details Style=======// 

$("#mail-list-view .show-mail-details").click(function (e) {
	$("#email-detail-veiw").css('display', 'block');
	$(".back-mail-list").css('display', 'block');
	$("#mail-list-view").css('display', 'none');
});
$(".back-mail-list").click(function (e) {
	$("#email-detail-veiw").css('display', 'none');
	$("#mail-list-view").css('display', 'block');
	$(".back-mail-list").css('display', 'none');
});


//  =======Message Details open/close Style=======// 
$(".message-heading").click(function (e) {
	$(this).next(".message-body").slideToggle(300);
	e.stopPropagation();
});

//  ======= Dashboard Add Class=======//
$('#dashboard .nav-tabs li:first-child').addClass('dashboard-bg');
$('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
    if ($('#dashboard-tab').hasClass('active')) {
        $('#dashboard-tab').parent().addClass('dashboard-bg');
        //$('body').addClass('dashboard-bg');
    } else {
        $('#dashboard-tab').parent().removeClass('dashboard-bg');
        //$('body').removeClass('dashboard-bg');
    }
});
//  ======= Update scroller on window resize=======//
$(window).resize(function () {
    $(".mCustomScrollbar").mCustomScrollbar("update");
});
//  ======= Toggle Button Animation =======//

$(".c-hamburger").click(function () {
    $(this).toggleClass('is-active');
});

function setCookie(name, value, expireDays, path) {
    path = path || "";
    let d = new Date();
    d.setTime(d.getTime() + expireDays * 24 * 60 * 60 * 1000);
    let expires = "expires=" + d.toUTCString();
    document.cookie = name + "=" + value + "; " + expires + (path.length > 0 ? "; path=" + path : "");
}
function deleteCookie(name) {
    this.setCookie(name, "", -1, "/");
}
window.addEventListener("beforeunload", function (e) {
    deleteCookie("username");
    document.getElementById('iframeDiv').innerHTML = "";
});
//Check Elgibility New Check
function printpage()
  {
  window.print();
  }


function Toggle(value,Length)
{
    var collaps = value;
    obj=document.getElementsByTagName('div');
    var arr = new Array(obj.length);
   for (var i = 0; i < Length; i++)
    {
      var d_id = 'dmain'+i;
      var a_id = 'amain'+i;
	try
	{
	      if(collaps == 'true')
	      {
	        document.getElementById(d_id).style.display = 'block';
	        document.getElementById(a_id).innerHTML='-'
	      }  
  	    else if(collaps == 'false')
	      {
        	document.getElementById(a_id).innerHTML='+'
	        document.getElementById(d_id).style.display = 'none';
	      }
	}
	catch(err)
	{
	}
    }
}
    
    
function CollapsExpand(Length)
{
	try
	{
       	 var obj = document.getElementById('mainAnch');
       	 if(obj.innerHTML=="+ Expand All")
       	 {
            Toggle('true',Length);  
            document.getElementById('mainAnch').innerHTML='- Collapse All'
            
         }
         else
         {
            
            Toggle('false',Length);
            document.getElementById('mainAnch').innerHTML='+ Expand All'
	    
         }
	return false;
	}
	catch(err)
	{
	}        
}


function toggle(control)
{
    var id = control.id;
    var d_id = id.replace('a','d')
     if(document.getElementById(id).innerHTML == '-')
     {
         document.getElementById(id).innerHTML = '+'
  	 document.getElementById('mainAnch').innerHTML='+ Expand All'
         document.getElementById(d_id).style.display = 'none';
      }
     else
     {  
        document.getElementById(id).innerHTML = '-'
        document.getElementById(d_id).style.display = 'block';
	document.getElementById('mainAnch').innerHTML='- Collapse All'
     }
     return false; 
}
function loadpage(heading, id) {
    $("#EligibilityDiv table").each(function () {
        $(this).attr('style', 'display:none');
    });
    document.getElementById("headingassign").innerHTML = heading;
    if ($("#Pat_tbl").length) {
        document.getElementById("Pat_tbl").style.display = '';
    }
    if ($("#Elig_tbl").length) {
        document.getElementById("Elig_tbl").style.display = '';
    }
    if ($("#Add_info_tbl").length) {
        document.getElementById("Add_info_tbl").style.display = '';
    }
    document.getElementById(id).style.display = '';

}
function myFunction() {
    var input, filter, ul, li, a, i;
    input = document.getElementById("myInput");
    filter = input.value.toUpperCase();
    ul = document.getElementById("myUL");
    li = ul.getElementsByTagName("li");
    for (i = 0; i < li.length; i++) {
        a = li[i].getElementsByTagName("a")[0];
        if (a.innerHTML.toUpperCase().indexOf(filter) > -1) {
            li[i].style.display = '';
        }
        else {
            li[i].style.display = 'none';

        }
    }
}

function printpage() {
    $("#EligibilityDiv table").each(function () {
        $(this).attr('style', 'display:');
    }); //
    $("EligibilityDiv .custom-panel-head1").show();
    $("#headingassign").hide(); //
    $("#benifits1").hide();

    $("#des").removeClass('col-8')
    $("#des").addClass('col-12')// <div id ="" class=""> 
    $("#tablescroll").removeClass('table-responsive table-scroll')
    $("#tablescroll").addClass('table-responsive')

    window.print();


    $("#EligibilityDiv table").each(function () {
        $(this).attr('style', 'display:none');
    });

    document.getElementById("Pat_tbl").style.display = '';
    document.getElementById("Elig_tbl").style.display = '';
    document.getElementById("Add_info_tbl").style.display = '';
    document.getElementById("1").style.display = '';
    $("EligibilityDiv .custom-panel-head1").hide();
    $("#headingassign").show(); //
    $("#benifits1").show();

    $("#des").removeClass('col-12')
    $("#des").addClass('col-8')// <div id ="" class=""> 
    $("#tablescroll").removeClass('table-responsive')
    $("#tablescroll").addClass('table-responsive table-scroll')
}
function startTour()
{
    if (localStorage.getItem('istour') != undefined)
    {
        localStorage.removeItem("istour");
    }
    localStorage.setItem("istour", "1");
}
function endTour()
{
    if (localStorage.getItem('istour') != undefined) {
        localStorage.removeItem("istour");
    }
    localStorage.setItem("istour", "0");
}
//Eligibility end here




