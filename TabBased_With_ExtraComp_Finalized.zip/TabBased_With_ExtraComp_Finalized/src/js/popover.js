﻿//  =======Popover on click=======//

$(function () {
    $('.aptt-popover').popover(),
    $('[rel = popover]').on('click', function (e) {
        $('[rel = popover]').not(this).popover('hide');
    });
    //$("#patPopOver tr").each(function () {
    //    $(this).children('td').slice(0, 2).attr("(click)", "openNewPatientTab(patientListObj.First_Name + ' ' + patientListObj.Last_Name,patientListObj.Patient_Account)");
    //});
    //$('#patPopOver tr td:not(:first-child)').attr("(click)", "openNewPatientTab(patientListObj.First_Name + ' ' + patientListObj.Last_Name,patientListObj.Patient_Account)");
});



$(function () {
    $('[rel=popover]').popover({
        html: true,
        placement: 'right',
        content: function () {
            return $($(this).data('popwrapper')).html();
        }
    }).on('shown.bs.popover', function () {
        var popup = $(this);
        $(this).parent().find("div.popover .close").click(function () {
            popup.click();
        });
    });
});