﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace Business_Layer.EFCoreCrud
{
    public interface IEfCoreCrudService
    {
        public List<Product_Category> GetCategoriesList();
        public Product_Category GetCustegoryById(int id);
        public void InsertProductCategory(Product_Category obj);
        public void UpdateCategory(Product_Category obj);
        public void DeleteProductCategory(int id);
        ///////////Products/////////////
        public List<my_Products> GetProductList();
        public void InsertProducts(my_Products obj);
        public my_Products GetProductById(int id);
        public string  updateProduct(my_Products myproduct);
        public string DeleteProductById(int id);
        public string myproject(int id);
    }
}
