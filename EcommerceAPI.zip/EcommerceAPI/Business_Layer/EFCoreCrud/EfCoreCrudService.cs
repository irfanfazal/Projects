﻿using Data_Access_Layer.DBContext;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Business_Layer.EFCoreCrud
{
    public class EfCoreCrudService : IEfCoreCrudService
    {
        private readonly EcommerceDBContext db;
        public EfCoreCrudService()
        {
            db = new EcommerceDBContext();
        }
        //   Directly By Database
        public List<Product_Category> GetCategoriesList()
        {
            return db.Product_Category.ToList();
        }
        public Product_Category GetCustegoryById(int id)
        {
            //var res= db.Customers.FromSqlRaw("select  * from Customers where id="+id).FirstOrDefault();
            var result = db.Product_Category.FirstOrDefault(res => res.id == id);
            return result;
        }
        public void InsertProductCategory(Product_Category obj)
        {
            db.Product_Category.Add(obj);
            db.SaveChanges();
        }
        public void UpdateCategory(Product_Category obj)
        {
            db.Product_Category.Attach(obj);
            db.Entry(obj).State = Microsoft.EntityFrameworkCore.EntityState.Modified;
            db.SaveChanges();
        }
        public void DeleteProductCategory(int id)
        {
            db.Remove(db.Product_Category.Find(id));
            db.SaveChanges();

        }
        ///////////////////////Products/////////////////
        public List<my_Products> GetProductList()
        {
            return db.my_Products.ToList();
        }
        public void InsertProducts(my_Products produts)
        {
            db.my_Products.Add(produts);
            db.SaveChanges();
        }
        [HttpGet]
        public my_Products GetProductById(int id)
        {
            //var res= db.Customers.FromSqlRaw("select  * from Customers where id="+id).FirstOrDefault();
            var result = db.my_Products.FirstOrDefault(res => res.productID == id);
            return result;
        }
        public string updateProduct( my_Products myproc)
        {
            
                db.Entry(myproc).State = Microsoft.EntityFrameworkCore.EntityState.Modified;
                db.SaveChanges();
                return "success";
            
        }
        public string DeleteProductById(int id)
        {


            var p = db.my_Products.FirstOrDefault(x => x.productID == id);
            if (p == null)
            {
                return "Invalid ID";
            }

            else
            {
                db.Remove(p);
                db.SaveChanges();
                return "Sucessfully deleted";
            }


        }
    }
  }


