﻿using Data_Access_Layer.DBContext;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bussinees_Access_Layer.Products
{
    public class Product_:IProducts
    {
        private readonly EcommerceDBContext db;
        public Product_()
        {
            db = new EcommerceDBContext();
        }
        public List<Product_> GetProdutList()
        {
            //return db.Products.ToList();
            return null;   
               
        }
    }
}
