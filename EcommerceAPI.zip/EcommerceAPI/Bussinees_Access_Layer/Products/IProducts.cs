﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bussinees_Access_Layer.Products
{
    public interface IProducts
    {
        //public List<Products> GetProdutList();
        //public Product_Category GetCustegoryById(int id);
        //public void InsertProductCategory(Product_Category obj);
        //public void DeleteProductCategory(int id);
    }
}
