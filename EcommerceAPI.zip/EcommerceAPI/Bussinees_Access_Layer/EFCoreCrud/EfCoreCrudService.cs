﻿
using Data_Access_Layer.DBContext;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bussinees_Access_Layer.EFCoreCrud
{
    public class EfCoreCrudService : IEfCoreCrudService
    {
        private readonly EcommerceDBContext db;
        public EfCoreCrudService()
        {
            db = new EcommerceDBContext();
        }
        //   Directly By Database
        public List<Product_Category> GetCategoriesList()
        {
            return db.Product_Category.ToList();
        }
        public Product_Category GetCustegoryById(int id)
        {
            //var res= db.Customers.FromSqlRaw("select  * from Customers where id="+id).FirstOrDefault();
            var result=db.Product_Category.FirstOrDefault(res => res.id == id);
            return result;
        }
        public void InsertProductCategory(Product_Category obj)
        {
            db.Product_Category.Add(obj);
            db.SaveChanges();
        }
        public void UpdateCategory(Product_Category obj)
        {
            db.Product_Category.Attach(obj);
            db.Entry(obj).State = Microsoft.EntityFrameworkCore.EntityState.Modified;
            db.SaveChanges();
        }
        public void DeleteProductCategory(int id)
        {
            db.Remove(db.Product_Category.Find(id));
            db.SaveChanges();

        }
    }
}