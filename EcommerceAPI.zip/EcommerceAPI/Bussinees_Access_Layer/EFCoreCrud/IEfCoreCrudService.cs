﻿
using Data_Access_Layer.Models.Category;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bussinees_Access_Layer.EFCoreCrud
{
    public interface IEfCoreCrudService
    {
        public List<Product_Category> GetCategoriesList();
        public Product_Category GetCustegoryById(int id);
        public void InsertProductCategory(Product_Category obj);
        public void UpdateCategory(Product_Category obj);
        public void DeleteProductCategory(int id);
   
       

    }
}