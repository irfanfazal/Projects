﻿using Data_Access_Layer.DBContext;
using Data_Access_Layer.Models.Category;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data_Access_Layer
{
    public class Category_Data_Layer: ControllerBase
    {
        private readonly EcommerceDBContext _dbContext;

        public Category_Data_Layer()
        {
            _dbContext = new EcommerceDBContext();
        }
        //public List<Categories> GetAll()
        //{
        //    return null;
            

        //}
    }
}
