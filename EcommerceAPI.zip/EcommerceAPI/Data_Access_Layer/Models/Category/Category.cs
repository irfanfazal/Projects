﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data_Access_Layer.Models.Category
{
   
  
    //public class Categories
    //{

    //    public int id { get; set; }
    //    public string name { get; set; }
    //}
}
public class Product_Category
{
    public int id { get; set; }
    public string name { get; set; }
    public string created_date { get; set; }
}
public class my_Products
{
    [Key]
    public int productID { get; set; }

   // public int categoryID { get; set; }
    public string productName { get; set; }
    public string description { get; set; }
    //public int rating { get; set; }
    //public int price { get; set; }
    //public string created_date { get; set; }
    //public string productImage { get; set; }
    public bool isAvaialable { get; set; }
    //public string color { get; set; }
    //public int review { get; set; }
    public int mrp { get; set; }
    public int dp { get; set; }


}
