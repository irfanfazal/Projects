﻿using Business_Layer.EFCoreCrud;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace eCommerceApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductController : ControllerBase
    {
        private IEfCoreCrudService _IEfCoreCrudService;
        public ProductController(IEfCoreCrudService iEfCoreCrudService)
        {
            this._IEfCoreCrudService = iEfCoreCrudService;
        }
        [Route("GetProductList")]
        [HttpGet]
        public IActionResult GetProductList()
        {
            return Ok(_IEfCoreCrudService.GetProductList());
        }
        [Route("InsertProduct")]
        [HttpPost]
        public void InsertProduct(my_Products my_prod)
        {
            _IEfCoreCrudService.InsertProducts(my_prod);
        }
        [Route("GetProductById")]
        [HttpGet]
        public IActionResult GetProductById(int id)
        {
            return Ok(_IEfCoreCrudService.GetProductById(id));
        }
        [Route("UpdateProduct")]
        [HttpPost]
        public string UpdateProduct(my_Products productdata)
        {
            return _IEfCoreCrudService.updateProduct(productdata);
        }
        [Route("DeleteProductById")]
        [HttpDelete]
        public string DeleteProductById(int id)
        {
            return _IEfCoreCrudService.DeleteProductById(id);
        }
    }
}
