﻿using Business_Layer.EFCoreCrud;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace eCommerceApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CategoriesController : ControllerBase
    {
        private IEfCoreCrudService _IEfCoreCrudService;
        public CategoriesController(IEfCoreCrudService iEfCoreCrudService)
        {
            this._IEfCoreCrudService = iEfCoreCrudService;
        }

        [Route("GetCategoriesList")]
        [HttpGet]
        public IActionResult GetCategoriesList()
        {
            return Ok(_IEfCoreCrudService.GetCategoriesList());
        }
        [Route("GetCategoryById")]
        [HttpGet]
        public IActionResult GetCategorybyId(int id)
        {
            return Ok(_IEfCoreCrudService.GetCustegoryById(id));
        }
        [Route("InsertProductCategory")]
        [HttpPost]
        public void InsertProductCategory(Product_Category prod_cat)
        {
            _IEfCoreCrudService.InsertProductCategory(prod_cat);
        }
        [Route("DeleteProductCategoryByID")]
        [HttpPost]
        public void DeleteProductCategoryByID(int id)
        {
            _IEfCoreCrudService.DeleteProductCategory(id);
        }
        [Route("UpdateProductCategory")]
        [HttpPost]
        public void UpdateCategory(Product_Category prod_cat)
        {
            _IEfCoreCrudService.UpdateCategory(prod_cat);
        }
       
       
        

    }
}
