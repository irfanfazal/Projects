import { Usermodel } from './usermodel';

describe('Usermodel', () => {
  it('should create an instance', () => {
    expect(new Usermodel()).toBeTruthy();
  });
});
