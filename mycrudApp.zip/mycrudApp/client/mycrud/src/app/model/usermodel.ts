export class Usermodel {
        id:number=0;  
        name: string;  
        age:any; 
        gender:string;
        email:string;
        isMarried:any;
        country:string;
        djoin:string;
        details:string;
        imgPath:string;
}
export class Register{
        id:number=0;
        FirstName:string;
        LastName:string;
        Email:string;
        Password:string;
        ConfirmPassword:string;
    }
