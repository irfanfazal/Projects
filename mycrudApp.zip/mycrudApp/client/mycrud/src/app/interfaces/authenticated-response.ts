export interface AuthenticatedResponse {
    token:string;
    refreshToken: string;
}
